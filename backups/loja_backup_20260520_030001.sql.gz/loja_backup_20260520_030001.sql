--
-- PostgreSQL database dump
--

\restrict 64KMjCnvRNFT1B1KVm3Zbe0qrbFBdmFZhXweVJ9cviUq1XiAI51WTJOd517HDJ3

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."_ManufacturerToSubcategory" DROP CONSTRAINT IF EXISTS "_ManufacturerToSubcategory_B_fkey";
ALTER TABLE IF EXISTS ONLY public."_ManufacturerToSubcategory" DROP CONSTRAINT IF EXISTS "_ManufacturerToSubcategory_A_fkey";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public."SupplierInteraction" DROP CONSTRAINT IF EXISTS "SupplierInteraction_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."Subcategory" DROP CONSTRAINT IF EXISTS "Subcategory_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."Stock" DROP CONSTRAINT IF EXISTS "Stock_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."Session" DROP CONSTRAINT IF EXISTS "Session_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrder" DROP CONSTRAINT IF EXISTS "ServiceOrder_technicianId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrder" DROP CONSTRAINT IF EXISTS "ServiceOrder_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrderItem" DROP CONSTRAINT IF EXISTS "ServiceOrderItem_serviceOrderId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrderItem" DROP CONSTRAINT IF EXISTS "ServiceOrderItem_serviceId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrderItem" DROP CONSTRAINT IF EXISTS "ServiceOrderItem_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrderHistory" DROP CONSTRAINT IF EXISTS "ServiceOrderHistory_serviceOrderId_fkey";
ALTER TABLE IF EXISTS ONLY public."Sale" DROP CONSTRAINT IF EXISTS "Sale_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleReturn" DROP CONSTRAINT IF EXISTS "SaleReturn_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleReturn" DROP CONSTRAINT IF EXISTS "SaleReturn_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleReturnItem" DROP CONSTRAINT IF EXISTS "SaleReturnItem_saleReturnId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleReturnItem" DROP CONSTRAINT IF EXISTS "SaleReturnItem_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleItem" DROP CONSTRAINT IF EXISTS "SaleItem_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleItem" DROP CONSTRAINT IF EXISTS "SaleItem_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."RolePermission" DROP CONSTRAINT IF EXISTS "RolePermission_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public."RolePermission" DROP CONSTRAINT IF EXISTS "RolePermission_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public."Receivable" DROP CONSTRAINT IF EXISTS "Receivable_serviceOrderId_fkey";
ALTER TABLE IF EXISTS ONLY public."Receivable" DROP CONSTRAINT IF EXISTS "Receivable_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public."Receivable" DROP CONSTRAINT IF EXISTS "Receivable_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Receivable" DROP CONSTRAINT IF EXISTS "Receivable_costCenterId_fkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_originClientId_fkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_manufacturerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductVariation" DROP CONSTRAINT IF EXISTS "ProductVariation_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductPriceHistory" DROP CONSTRAINT IF EXISTS "ProductPriceHistory_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductAttribute" DROP CONSTRAINT IF EXISTS "ProductAttribute_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductAttribute" DROP CONSTRAINT IF EXISTS "ProductAttribute_attributeId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payable" DROP CONSTRAINT IF EXISTS "Payable_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payable" DROP CONSTRAINT IF EXISTS "Payable_costCenterId_fkey";
ALTER TABLE IF EXISTS ONLY public."MarketplaceListing" DROP CONSTRAINT IF EXISTS "MarketplaceListing_variationId_fkey";
ALTER TABLE IF EXISTS ONLY public."MarketplaceListing" DROP CONSTRAINT IF EXISTS "MarketplaceListing_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."MarketplaceListing" DROP CONSTRAINT IF EXISTS "MarketplaceListing_marketplaceId_fkey";
ALTER TABLE IF EXISTS ONLY public."MarketplaceCategory" DROP CONSTRAINT IF EXISTS "MarketplaceCategory_marketplaceId_fkey";
ALTER TABLE IF EXISTS ONLY public."Item" DROP CONSTRAINT IF EXISTS "Item_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."Employee" DROP CONSTRAINT IF EXISTS "Employee_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."CustomerInteraction" DROP CONSTRAINT IF EXISTS "CustomerInteraction_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."CustomerFunnelCard" DROP CONSTRAINT IF EXISTS "CustomerFunnelCard_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."CashMovement" DROP CONSTRAINT IF EXISTS "CashMovement_receivableId_fkey";
ALTER TABLE IF EXISTS ONLY public."CashMovement" DROP CONSTRAINT IF EXISTS "CashMovement_payableId_fkey";
ALTER TABLE IF EXISTS ONLY public."BlogPost" DROP CONSTRAINT IF EXISTS "BlogPost_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."AttributeOption" DROP CONSTRAINT IF EXISTS "AttributeOption_attributeId_fkey";
ALTER TABLE IF EXISTS ONLY public."Account" DROP CONSTRAINT IF EXISTS "Account_userId_fkey";
DROP INDEX IF EXISTS public."_ManufacturerToSubcategory_B_index";
DROP INDEX IF EXISTS public."_ManufacturerToSubcategory_AB_unique";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."Supplier_document_key";
DROP INDEX IF EXISTS public."Subcategory_slug_categoryId_key";
DROP INDEX IF EXISTS public."Subcategory_categoryId_idx";
DROP INDEX IF EXISTS public."Stock_productId_key";
DROP INDEX IF EXISTS public."StockMovement_productId_idx";
DROP INDEX IF EXISTS public."Session_sessionToken_key";
DROP INDEX IF EXISTS public."Service_internalCode_key";
DROP INDEX IF EXISTS public."ServiceCommissionProvision_technicianUserId_competenceYear__idx";
DROP INDEX IF EXISTS public."ServiceCommissionProvision_status_paidAt_idx";
DROP INDEX IF EXISTS public."ServiceCommissionProvision_serviceOrderItemId_technicianUse_key";
DROP INDEX IF EXISTS public."Role_name_key";
DROP INDEX IF EXISTS public."RolePermission_roleId_permissionId_key";
DROP INDEX IF EXISTS public."Receivable_serviceOrderId_key";
DROP INDEX IF EXISTS public."Receivable_saleId_key";
DROP INDEX IF EXISTS public."Receivable_origin_paidAt_idx";
DROP INDEX IF EXISTS public."Product_manufacturerId_idx";
DROP INDEX IF EXISTS public."Product_categoryId_idx";
DROP INDEX IF EXISTS public."Product_baseSku_key";
DROP INDEX IF EXISTS public."Product_baseSku_idx";
DROP INDEX IF EXISTS public."Product_barcode_idx";
DROP INDEX IF EXISTS public."ProductVariation_sku_key";
DROP INDEX IF EXISTS public."ProductVariation_sku_idx";
DROP INDEX IF EXISTS public."ProductAttribute_productId_attributeId_key";
DROP INDEX IF EXISTS public."Permission_action_resource_key";
DROP INDEX IF EXISTS public."Marketplace_name_key";
DROP INDEX IF EXISTS public."MarketplaceListing_marketplaceId_productId_variationId_key";
DROP INDEX IF EXISTS public."MarketplaceListing_externalId_idx";
DROP INDEX IF EXISTS public."MarketplaceCategory_marketplaceId_externalCode_key";
DROP INDEX IF EXISTS public."MarketplaceCategory_categoryId_idx";
DROP INDEX IF EXISTS public."Manufacturer_slug_key";
DROP INDEX IF EXISTS public."Manufacturer_name_key";
DROP INDEX IF EXISTS public."Item_serialNumber_key";
DROP INDEX IF EXISTS public."Employee_cpf_key";
DROP INDEX IF EXISTS public."DailyMetrics_date_key";
DROP INDEX IF EXISTS public."Customer_email_key";
DROP INDEX IF EXISTS public."Customer_document_key";
DROP INDEX IF EXISTS public."CustomerFunnelCard_stage_active_idx";
DROP INDEX IF EXISTS public."CustomerFunnelCard_customerId_active_idx";
DROP INDEX IF EXISTS public."Category_slug_key";
DROP INDEX IF EXISTS public."BlogPost_slug_key";
DROP INDEX IF EXISTS public."BlogAuthor_slug_key";
DROP INDEX IF EXISTS public."Attribute_slug_key";
DROP INDEX IF EXISTS public."AttributeOption_attributeId_idx";
DROP INDEX IF EXISTS public."Account_provider_providerAccountId_key";
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."Supplier" DROP CONSTRAINT IF EXISTS "Supplier_pkey";
ALTER TABLE IF EXISTS ONLY public."SupplierInteraction" DROP CONSTRAINT IF EXISTS "SupplierInteraction_pkey";
ALTER TABLE IF EXISTS ONLY public."Subcategory" DROP CONSTRAINT IF EXISTS "Subcategory_pkey";
ALTER TABLE IF EXISTS ONLY public."StoreSettings" DROP CONSTRAINT IF EXISTS "StoreSettings_pkey";
ALTER TABLE IF EXISTS ONLY public."Stock" DROP CONSTRAINT IF EXISTS "Stock_pkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_pkey";
ALTER TABLE IF EXISTS ONLY public."Session" DROP CONSTRAINT IF EXISTS "Session_pkey";
ALTER TABLE IF EXISTS ONLY public."Service" DROP CONSTRAINT IF EXISTS "Service_pkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrder" DROP CONSTRAINT IF EXISTS "ServiceOrder_pkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrderItem" DROP CONSTRAINT IF EXISTS "ServiceOrderItem_pkey";
ALTER TABLE IF EXISTS ONLY public."ServiceOrderHistory" DROP CONSTRAINT IF EXISTS "ServiceOrderHistory_pkey";
ALTER TABLE IF EXISTS ONLY public."ServiceCommissionProvision" DROP CONSTRAINT IF EXISTS "ServiceCommissionProvision_pkey";
ALTER TABLE IF EXISTS ONLY public."Sale" DROP CONSTRAINT IF EXISTS "Sale_pkey";
ALTER TABLE IF EXISTS ONLY public."SaleReturn" DROP CONSTRAINT IF EXISTS "SaleReturn_pkey";
ALTER TABLE IF EXISTS ONLY public."SaleReturnItem" DROP CONSTRAINT IF EXISTS "SaleReturnItem_pkey";
ALTER TABLE IF EXISTS ONLY public."SaleItem" DROP CONSTRAINT IF EXISTS "SaleItem_pkey";
ALTER TABLE IF EXISTS ONLY public."Role" DROP CONSTRAINT IF EXISTS "Role_pkey";
ALTER TABLE IF EXISTS ONLY public."RolePermission" DROP CONSTRAINT IF EXISTS "RolePermission_pkey";
ALTER TABLE IF EXISTS ONLY public."Receivable" DROP CONSTRAINT IF EXISTS "Receivable_pkey";
ALTER TABLE IF EXISTS ONLY public."RateLimit" DROP CONSTRAINT IF EXISTS "RateLimit_pkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_pkey";
ALTER TABLE IF EXISTS ONLY public."ProductVariation" DROP CONSTRAINT IF EXISTS "ProductVariation_pkey";
ALTER TABLE IF EXISTS ONLY public."ProductPriceHistory" DROP CONSTRAINT IF EXISTS "ProductPriceHistory_pkey";
ALTER TABLE IF EXISTS ONLY public."ProductAttribute" DROP CONSTRAINT IF EXISTS "ProductAttribute_pkey";
ALTER TABLE IF EXISTS ONLY public."Permission" DROP CONSTRAINT IF EXISTS "Permission_pkey";
ALTER TABLE IF EXISTS ONLY public."PaymentFeeSettings" DROP CONSTRAINT IF EXISTS "PaymentFeeSettings_pkey";
ALTER TABLE IF EXISTS ONLY public."Payable" DROP CONSTRAINT IF EXISTS "Payable_pkey";
ALTER TABLE IF EXISTS ONLY public."Marketplace" DROP CONSTRAINT IF EXISTS "Marketplace_pkey";
ALTER TABLE IF EXISTS ONLY public."MarketplaceListing" DROP CONSTRAINT IF EXISTS "MarketplaceListing_pkey";
ALTER TABLE IF EXISTS ONLY public."MarketplaceCategory" DROP CONSTRAINT IF EXISTS "MarketplaceCategory_pkey";
ALTER TABLE IF EXISTS ONLY public."Manufacturer" DROP CONSTRAINT IF EXISTS "Manufacturer_pkey";
ALTER TABLE IF EXISTS ONLY public."Item" DROP CONSTRAINT IF EXISTS "Item_pkey";
ALTER TABLE IF EXISTS ONLY public."Employee" DROP CONSTRAINT IF EXISTS "Employee_pkey";
ALTER TABLE IF EXISTS ONLY public."DailyMetrics" DROP CONSTRAINT IF EXISTS "DailyMetrics_pkey";
ALTER TABLE IF EXISTS ONLY public."Customer" DROP CONSTRAINT IF EXISTS "Customer_pkey";
ALTER TABLE IF EXISTS ONLY public."CustomerInteraction" DROP CONSTRAINT IF EXISTS "CustomerInteraction_pkey";
ALTER TABLE IF EXISTS ONLY public."CustomerFunnelCard" DROP CONSTRAINT IF EXISTS "CustomerFunnelCard_pkey";
ALTER TABLE IF EXISTS ONLY public."CostCenter" DROP CONSTRAINT IF EXISTS "CostCenter_pkey";
ALTER TABLE IF EXISTS ONLY public."Category" DROP CONSTRAINT IF EXISTS "Category_pkey";
ALTER TABLE IF EXISTS ONLY public."CashMovement" DROP CONSTRAINT IF EXISTS "CashMovement_pkey";
ALTER TABLE IF EXISTS ONLY public."BlogPost" DROP CONSTRAINT IF EXISTS "BlogPost_pkey";
ALTER TABLE IF EXISTS ONLY public."BlogAuthor" DROP CONSTRAINT IF EXISTS "BlogAuthor_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_pkey";
ALTER TABLE IF EXISTS ONLY public."Attribute" DROP CONSTRAINT IF EXISTS "Attribute_pkey";
ALTER TABLE IF EXISTS ONLY public."AttributeOption" DROP CONSTRAINT IF EXISTS "AttributeOption_pkey";
ALTER TABLE IF EXISTS ONLY public."Account" DROP CONSTRAINT IF EXISTS "Account_pkey";
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TABLE IF EXISTS public."_ManufacturerToSubcategory";
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."SupplierInteraction";
DROP TABLE IF EXISTS public."Supplier";
DROP TABLE IF EXISTS public."Subcategory";
DROP TABLE IF EXISTS public."StoreSettings";
DROP TABLE IF EXISTS public."StockMovement";
DROP TABLE IF EXISTS public."Stock";
DROP TABLE IF EXISTS public."Session";
DROP TABLE IF EXISTS public."ServiceOrderItem";
DROP TABLE IF EXISTS public."ServiceOrderHistory";
DROP TABLE IF EXISTS public."ServiceOrder";
DROP TABLE IF EXISTS public."ServiceCommissionProvision";
DROP TABLE IF EXISTS public."Service";
DROP TABLE IF EXISTS public."SaleReturnItem";
DROP TABLE IF EXISTS public."SaleReturn";
DROP TABLE IF EXISTS public."SaleItem";
DROP TABLE IF EXISTS public."Sale";
DROP TABLE IF EXISTS public."RolePermission";
DROP TABLE IF EXISTS public."Role";
DROP TABLE IF EXISTS public."Receivable";
DROP TABLE IF EXISTS public."RateLimit";
DROP TABLE IF EXISTS public."ProductVariation";
DROP TABLE IF EXISTS public."ProductPriceHistory";
DROP TABLE IF EXISTS public."ProductAttribute";
DROP TABLE IF EXISTS public."Product";
DROP TABLE IF EXISTS public."Permission";
DROP TABLE IF EXISTS public."PaymentFeeSettings";
DROP TABLE IF EXISTS public."Payable";
DROP TABLE IF EXISTS public."MarketplaceListing";
DROP TABLE IF EXISTS public."MarketplaceCategory";
DROP TABLE IF EXISTS public."Marketplace";
DROP TABLE IF EXISTS public."Manufacturer";
DROP TABLE IF EXISTS public."Item";
DROP TABLE IF EXISTS public."Employee";
DROP TABLE IF EXISTS public."DailyMetrics";
DROP TABLE IF EXISTS public."CustomerInteraction";
DROP TABLE IF EXISTS public."CustomerFunnelCard";
DROP TABLE IF EXISTS public."Customer";
DROP TABLE IF EXISTS public."CostCenter";
DROP TABLE IF EXISTS public."Category";
DROP TABLE IF EXISTS public."CashMovement";
DROP TABLE IF EXISTS public."BlogPost";
DROP TABLE IF EXISTS public."BlogAuthor";
DROP TABLE IF EXISTS public."AuditLog";
DROP TABLE IF EXISTS public."AttributeOption";
DROP TABLE IF EXISTS public."Attribute";
DROP TABLE IF EXISTS public."Account";
DROP TYPE IF EXISTS public."StockMovementType";
DROP TYPE IF EXISTS public."ServicePriceType";
DROP TYPE IF EXISTS public."ServiceCommissionStatus";
DROP TYPE IF EXISTS public."SaleStatus";
DROP TYPE IF EXISTS public."ReturnType";
DROP TYPE IF EXISTS public."ReturnStatus";
DROP TYPE IF EXISTS public."ReceivableOrigin";
DROP TYPE IF EXISTS public."ProductType";
DROP TYPE IF EXISTS public."ProductCondition";
DROP TYPE IF EXISTS public."PaymentStatus";
DROP TYPE IF EXISTS public."PayableType";
DROP TYPE IF EXISTS public."OrderItemType";
DROP TYPE IF EXISTS public."OSStatus";
DROP TYPE IF EXISTS public."OSPriority";
DROP TYPE IF EXISTS public."ItemStatus";
DROP TYPE IF EXISTS public."FunnelStage";
DROP TYPE IF EXISTS public."EmployeeStatus";
DROP TYPE IF EXISTS public."EmployeeContractType";
DROP TYPE IF EXISTS public."CustomerType";
DROP TYPE IF EXISTS public."CostCenterType";
DROP TYPE IF EXISTS public."CommissionType";
DROP TYPE IF EXISTS public."CashMovementType";
DROP TYPE IF EXISTS public."AttributeType";
DROP TYPE IF EXISTS public."AttributeEntitySource";
--
-- Name: AttributeEntitySource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttributeEntitySource" AS ENUM (
    'NONE',
    'MANUFACTURER',
    'SUPPLIER',
    'CATEGORY'
);


--
-- Name: AttributeType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttributeType" AS ENUM (
    'TEXT',
    'NUMBER',
    'LIST',
    'BOOLEAN'
);


--
-- Name: CashMovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CashMovementType" AS ENUM (
    'IN',
    'OUT'
);


--
-- Name: CommissionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommissionType" AS ENUM (
    'PERCENT',
    'FIXED'
);


--
-- Name: CostCenterType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CostCenterType" AS ENUM (
    'REVENUE',
    'EXPENSE'
);


--
-- Name: CustomerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CustomerType" AS ENUM (
    'PF',
    'PJ'
);


--
-- Name: EmployeeContractType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EmployeeContractType" AS ENUM (
    'CLT',
    'PJ',
    'AUTONOMO',
    'ESTAGIARIO',
    'SOCIO'
);


--
-- Name: EmployeeStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EmployeeStatus" AS ENUM (
    'ATIVO',
    'INATIVO'
);


--
-- Name: FunnelStage; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FunnelStage" AS ENUM (
    'NOVO_CONTATO',
    'EM_ANDAMENTO',
    'CONTATO_QUENTE',
    'VENDA_CONCLUIDA',
    'FEEDBACK_REALIZADO',
    'DESINTERESSADO',
    'FINALIZADO'
);


--
-- Name: ItemStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ItemStatus" AS ENUM (
    'AVAILABLE',
    'SOLD',
    'MAINTENANCE',
    'RESERVED'
);


--
-- Name: OSPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OSPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


--
-- Name: OSStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OSStatus" AS ENUM (
    'ENTRADA',
    'DIAGNOSTICO',
    'ORCAMENTO',
    'AGUARDANDO_APROVACAO',
    'APROVADO',
    'EM_REPARO',
    'AGUARDANDO_PECA',
    'FINALIZADO',
    'ENTREGUE',
    'CANCELADO'
);


--
-- Name: OrderItemType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderItemType" AS ENUM (
    'PART',
    'SERVICE'
);


--
-- Name: PayableType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PayableType" AS ENUM (
    'DEFAULT',
    'TECHNICIAN_COMMISSION'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PAID',
    'CANCELLED',
    'OVERDUE'
);


--
-- Name: ProductCondition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductCondition" AS ENUM (
    'NEW',
    'USED',
    'DEFECTIVE'
);


--
-- Name: ProductType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductType" AS ENUM (
    'PRODUCT',
    'PART',
    'SERVICE'
);


--
-- Name: ReceivableOrigin; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReceivableOrigin" AS ENUM (
    'MANUAL',
    'SALE',
    'SERVICE'
);


--
-- Name: ReturnStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReturnStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'COMPLETED'
);


--
-- Name: ReturnType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReturnType" AS ENUM (
    'RETURN',
    'EXCHANGE'
);


--
-- Name: SaleStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SaleStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: ServiceCommissionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ServiceCommissionStatus" AS ENUM (
    'PROVISIONED',
    'PAID',
    'CANCELLED'
);


--
-- Name: ServicePriceType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ServicePriceType" AS ENUM (
    'FIXED',
    'HOURLY',
    'VARIABLE'
);


--
-- Name: StockMovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StockMovementType" AS ENUM (
    'IN_PURCHASE',
    'IN_RETURN',
    'IN_ADJUSTMENT',
    'OUT_SALE',
    'OUT_WARRANTY',
    'OUT_LOSS',
    'OUT_ADJUSTMENT',
    'OUT_SERVICE_PART'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: Attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Attribute" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    type public."AttributeType" DEFAULT 'TEXT'::public."AttributeType" NOT NULL,
    "marketplaceRequired" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "entitySource" public."AttributeEntitySource" DEFAULT 'NONE'::public."AttributeEntitySource" NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


--
-- Name: AttributeOption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AttributeOption" (
    id text NOT NULL,
    "attributeId" text NOT NULL,
    value text NOT NULL,
    label text,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    action text NOT NULL,
    module text NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text,
    "newValue" text,
    "oldValue" text
);


--
-- Name: BlogAuthor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BlogAuthor" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    role text NOT NULL,
    bio text,
    image text,
    "imageAlt" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: BlogPost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BlogPost" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "featuredImage" text,
    "featuredImageAlt" text,
    categoria text NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "authorId" text NOT NULL,
    excerpt text,
    body jsonb NOT NULL,
    faqs jsonb,
    "relatedService" text,
    "readingTime" integer,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: CashMovement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CashMovement" (
    id text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    description text,
    "payableId" text,
    "receivableId" text,
    type public."CashMovementType" NOT NULL,
    "userId" text,
    value numeric(10,2) NOT NULL
);


--
-- Name: Category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    slug text NOT NULL
);


--
-- Name: CostCenter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CostCenter" (
    id text NOT NULL,
    name text NOT NULL,
    type public."CostCenterType" NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    document text NOT NULL,
    type public."CustomerType" DEFAULT 'PF'::public."CustomerType" NOT NULL,
    phone text,
    "zipCode" text,
    street text,
    number text,
    complement text,
    neighborhood text,
    city text,
    state text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CustomerFunnelCard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CustomerFunnelCard" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    stage public."FunnelStage" DEFAULT 'NOVO_CONTATO'::public."FunnelStage" NOT NULL,
    "sellerNote" text,
    "itemInterest" text,
    active boolean DEFAULT true NOT NULL,
    "archivedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastStageChangeAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "hasNewMessage" boolean DEFAULT false NOT NULL
);


--
-- Name: CustomerInteraction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CustomerInteraction" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: DailyMetrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DailyMetrics" (
    id text NOT NULL,
    date date NOT NULL,
    "totalSales" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalRevenue" numeric(10,2) DEFAULT 0 NOT NULL,
    "osCount" integer DEFAULT 0 NOT NULL,
    "saleCount" integer DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Employee" (
    id text NOT NULL,
    "nomeCompleto" text NOT NULL,
    cpf text NOT NULL,
    "dataNascimento" timestamp(3) without time zone NOT NULL,
    "celularWhatsapp" text NOT NULL,
    "emailPessoal" text,
    "dataAdmissao" timestamp(3) without time zone NOT NULL,
    "cargoFuncao" text NOT NULL,
    "tipoContrato" public."EmployeeContractType" NOT NULL,
    "salarioBase" numeric(10,2) NOT NULL,
    "percentualComissao" numeric(5,2),
    "chavePix" text,
    status public."EmployeeStatus" DEFAULT 'ATIVO'::public."EmployeeStatus" NOT NULL,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "descricaoPerfil" text,
    "fotoUrl" text
);


--
-- Name: Item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Item" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "serialNumber" text NOT NULL,
    imei text,
    condition public."ProductCondition" NOT NULL,
    grade text,
    "costPrice" numeric(10,2) NOT NULL,
    "warrantyDays" integer,
    status public."ItemStatus" DEFAULT 'AVAILABLE'::public."ItemStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Manufacturer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Manufacturer" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    website text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Marketplace; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Marketplace" (
    id text NOT NULL,
    name text NOT NULL,
    "apiCode" text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: MarketplaceCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MarketplaceCategory" (
    id text NOT NULL,
    "marketplaceId" text NOT NULL,
    "externalCode" text NOT NULL,
    "externalName" text NOT NULL,
    "categoryId" text
);


--
-- Name: MarketplaceListing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MarketplaceListing" (
    id text NOT NULL,
    "marketplaceId" text NOT NULL,
    "productId" text NOT NULL,
    "variationId" text,
    "externalId" text,
    "publishedTitle" text,
    "publishedPrice" numeric(10,2),
    status text DEFAULT 'DRAFT'::text,
    "publicLink" text,
    "syncStock" boolean DEFAULT true NOT NULL,
    "syncPrice" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Payable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payable" (
    id text NOT NULL,
    description text NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    value numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "costCenterId" text,
    "supplierId" text,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "attachmentUrl" text,
    "competenceMonth" integer,
    "competenceYear" integer,
    "payableType" public."PayableType" DEFAULT 'DEFAULT'::public."PayableType" NOT NULL,
    "technicianUserId" text
);


--
-- Name: PaymentFeeSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PaymentFeeSettings" (
    id text NOT NULL,
    "creditFixedFee" numeric(10,2) DEFAULT 0 NOT NULL,
    "creditVariableFee" numeric(5,2) DEFAULT 0 NOT NULL,
    "debitFixedFee" numeric(10,2) DEFAULT 0 NOT NULL,
    "debitVariableFee" numeric(5,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    price numeric(10,2) NOT NULL,
    barcode text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    active boolean DEFAULT true NOT NULL,
    condition public."ProductCondition" DEFAULT 'NEW'::public."ProductCondition" NOT NULL,
    "originClientId" text,
    "supplierId" text,
    type public."ProductType" DEFAULT 'PRODUCT'::public."ProductType" NOT NULL,
    ncm text,
    unit text DEFAULT 'UN'::text,
    "allowUsed" boolean DEFAULT true NOT NULL,
    "baseSku" text,
    "commercialName" text NOT NULL,
    commission numeric(10,2) DEFAULT 0 NOT NULL,
    "controlSerialNumber" boolean DEFAULT false NOT NULL,
    height numeric(10,2),
    length numeric(10,2),
    location text,
    "longDescription" text,
    margin numeric(5,2) DEFAULT 0 NOT NULL,
    "shortDescription" text,
    "warrantyMonths" integer,
    weight numeric(10,3),
    width numeric(10,2),
    "categoryId" text NOT NULL,
    "manufacturerId" text NOT NULL
);


--
-- Name: ProductAttribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductAttribute" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "attributeId" text NOT NULL,
    value text NOT NULL
);


--
-- Name: ProductPriceHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductPriceHistory" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "oldPrice" numeric(10,2) NOT NULL,
    "newPrice" numeric(10,2) NOT NULL,
    "changedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ProductVariation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductVariation" (
    id text NOT NULL,
    "productId" text NOT NULL,
    sku text NOT NULL,
    title text NOT NULL,
    "basePrice" numeric(10,2) NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: RateLimit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RateLimit" (
    key text NOT NULL,
    timestamps text DEFAULT '[]'::text NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: Receivable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Receivable" (
    id text NOT NULL,
    description text NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    value numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "costCenterId" text,
    "customerId" text,
    "saleId" text,
    "serviceOrderId" text,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "paymentMethod" text,
    "cardFeePercent" numeric(5,2),
    "cardFeeValue" numeric(10,2),
    "netValue" numeric(10,2),
    "paidAt" timestamp(3) without time zone,
    origin public."ReceivableOrigin" DEFAULT 'MANUAL'::public."ReceivableOrigin" NOT NULL
);


--
-- Name: Role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Sale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Sale" (
    id text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    total numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "customerId" text,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    installments integer DEFAULT 1 NOT NULL,
    "paymentMethod" text NOT NULL,
    status public."SaleStatus" DEFAULT 'COMPLETED'::public."SaleStatus" NOT NULL
);


--
-- Name: SaleItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SaleItem" (
    id text NOT NULL,
    "saleId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    "costPrice" numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    "warrantyMonths" integer
);


--
-- Name: SaleReturn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SaleReturn" (
    id text NOT NULL,
    "saleId" text NOT NULL,
    "customerId" text,
    reason text NOT NULL,
    notes text,
    status public."ReturnStatus" DEFAULT 'PENDING'::public."ReturnStatus" NOT NULL,
    type public."ReturnType" DEFAULT 'RETURN'::public."ReturnType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text
);


--
-- Name: SaleReturnItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SaleReturnItem" (
    id text NOT NULL,
    "saleReturnId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    reason text
);


--
-- Name: Service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Service" (
    id text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "commissionType" public."CommissionType" DEFAULT 'PERCENT'::public."CommissionType" NOT NULL,
    "commissionValue" numeric(10,2) DEFAULT 0 NOT NULL,
    "descriptionShort" text,
    "estimatedTimeMin" integer,
    "internalCode" text NOT NULL,
    "marketplaceCategoryId" text,
    "marketplaceDescTemplate" text,
    "marketplaceTitleTemplate" text,
    "priceBase" numeric(10,2) NOT NULL,
    "priceType" public."ServicePriceType" DEFAULT 'FIXED'::public."ServicePriceType" NOT NULL,
    "warrantyMonths" integer
);


--
-- Name: ServiceCommissionProvision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ServiceCommissionProvision" (
    id text NOT NULL,
    "serviceOrderId" text NOT NULL,
    "serviceOrderItemId" text NOT NULL,
    "serviceId" text,
    "technicianUserId" text NOT NULL,
    "competenceMonth" integer NOT NULL,
    "competenceYear" integer NOT NULL,
    "baseAmount" numeric(10,2) NOT NULL,
    "commissionPercent" numeric(5,2) NOT NULL,
    "commissionAmount" numeric(10,2) NOT NULL,
    status public."ServiceCommissionStatus" DEFAULT 'PROVISIONED'::public."ServiceCommissionStatus" NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "payableId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ServiceOrder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ServiceOrder" (
    id text NOT NULL,
    device text NOT NULL,
    serial text,
    defect text NOT NULL,
    "entryDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "customerId" text NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "endDate" timestamp(3) without time zone,
    notes text,
    report text,
    "technicianId" text,
    total numeric(10,2) DEFAULT 0 NOT NULL,
    "totalParts" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalServices" numeric(10,2) DEFAULT 0 NOT NULL,
    status public."OSStatus" DEFAULT 'ENTRADA'::public."OSStatus" NOT NULL,
    priority public."OSPriority" DEFAULT 'NORMAL'::public."OSPriority" NOT NULL
);


--
-- Name: ServiceOrderHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ServiceOrderHistory" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    notes text,
    "serviceOrderId" text NOT NULL,
    "userId" text,
    status public."OSStatus" NOT NULL
);


--
-- Name: ServiceOrderItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ServiceOrderItem" (
    id text NOT NULL,
    "serviceOrderId" text NOT NULL,
    type public."OrderItemType" NOT NULL,
    "productId" text,
    "serviceId" text,
    name text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    "costPrice" numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    "warrantyMonths" integer
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: Stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Stock" (
    id text NOT NULL,
    "productId" text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    "averageCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalValue" numeric(10,2) DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 5 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    quantity integer NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdBy" text,
    reason text,
    "referenceId" text,
    type public."StockMovementType" NOT NULL,
    invoice text,
    "resultingAverageCost" numeric(10,2),
    "supplierId" text,
    "unitCost" numeric(10,2)
);


--
-- Name: StoreSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StoreSettings" (
    id text NOT NULL,
    "nameFantasia" text DEFAULT 'Virtual Games'::text NOT NULL,
    cnpj text DEFAULT '00.000.000/0001-00'::text NOT NULL,
    address text DEFAULT 'Rua Venâncio Aires, 1434, Torre Divindade. Sala 106 D-2, Centro, Santa Maria, RS - CEP 97010-002'::text NOT NULL,
    phone text DEFAULT '(55) 99725-2786'::text NOT NULL,
    email text DEFAULT 'contato@virtualgames.com'::text NOT NULL,
    "serviceHours" text DEFAULT 'Segunda a Sexta: 09:00 às 18:30 | Sábado: 09:00 às 13:00'::text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Subcategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Subcategory" (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    name text NOT NULL,
    slug text,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Supplier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Supplier" (
    id text NOT NULL,
    name text NOT NULL,
    contact text,
    phone text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    document text,
    email text
);


--
-- Name: SupplierInteraction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SupplierInteraction" (
    id text NOT NULL,
    "supplierId" text NOT NULL,
    type text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    password text,
    "roleId" text NOT NULL,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone
);


--
-- Name: _ManufacturerToSubcategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."_ManufacturerToSubcategory" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: Attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Attribute" (id, name, slug, type, "marketplaceRequired", "createdAt", "entitySource", "order") FROM stdin;
cmndrx2kk0086xpl65pu09ax0	Cor	cor	TEXT	f	2026-03-30 22:42:36.74	NONE	2
cmnezvfew0002lyycvfv5vbn0	Fornecedor	fornecedor	TEXT	f	2026-03-31 19:13:03.176	SUPPLIER	3
cmndrx2l4008cxpl6g41mkgac	Código Universal de Produto	codigo-universal	TEXT	f	2026-03-30 22:42:36.76	NONE	4
cmndrx2l1008bxpl6q7itcd29	GTIN	gtin	TEXT	t	2026-03-30 22:42:36.757	NONE	5
cmndrx2ky008axpl6rsxpx90g	Garantia	garantia	NUMBER	f	2026-03-30 22:42:36.754	NONE	6
cmndrx2kb0084xpl66f57n86j	Marca	marca	TEXT	t	2026-03-30 22:42:36.731	NONE	7
cmndrx2kn0087xpl60hc9x2rq	Memória RAM	memoria-ram	TEXT	f	2026-03-30 22:42:36.744	NONE	8
cmndrx2kr0088xpl6ujxuznjg	Voltagem	voltagem	LIST	f	2026-03-30 22:42:36.747	NONE	9
cmndrx2ku0089xpl67rzzrx5l	Condição	condicao	LIST	t	2026-03-30 22:42:36.75	NONE	1
cmndrx2kg0085xpl6alqzjc22	Armazenamento	armazenamento	TEXT	f	2026-03-30 22:42:36.737	NONE	0
\.


--
-- Data for Name: AttributeOption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AttributeOption" (id, "attributeId", value, label, "order", "createdAt", "updatedAt") FROM stdin;
cmnezw5xf000blyycwgif7slp	cmndrx2ku0089xpl67rzzrx5l	Novo	Novo	0	2026-03-31 19:13:37.539	2026-03-31 19:13:37.539
cmnezw5xf000clyycv8673fl5	cmndrx2ku0089xpl67rzzrx5l	Usado	Usado	1	2026-03-31 19:13:37.539	2026-03-31 19:13:37.539
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, action, module, entity, "entityId", ip, "createdAt", "userId", "newValue", "oldValue") FROM stdin;
cmndsg0ui0000h739t6lm0bno	Excluiu usuário Pedro Técnico	ADMIN	User	cmndrx2ca005uxpl6a87npqwi	\N	2026-03-30 22:57:20.971	\N	\N	{"name":"Pedro Técnico","email":"tecnico@virtualgames.com"}
cmndshqgb0001h7392mdm0zlz	Excluiu usuário Maria Vendedora	ADMIN	User	cmndrx29u005sxpl656bfnijb	\N	2026-03-30 22:58:40.811	\N	\N	{"name":"Maria Vendedora","email":"vendedor@virtualgames.com"}
cmndshso60002h739740djdmi	Excluiu usuário João Gerente	ADMIN	User	cmndrx27g005qxpl655p534od	\N	2026-03-30 22:58:43.687	\N	\N	{"name":"João Gerente","email":"gerente@virtualgames.com"}
cmnf0fe3r000ilyyc5sbjr328	CLIENT_CREATE	customers	Client	cmnf0fe2z000hlyycctc7f2j3	::1	2026-03-31 19:28:34.599	\N	\N	\N
cmnf4p0yl002tlyycortj9ccw	Excluiu usuário Márcia Studer Ghisio	ADMIN	User	cmnf0dqkp000elyyc3aucdby4	\N	2026-03-31 21:28:02.589	\N	\N	{"name":"Márcia Studer Ghisio","email":"marciaghisio@gmail.com"}
cmnf6ejzr002ulyycdw6p6hon	CLIENT_DELETE	customers	Client	cmnf0fe2z000hlyycctc7f2j3	::1	2026-03-31 22:15:53.271	\N	\N	\N
cmp4fr5fx0009ivh633z4q560	CLIENT_DELETE	customers	Client	cmp4f2u3o0001ivh6ihy8b6gq	177.191.129.82	2026-05-13 19:11:34.221	\N	\N	\N
cmp8s3n30000dw6aqsngb98z3	CLIENT_CREATE	customers	Client	cmp8s3n2v000cw6aqlssmcyvi	131.221.54.140	2026-05-16 20:08:17.052	\N	\N	\N
\.


--
-- Data for Name: BlogAuthor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BlogAuthor" (id, name, slug, role, bio, image, "imageAlt", "createdAt", "updatedAt") FROM stdin;
ee6b8943-cd39-4dbd-8921-dd35f7a55b34	Emerson Gabriel de Mello Graeff	emerson-graeff	CEO e Fundador	Fundador da Virtual Games, especialista em gestão de assistência técnica com mais de 10 anos de experiência no mercado de games.	\N	\N	2026-05-17 14:10:28.063	2026-05-17 14:10:28.063
f573ec9e-ec58-4100-b634-4dc00ad8fbb1	Kevin de Mello Graeff	kevin-graeff	Técnico em Consoles	Técnico especializado em consoles PlayStation, Xbox e Nintendo. Certificado em reparo avançado de hardware gamer.	\N	\N	2026-05-17 14:10:28.063	2026-05-17 14:10:28.063
2245169a-98be-45a0-a2f0-f4e57aa1b2ec	Elias Rodrigues Fagundes	elias-fagundes	Técnico em Consoles	Técnico especializado em reparo de placas-mãe, soldagem SMD e diagnóstico de falhas em consoles e PCs gamer.	\N	\N	2026-05-17 14:10:28.063	2026-05-17 14:10:28.063
15678d8d-6091-4642-b77d-11e9e4e87654	Gabriel Rae da Silva Castro	gabriel-castro	Atendimento e Vendas	Especialista em atendimento ao cliente e vendas de equipamentos gamer. Responsável pelo suporte via WhatsApp e orçamentos.	\N	\N	2026-05-17 14:10:28.063	2026-05-17 14:10:28.063
cmpd9tmak0000zdl2ul4uefpw	Equipe Virtual Games	equipe-virtual-games	Equipe Técnica e Conteúdo	Equipe da Virtual Games, assistência técnica especializada em consoles e PC Gamer em Santa Maria, RS. Gamers de coração e profissionais por excelência.	\N	\N	2026-05-19 23:35:27.26	2026-05-19 23:35:27.26
\.


--
-- Data for Name: BlogPost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BlogPost" (id, title, slug, "metaTitle", "metaDescription", "featuredImage", "featuredImageAlt", categoria, "publishedAt", "updatedAt", "createdAt", "authorId", excerpt, body, faqs, "relatedService", "readingTime", published) FROM stdin;
f3764cf5-22b9-4ad4-b845-12195967253e	PS5 Superaquecendo: Causas, Sintomas e Soluções Definitivas	ps5-superaquecendo-causas-solucoes	PS5 Superaquecendo? Causas, Sintomas e Como Resolver em 2026	Seu PS5 está superaquecendo e desligando sozinho? Descubra as causas, sintomas e soluções definitivas para resolver o problema. Assistência técnica em Santa Maria RS.	\N	Console PS5 com ventilação obstruída por poeira	Consoles	2026-05-17 14:24:26.627	2026-05-17 14:24:26.627	2026-05-17 14:24:26.627	f573ec9e-ec58-4100-b634-4dc00ad8fbb1	O superaquecimento do PS5 é um dos problemas mais comuns enfrentados por gamers. Neste guia completo, explicamos as causas, sintomas e todas as soluções definitivas para manter seu console funcionando perfeitamente.	[{"type": "paragraph", "children": [{"text": "O PlayStation 5 é um console potente, mas seu hardware de última geração gera muito calor. Quando o sistema de refrigeração não consegue dissipar esse calor adequadamente, o console começa a superaquecer, resultando em quedas de desempenho, travamentos e até desligamentos automáticos."}]}, {"type": "heading", "children": [{"text": "Por que o PS5 Superaquece?"}]}, {"type": "paragraph", "children": [{"text": "Existem várias razões pelas quais seu PS5 pode estar superaquecendo. A causa mais comum é o acúmulo de poeira nos dissipadores de calor e ventoinhas. O PS5 possui um design que, embora eficiente, pode acumular poeira rapidamente dependendo do ambiente onde está instalado."}]}, {"type": "paragraph", "children": [{"text": "Outra causa frequente é a má ventilação. O console precisa de pelo menos 10 centímetros de espaço livre em todas as direções para que o ar circule adequadamente. Colocar o PS5 dentro de um rack fechado ou muito próximo da parede é uma receita para o superaquecimento."}]}, {"type": "paragraph", "children": [{"text": "Problemas na pasta térmica também são comuns, especialmente em consoles mais antigos. A pasta térmica entre o processador e o dissipador de calor pode secar ou degradar com o tempo, reduzindo significativamente a eficiência da transferência de calor."}]}, {"type": "heading", "children": [{"text": "Sintomas de Superaquecimento"}]}, {"type": "list", "children": [{"text": "Ventoinha girando muito rápido e fazendo barulho excessivo"}, {"text": "Console quente ao toque, especialmente na parte traseira"}, {"text": "Queda de desempenho (FPS baixo) durante jogos pesados"}, {"text": "Mensagem de aviso de temperatura elevada na tela"}, {"text": "Desligamento automático sem aviso prévio"}, {"text": "Travamentos e crashes frequentes durante sessões longas"}]}, {"type": "heading", "children": [{"text": "Soluções Definitivas"}]}, {"type": "paragraph", "children": [{"text": "A primeira e mais simples solução é a limpeza externa. Use um pano de microfibra levemente umedecido para limpar as entradas e saídas de ar. Um aspirador de pó com bocal estreito pode ajudar a remover poeira superficial das grades de ventilação."}]}, {"type": "paragraph", "children": [{"text": "Para uma limpeza mais profunda, é necessário abrir o console e limpar a ventoinha e o dissipador de calor. Este procedimento requer ferramentas adequadas e conhecimento técnico. Se você não tem experiência com manutenção de eletrônicos, recomendamos procurar uma assistência técnica especializada."}]}, {"type": "paragraph", "children": [{"text": "A troca da pasta térmica e dos thermal pads é a solução mais eficaz para problemas crônicos de superaquecimento. Utilizamos pastas térmicas de alta performance como Arctic MX-6 ou Thermal Grizzly Kryonaut, que oferecem condutividade térmica superior."}]}, {"type": "paragraph", "children": [{"text": "Também é importante verificar o posicionamento do console. Mantenha o PS5 em uma superfície plana, longe de fontes de calor como TVs e amplificadores, e com espaço adequado para ventilação."}]}]	[{"answer": "Os principais sinais são ventoinha barulhenta, console muito quente ao toque, queda de desempenho em jogos e desligamentos automáticos. Se você receber a mensagem de alerta de temperatura na tela, é sinal claro de superaquecimento.", "question": "Como saber se meu PS5 está superaquecendo?"}, {"answer": "A limpeza externa pode ser feita em casa com cuidado. Para limpeza interna, recomendamos assistência técnica especializada, pois abrir o console incorretamente pode danificar componentes sensíveis e anular a garantia.", "question": "Posso limpar o PS5 sozinho?"}, {"answer": "O valor varia conforme a gravidade. Uma limpeza completa com troca de pasta térmica custa entre R$150 e R$300. Entre em contato conosco para um orçamento personalizado.", "question": "Quanto custa para resolver superaquecimento do PS5?"}, {"answer": "Sim. O calor excessivo prolongado pode danificar componentes internos como o processador, a GPU e até soldas da placa-mãe. Quanto antes resolver, menores os danos.", "question": "Superaquecimento pode danificar permanentemente o PS5?"}]	/servicos/limpeza-preventiva	7	t
dc97439b-661b-4559-9b28-ffd0fe8b78d9	Quanto Custa Consertar um PS5? Guia de Preços 2026	quanto-custa-consertar-ps5-guia-precos	Quanto Custa Consertar um PS5 em 2026? Guia de Preços Atualizado	Guia completo de preços para conserto de PS5 em 2026: HDMI, superaquecimento, fonte, leitor de disco. Orçamento transparente em Santa Maria RS.	\N	PS5 sendo reparado por técnico especializado	Consoles	2026-05-17 14:24:26.634	2026-05-17 14:24:26.634	2026-05-17 14:24:26.634	ee6b8943-cd39-4dbd-8921-dd35f7a55b34	Saiba exatamente quanto custa cada tipo de reparo do PS5 em 2026. Preços atualizados para conserto de HDMI, superaquecimento, fonte e muito mais.	[{"type": "paragraph", "children": [{"text": "Seu PS5 quebrou e você está preocupado com o custo do conserto? Neste guia completo, detalhamos os preços de cada tipo de reparo em 2026 para que você possa tomar a melhor decisão."}]}, {"type": "heading", "children": [{"text": "Tabela de Preços de Reparos PS5"}]}, {"type": "paragraph", "children": [{"text": "Reparo da porta HDMI: R$250 a R$450. Este é um dos reparos mais comuns e o preço varia conforme o dano. Se apenas os pinos estão tortos, o custo é menor. Se a porta precisa ser totalmente substituída, o valor sobe."}]}, {"type": "paragraph", "children": [{"text": "Limpeza completa com troca de pasta térmica: R$150 a R$300. Inclui desmontagem completa, limpeza de todos os componentes, troca da pasta térmica do processador e thermal pads quando necessário."}]}, {"type": "paragraph", "children": [{"text": "Troca da fonte de alimentação: R$400 a R$700. A fonte do PS5 é um componente caro. O valor depende se usamos uma fonte original ou uma fonte compatível de alta qualidade."}]}, {"type": "paragraph", "children": [{"text": "Reparo do leitor de disco: R$300 a R$500. Inclui limpeza da lente, ajuste do mecanismo ou troca completa do leitor em casos mais graves."}]}, {"type": "paragraph", "children": [{"text": "Troca do SSD interno: R$250 a R$400 (apenas mão de obra). O valor do SSD é à parte e varia conforme a capacidade escolhida."}]}, {"type": "heading", "children": [{"text": "Por que os preços variam?"}]}, {"type": "paragraph", "children": [{"text": "O custo final depende de três fatores: gravidade do dano, disponibilidade de peças e se serão usadas peças originais ou compatíveis. Na Virtual Games, sempre apresentamos um orçamento detalhado antes de iniciar qualquer serviço."}]}]	[{"answer": "Sim! O diagnóstico e orçamento são totalmente gratuitos e sem compromisso. Você só paga se autorizar o serviço.", "question": "O orçamento é realmente grátis?"}, {"answer": "Reparos simples como limpeza levam 1 dia. Trocas de HDMI ou fonte levam de 2 a 3 dias. Reparos complexos podem levar até 5 dias.", "question": "Quanto tempo leva o conserto?"}, {"answer": "Priorizamos peças originais Sony sempre que disponíveis. Quando não estão disponíveis, usamos peças compatíveis de alta qualidade com garantia.", "question": "Usam peças originais?"}, {"answer": "Sim! Todos os nossos reparos têm garantia de 90 dias. Se o mesmo problema voltar dentro deste período, reparamos sem custo adicional.", "question": "Oferecem garantia no serviço?"}]	/servicos/manutencao-ps5	5	t
422053d4-1182-428b-adad-418ce9fd95c7	PS5 Não Liga: O Que Pode Ser e Como Resolver	ps5-nao-liga-como-resolver	PS5 Não Liga? Principais Causas e Soluções - Guia Completo	Seu PS5 não liga? Descubra as causas mais comuns (fonte, superaquecimento, curto) e como resolver. Assistência técnica especializada em Santa Maria RS.	\N	PS5 que não liga com tela preta	Consoles	2026-05-17 14:24:26.636	2026-05-17 14:24:26.636	2026-05-17 14:24:26.636	2245169a-98be-45a0-a2f0-f4e57aa1b2ec	PS5 não liga? Não entre em pânico. Listamos todas as causas possíveis e suas soluções, desde problemas simples que você resolve em casa até casos que precisam de assistência técnica.	[{"type": "paragraph", "children": [{"text": "Poucas coisas são mais frustrantes do que apertar o botão power do PS5 e... nada acontecer. Antes de entrar em desespero, saiba que muitas causas têm solução simples. Vamos listar todas as possibilidades em ordem da mais simples para a mais complexa."}]}, {"type": "heading", "children": [{"text": "Verificações Simples (faça primeiro)"}]}, {"type": "list", "children": [{"text": "Verifique se o cabo de força está bem conectado nas duas pontas"}, {"text": "Teste outra tomada para descartar problemas elétricos"}, {"text": "Verifique se o LED da fonte acende brevemente ao conectar"}, {"text": "Tente ligar pelo controle e pelo botão físico do console"}, {"text": "Remova todos os cabos USB e acessórios conectados"}]}, {"type": "heading", "children": [{"text": "Problemas na Fonte de Alimentação"}]}, {"type": "paragraph", "children": [{"text": "A fonte é o componente que mais falha quando o PS5 não liga. Se você não ouve nenhum som e nenhum LED acende, a fonte provavelmente queimou. Isso pode acontecer por picos de energia, raios ou simples desgaste do componente."}]}, {"type": "paragraph", "children": [{"text": "Um sinal típico de problema na fonte é quando o console emite um som de clique mas não liga. Isso indica que a fonte está tentando iniciar mas não consegue manter a tensão necessária."}]}, {"type": "heading", "children": [{"text": "Curto-circuito na Placa-Mãe"}]}, {"type": "paragraph", "children": [{"text": "Se o PS5 liga por alguns segundos e desliga imediatamente (luz azul pisca e apaga), pode ser um curto em algum componente da placa-mãe. Isso geralmente é causado por danos físicos, líquidos derramados ou falha de componentes."}]}, {"type": "paragraph", "children": [{"text": "Componentes comuns que entram em curto: capacitores da linha de alimentação, o próprio processador APU ou módulos de memória RAM. Este tipo de reparo requer diagnóstico com equipamentos especializados."}]}]	[{"answer": "Não recomendamos. Testar fontes requer equipamento específico e conhecimento técnico. Uma fonte com defeito pode causar choque elétrico. Traga para avaliação gratuita.", "question": "Posso testar a fonte em casa?"}, {"answer": "Na maioria dos casos, sim! Geralmente apenas a fonte queima e pode ser substituída. Traga para diagnóstico - só cobramos se houver reparo.", "question": "PS5 queimou na tempestade, tem conserto?"}, {"answer": "Entre R$400 e R$700 dependendo se usamos fonte original ou compatível de alta qualidade. O diagnóstico é gratuito.", "question": "Quanto custa trocar a fonte do PS5?"}]	/servicos/manutencao-ps5	5	t
d22a603a-8f53-4add-8dc0-4974c692c540	Drift no Controle PS5: Tem Conserto? Quanto Custa?	drift-controle-ps5-conserto-custo	Drift no Controle DualSense PS5: Tem Conserto? Preço e Solução	Drift no analógico do controle PS5 DualSense? Saiba o que causa, se tem conserto, quanto custa o reparo e como resolver em Santa Maria RS.	\N	Controle DualSense PS5 com drift no analógico	Controles e Acessórios	2026-05-17 14:24:26.638	2026-05-17 14:24:26.638	2026-05-17 14:24:26.638	2245169a-98be-45a0-a2f0-f4e57aa1b2ec	O temido drift no analógico do DualSense é um problema frustrante. Felizmente, TEM CONSERTO e não é necessário comprar um controle novo. Descubra as causas e quanto custa o reparo.	[{"type": "paragraph", "children": [{"text": "O drift no analógico é quando seu personagem se move sozinho ou a câmera gira sem você encostar no controle. Este problema afeta milhares de controles DualSense e pode arruinar completamente a experiência de jogo. Mas a boa notícia é que tem solução."}]}, {"type": "heading", "children": [{"text": "O que causa o drift no DualSense?"}]}, {"type": "paragraph", "children": [{"text": "O drift é causado principalmente pelo desgaste dos potenciômetros dentro dos módulos analógicos. Estes componentes são pequenas peças eletromecânicas que medem a posição do stick. Com o uso contínuo, o material interno se desgasta, causando leituras imprecisas."}]}, {"type": "paragraph", "children": [{"text": "Poeira e sujeira também são grandes vilões. Partículas minúsculas podem entrar no mecanismo do analógico e interferir nos contatos elétricos, causando movimentos fantasmas. Ambientes com muita poeira ou o hábito de comer enquanto joga aceleram este problema."}]}, {"type": "heading", "children": [{"text": "Tem conserto?"}]}, {"type": "paragraph", "children": [{"text": "SIM, tem conserto! Existem basicamente três níveis de reparo para drift no DualSense. O primeiro é a limpeza profunda dos potenciômetros com álcool isopropílico e ar comprimido. Este método resolve cerca de 40% dos casos de drift leve."}]}, {"type": "paragraph", "children": [{"text": "O segundo nível é a troca dos potenciômetros, que são componentes individuais dentro do módulo analógico. Este é um reparo mais técnico que requer soldagem de precisão. Resolve aproximadamente 90% dos casos."}]}, {"type": "paragraph", "children": [{"text": "O terceiro e mais definitivo é a troca completa do módulo analógico por um novo. Este procedimento substitui todo o mecanismo do stick, garantindo zero drift e a mesma sensação de um controle novo."}]}, {"type": "heading", "children": [{"text": "Quanto custa o reparo?"}]}, {"type": "paragraph", "children": [{"text": "Os preços variam conforme o tipo de reparo. Uma limpeza profissional custa entre R$60 e R$100. A troca dos potenciômetros fica entre R$100 e R$150 por analógico. A troca completa do módulo analógico custa entre R$130 e R$180 por stick."}]}, {"type": "paragraph", "children": [{"text": "Considerando que um DualSense novo custa entre R$350 e R$450, o reparo é sempre a opção mais econômica. Além disso, após o reparo com peças de qualidade, o controle pode durar ainda mais que um novo."}]}]	[{"answer": "A limpeza leva de 30 minutos a 1 hora. A troca de potenciômetros ou módulo leva de 1 a 2 horas. Na Virtual Games, muitos reparos são feitos no mesmo dia.", "question": "Quanto tempo leva para consertar o drift?"}, {"answer": "Quando feito corretamente com peças de qualidade, o reparo é duradouro. Nossos serviços têm garantia de 90 dias. Se voltar dentro deste período, reparamos sem custo adicional.", "question": "O drift volta depois do conserto?"}, {"answer": "O conserto custa entre R$60 e R$180, enquanto um controle novo custa R$350+. O reparo é sempre a opção mais econômica, especialmente se o resto do controle está em bom estado.", "question": "Vale a pena consertar ou comprar um novo?"}, {"answer": "Sim! Trabalhamos com todos os controles: Xbox Series, Nintendo Switch (Joy-Con e Pro Controller), DualShock 4 (PS4) e controles de terceiros.", "question": "Consertam drift de outros controles também?"}]	/servicos/reparo-controle-drift	6	t
cmpd9tmcm0006zdl2h4fo1acj	Xbox Series S vs Xbox Series X: Qual console da Microsoft escolher?	xbox-series-s-vs-xbox-series-x-qual-console-da-microsoft-escolher	Xbox Series S vs Xbox Series X: Qual console da Microsoft escolher?	Entenda as diferenças entre Xbox Series S e Series X em desempenho, armazenamento, preço e descubra qual é o melhor para você.	\N	\N	Comparativos	2026-05-19 23:35:27.332	2026-05-19 23:35:27.334	2026-05-19 23:35:27.334	cmpd9tmak0000zdl2ul4uefpw	Entenda as diferenças entre Xbox Series S e Series X em desempenho, armazenamento, preço e descubra qual é o melhor para você.	[{"type": "paragraph", "children": [{"text": "A Microsoft lançou duas versões do seu console de nona geração: o Xbox Series X, mais potente e caro, e o Xbox Series S, mais acessível e compacto. Ambos rodam os mesmos jogos, mas com diferenças importantes."}]}, {"type": "paragraph", "children": [{"text": "O Xbox Series X é um console de alto desempenho com 12 TFLOPS de poder gráfico, 1 TB de armazenamento SSD e leitor de disco 4K. Ele é capaz de rodar jogos em 4K nativo a 60 fps, com suporte a ray tracing e taxas de até 120 fps em títulos otimizados."}]}, {"type": "paragraph", "children": [{"text": "O Xbox Series S é totalmente digital e mais compacto. Com 4 TFLOPS, 512 GB ou 1 TB de SSD, ele foca em resolução 1440p (podendo chegar a 4K upscaling) e roda os mesmos jogos do Series X, mas com gráficos reduzidos e sem leitor de disco."}]}, {"type": "paragraph", "children": [{"text": "Na prática, a diferença é clara: o Series X entrega a experiência completa em 4K, enquanto o Series S é uma porta de entrada acessível para o ecossistema Xbox e Game Pass. O Series S é ideal para quem tem TV Full HD ou 1440p e não se importa em abrir mão do disco físico."}]}, {"type": "paragraph", "children": [{"text": "Com a recente atualização do Series S com 2 TB de armazenamento, a Microsoft oferece ainda mais opções para diferentes orçamentos."}]}, {"type": "paragraph", "children": [{"text": "Ambos os consoles têm acesso ao Game Pass Ultimate, que dá centenas de jogos por uma assinatura mensal, incluindo lançamentos day one da Microsoft e da Activision Blizzard."}]}, {"type": "paragraph", "children": [{"text": "Conclusão: escolha o Series X se você tem uma TV 4K e quer a máxima performance. Escolha o Series S se quer entrar no ecossistema Xbox gastando menos."}]}]	[{"a": "Sim, roda todos os mesmos jogos, porém em resolução mais baixa (1440p em vez de 4K) e sem leitor de disco.", "q": "O Xbox Series S roda todos os jogos do Series X?"}, {"a": "Sim, especialmente para quem assina Game Pass e não joga em TV 4K. É o console de maior custo-benefício da atual geração.", "q": "Vale a pena comprar o Series S em 2025?"}]	\N	5	t
54be21af-94d8-4dba-8491-3474656e07e7	Porta HDMI do PS5 Sem Sinal: Causas e Solução	porta-hdmi-ps5-sem-sinal	Porta HDMI PS5 Sem Sinal? Causas e Como Resolver - Virtual Games	PS5 sem imagem na TV? Porta HDMI quebrada ou com mal contato? Saiba as causas e como consertar. Reparo de HDMI PS5 em Santa Maria RS.	\N	\N	Consoles	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	f573ec9e-ec58-4100-b634-4dc00ad8fbb1	HDMI do PS5 sem sinal é um dos problemas mais comuns. Pode ser desde um simples mau contato até a necessidade de troca completa da porta. Saiba como diagnosticar e resolver.	[{"type": "paragraph", "children": [{"text": "Ligou o PS5, ele acende a luz azul, mas a TV não mostra nada? O problema de HDMI sem sinal é extremamente comum e pode ter várias causas. Felizmente, a maioria delas tem solução."}]}, {"type": "heading", "children": [{"text": "Verificações Rápidas"}]}, {"type": "paragraph", "children": [{"text": "Antes de levar para assistência, teste o cabo HDMI em outro dispositivo, experimente outra porta HDMI da TV e verifique se o console está na resolução correta."}]}, {"type": "heading", "children": [{"text": "Quando é necessário trocar a porta HDMI"}]}, {"type": "paragraph", "children": [{"text": "Se os pinos internos estão tortos ou quebrados, a substituição da porta é inevitável. Realizamos este reparo com equipamento profissional, garantindo solda perfeita e funcionamento duradouro."}]}]	[{"answer": "Entre R$250 e R$450 dependendo da extensão do dano. Usamos apenas conectores de alta qualidade.", "question": "Quanto custa trocar a porta HDMI do PS5?"}, {"answer": "De 2 a 3 dias úteis. Temos a maioria das portas HDMI em estoque para agilizar o serviço.", "question": "Quanto tempo leva o reparo?"}]	/servicos/reparo-hdmi-ps5	4	t
28d8d3d2-5317-4f9d-97d4-08796f5a047e	Upgrade de SSD no PS5: Vale a Pena? Guia Completo	upgrade-ssd-ps5-guia-completo	Upgrade de SSD no PS5 em 2026: Vale a Pena? Guia Completo	Guia completo de upgrade de SSD para PS5: compatibilidade, instalação, melhores SSDs NVMe em 2026. Serviço profissional em Santa Maria RS.	\N	\N	Consoles	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	f573ec9e-ec58-4100-b634-4dc00ad8fbb1	Ficando sem espaço no PS5? Fazer upgrade do SSD é a solução. Guia completo sobre compatibilidade, os melhores SSDs de 2026 e como instalar corretamente.	[{"type": "paragraph", "children": [{"text": "O PS5 vem com 825GB de armazenamento, mas apenas 667GB são utilizáveis. Com jogos ocupando 100GB ou mais cada, o espaço acaba rapidamente. A boa notícia é que o PS5 tem um slot M.2 NVMe para expansão."}]}, {"type": "heading", "children": [{"text": "Melhores SSDs para PS5 em 2026"}]}, {"type": "paragraph", "children": [{"text": "WD Black SN850X, Samsung 990 Pro, Corsair MP600 PRO e Kingston Fury Renegade são as melhores opções. Todos precisam ter velocidade de leitura acima de 5.500MB/s e dissipador de calor compatível."}]}]	[{"answer": "SSDs NVMe M.2 PCIe 4.0 com velocidade de leitura acima de 5.500MB/s. Recomendamos modelos com dissipador de calor integrado.", "question": "Qual SSD é compatível com PS5?"}, {"answer": "Não! A Sony projetou o slot de expansão para ser usado pelo consumidor. A instalação não anula a garantia.", "question": "Instalar SSD perde a garantia do PS5?"}, {"answer": "Sim! Fazemos a instalação profissional com pasta térmica de qualidade nos dissipadores. O serviço leva cerca de 1 hora.", "question": "Vocês instalam SSD?"}]	/servicos/upgrade-ssd-ps5	5	t
9b0f630c-a991-418d-b5de-10349474bbc1	Como Montar um PC Gamer do Zero — Guia para Iniciantes	como-montar-pc-gamer-guia-iniciantes	Como Montar PC Gamer do Zero: Guia Completo para Iniciantes 2026	Guia passo a passo de como montar um PC gamer do zero. Escolha de peças, compatibilidade, montagem e otimização. Serviço profissional em Santa Maria RS.	\N	\N	PC Gamer	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	15678d8d-6091-4642-b77d-11e9e4e87654	Quer montar seu primeiro PC gamer mas não sabe por onde começar? Guia completo com tudo que você precisa saber sobre peças, compatibilidade e montagem.	[{"type": "paragraph", "children": [{"text": "Montar um PC gamer é mais fácil do que parece. Com as peças certas e um pouco de paciência, você pode construir uma máquina potente que roda todos os jogos atuais com qualidade máxima."}]}, {"type": "heading", "children": [{"text": "Escolhendo as Peças"}]}, {"type": "paragraph", "children": [{"text": "O coração do PC gamer é o equilíbrio entre processador e placa de vídeo. Para 2026, recomendamos no mínimo um Ryzen 5 ou Intel i5 de 13ª geração com uma RTX 4060 ou RX 7600 para jogos em 1080p no ultra."}]}]	[{"answer": "Um PC gamer de entrada custa entre R$3.500 e R$5.000. Um intermediário entre R$5.000 e R$8.000. High-end acima de R$12.000.", "question": "Quanto custa montar um PC gamer em 2026?"}, {"answer": "Sim! Você escolhe o orçamento e a finalidade, nós selecionamos as melhores peças, montamos e entregamos testado e pronto para jogar.", "question": "Montam PC gamer sob encomenda?"}]	/servicos/montagem-pc-gamer	6	t
0abb562a-51b5-4e56-b906-dd25bebdebc9	Quanto Custa Montar um PC Gamer em 2026?	quanto-custa-montar-pc-gamer-2026	Quanto Custa Montar um PC Gamer em 2026? Guia por Faixa de Preço	Descubra quanto custa montar um PC gamer em 2026. Guia por faixa de preço: entrada, intermediário e high-end. Orçamento em Santa Maria RS.	\N	\N	PC Gamer	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	15678d8d-6091-4642-b77d-11e9e4e87654	Planejando montar um PC gamer em 2026? Confira quanto custa em cada faixa de preço e quais jogos cada configuração consegue rodar com qualidade.	[{"type": "paragraph", "children": [{"text": "Os preços de hardware têm se mantido estáveis em 2026, com ótimas opções em todas as faixas de preço. Confira nossas recomendações atualizadas."}]}, {"type": "heading", "children": [{"text": "PC Gamer de Entrada — R$3.500 a R$5.000"}]}, {"type": "paragraph", "children": [{"text": "Configuração: Ryzen 5 5600, RTX 4060 ou RX 7600, 16GB DDR4, SSD NVMe 1TB. Roda todos os jogos atuais em 1080p com qualidade alta."}]}, {"type": "heading", "children": [{"text": "PC Gamer Intermediário — R$5.000 a R$8.000"}]}, {"type": "paragraph", "children": [{"text": "Configuração: Ryzen 7 7700X ou i5-14600K, RTX 4070 Super, 32GB DDR5, SSD NVMe 2TB. Roda jogos em 1440p no ultra."}]}]	[{"answer": "Depende do seu uso. PCs são mais caros inicialmente mas jogos são mais baratos, não pagam assinatura online e servem para trabalho e estudo. Consoles são mais práticos.", "question": "Vale a pena montar PC em vez de comprar console?"}, {"answer": "Sim! Conte seu orçamento e o que você quer jogar, montamos a melhor configuração possível dentro do seu limite.", "question": "Fazem orçamento personalizado?"}]	/servicos/montagem-pc-gamer	5	t
8f33e224-0f08-4257-9f80-867e78edefd0	PS5 vs Xbox Series X: Qual Comprar em 2026?	ps5-vs-xbox-series-x-qual-comprar-2026	PS5 vs Xbox Series X: Qual Console Comprar em 2026? Comparativo	Comparativo completo PS5 vs Xbox Series X em 2026: preço, exclusivos, desempenho, catálogo. Qual o melhor console para você? Descubra agora.	\N	\N	Comparativos	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	2026-05-17 14:32:45.031	ee6b8943-cd39-4dbd-8921-dd35f7a55b34	Na dúvida entre PS5 e Xbox Series X? Comparamos todos os aspectos: preço, exclusivos, desempenho, serviços e muito mais para você decidir qual console comprar.	[{"type": "paragraph", "children": [{"text": "Três anos após o lançamento, ambos os consoles têm catálogos maduros e preços mais acessíveis. A decisão agora depende mais de preferências pessoais do que de especificações técnicas."}]}, {"type": "heading", "children": [{"text": "Exclusivos: O Diferencial Decisivo"}]}, {"type": "paragraph", "children": [{"text": "O PS5 lidera em exclusivos com God of War Ragnarök, Spider-Man 3, Final Fantasy XVI e Wolverine. Já o Xbox Series X aposta no Game Pass com lançamentos day-one e franquias como Halo, Forza e Starfield."}]}]	[{"answer": "Trabalhamos com ambos! Temos assistência técnica especializada para PS5 e Xbox Series X, com peças em estoque e técnicos certificados.", "question": "Qual console tem melhor suporte técnico em Santa Maria?"}, {"answer": "Ambos são confiáveis. O PS5 tem mais casos de problemas na porta HDMI, enquanto o Xbox Series X tem menos relatos de falhas. Ambos são cobertos pela nossa garantia de 90 dias após reparo.", "question": "Qual console quebra menos?"}]	/servicos/manutencao-ps5	6	t
9d4285e3-9f45-4116-8a15-32e173659ec6	Nintendo Switch OLED vs Lite vs Original: Qual é o Melhor?	nintendo-switch-oled-lite-original-comparativo	Nintendo Switch OLED vs Lite vs Original: Qual Modelo Comprar?	Comparativo Nintendo Switch OLED vs Lite vs Original. Descubra qual modelo é ideal para você em 2026. Assistência técnica especializada em Santa Maria.	\N	\N	Nintendo	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2245169a-98be-45a0-a2f0-f4e57aa1b2ec	Três modelos de Nintendo Switch disponíveis em 2026. Comparamos tela, bateria, portabilidade e preço para ajudar você a escolher o melhor Switch para seu estilo de jogo.	[{"type": "paragraph", "children": [{"text": "Com três modelos no mercado, escolher o Nintendo Switch certo pode ser confuso. Cada versão atende a um perfil diferente de jogador."}]}, {"type": "heading", "children": [{"text": "Nintendo Switch OLED — O Premium"}]}, {"type": "paragraph", "children": [{"text": "Tela OLED de 7 polegadas vibrante, 64GB internos, dock com porta LAN e melhor áudio. Ideal para quem joga principalmente no modo portátil."}]}, {"type": "heading", "children": [{"text": "Nintendo Switch Original — O Clássico"}]}, {"type": "paragraph", "children": [{"text": "Tela LCD de 6.2 polegadas, 32GB internos, bateria de 4-9 horas. Melhor custo-benefício para quem joga na TV."}]}]	[{"answer": "Sim! Reparamos todos os modelos: tela quebrada, drift nos Joy-Con, bateria, conector de carga e problemas na placa-mãe.", "question": "Consertam Nintendo Switch?"}, {"answer": "Drift nos Joy-Con é o mais frequente, seguido de tela quebrada e problemas no conector USB-C. Todos têm reparo aqui.", "question": "Qual o problema mais comum no Switch?"}]	/servicos/manutencao-nintendo-switch	5	t
7b92637d-2987-40b9-9c3b-fbd5e8d059af	Xbox Series X Não Lê Disco: Causas e Solução	xbox-series-x-nao-le-disco	Xbox Series X Não Lê Disco? Causas e Como Resolver em 2026	Xbox Series X não lê disco de jeito nenhum? Veja as causas mais comuns e como resolver. Reparo de leitor de disco Xbox em Santa Maria RS.	\N	\N	Xbox	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	f573ec9e-ec58-4100-b634-4dc00ad8fbb1	Seu Xbox Series X parou de ler discos? De forma surpreendente, este problema é mais comum do que parece. Descubra as causas e como resolver definitivamente.	[{"type": "paragraph", "children": [{"text": "O leitor de disco do Xbox Series X é um componente de precisão que pode apresentar falhas por diversos motivos."}]}, {"type": "heading", "children": [{"text": "Causas do Problema"}]}, {"type": "paragraph", "children": [{"text": "Poeira na lente, desgaste do mecanismo de tração, falha na placa controladora do drive e até atualizações de sistema problemáticas podem causar falhas de leitura."}]}, {"type": "heading", "children": [{"text": "Soluções"}]}, {"type": "paragraph", "children": [{"text": "Limpeza da lente com álcool isopropílico resolve casos leves. Problemas mecânicos exigem desmontagem e substituição de peças. Falhas eletrônicas podem precisar de reparo na placa controladora."}]}]	[{"answer": "O conserto custa entre R$300 e R$500. Considere que jogos em disco podem ser revendidos e emprestados, o que não acontece com digitais.", "question": "Vale a pena consertar o leitor ou comprar jogos digitais?"}, {"answer": "Na maioria sim, mas às vezes o problema está na placa-mãe. Nosso diagnóstico completo identifica a causa exata antes do reparo.", "question": "Troca do leitor resolve 100% dos casos?"}]	/servicos/manutencao-xbox	4	t
12814fd0-c6dc-4a44-bd63-3fda80e11113	Limpeza Preventiva de Console: Por Que É Essencial?	limpeza-preventiva-console-essencial	Limpeza Preventiva de Console: Por Que É Essencial para seu Videogame	Limpeza preventiva de console previne superaquecimento e prolonga vida útil. Saiba por que é essencial e quando fazer. Serviço profissional em Santa Maria.	\N	\N	Consoles	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2245169a-98be-45a0-a2f0-f4e57aa1b2ec	Você sabia que a falta de limpeza é a causa número 1 de falhas em consoles? A limpeza preventiva regular pode evitar reparos caros e prolongar a vida útil do seu videogame.	[{"type": "paragraph", "children": [{"text": "Assim como um carro precisa de troca de óleo, consoles precisam de limpeza periódica. Poeira acumulada age como um cobertor térmico, retendo calor e forçando componentes a trabalharem em temperaturas perigosas."}]}, {"type": "heading", "children": [{"text": "Benefícios da Limpeza Preventiva"}]}, {"type": "paragraph", "children": [{"text": "Redução da temperatura em até 15°C, ventoinha mais silenciosa, maior vida útil dos componentes, prevenção de falhas catastróficas e economia a longo prazo evitando reparos caros."}]}, {"type": "heading", "children": [{"text": "Quando Fazer a Limpeza?"}]}, {"type": "paragraph", "children": [{"text": "Recomendamos limpeza a cada 12 meses para uso normal. Em ambientes com animais de estimação, fumantes ou muita poeira, a cada 6 meses."}]}]	[{"answer": "A cada 12 meses em ambientes normais, a cada 6 meses se tem pets, fuma ou mora em local com muita poeira.", "question": "De quanto em quanto tempo preciso limpar meu console?"}, {"answer": "Quase sempre! Ventoinha barulhenta é sinal de esforço extra para resfriar. Após limpeza e troca de pasta térmica, o console fica muito mais silencioso.", "question": "A limpeza resolve o barulho da ventoinha?"}]	/servicos/limpeza-preventiva	5	t
8e937c4a-4064-47d9-adca-20e586fd25b7	Controle Xbox com Drift: Como Resolver?	controle-xbox-drift-como-resolver	Controle Xbox Series com Drift? Causas, Conserto e Preço em 2026	Drift no controle Xbox Series? Descubra as causas, quanto custa o conserto e como resolver. Reparo profissional de controles Xbox em Santa Maria RS.	\N	\N	Controles e Acessórios	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	f573ec9e-ec58-4100-b634-4dc00ad8fbb1	O drift no controle do Xbox Series é frustrante, mas tem solução. Explicamos as causas e como consertar sem precisar comprar um controle novo.	[{"type": "paragraph", "children": [{"text": "O controle do Xbox Series também sofre com drift nos analógicos. Embora menos frequente que no DualSense, o problema existe e tem as mesmas causas."}]}, {"type": "heading", "children": [{"text": "Causas e Soluções"}]}, {"type": "paragraph", "children": [{"text": "As causas são as mesmas de outros controles: desgaste dos potenciômetros, acúmulo de sujeira e oxidação dos contatos. A boa notícia é que o reparo segue o mesmo princípio e tem a mesma eficácia."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, reparamos controles de Xbox com as mesmas técnicas e qualidade que aplicamos nos controles de PS5. Oferecemos garantia de 90 dias em todos os serviços."}]}]	[{"answer": "Sim! Os princípios são os mesmos e usamos peças de reposição de igual qualidade. Ambos têm garantia de 90 dias.", "question": "O reparo do controle Xbox é igual ao do PS5?"}, {"answer": "Limpeza: R$60 a R$100. Troca de potenciômetros: R$100 a R$150. Troca do módulo: R$130 a R$180. Sempre mais barato que um controle novo.", "question": "Quanto custa consertar drift no controle Xbox?"}]	/servicos/reparo-controle-drift	4	t
051d8ce5-7cb1-4cb1-afdf-f2a6cef768de	Melhores Jogos de PS5 em 2026 para Começar	melhores-jogos-ps5-2026	13 Melhores Jogos de PS5 em 2026: Lista Definitiva	Os melhores jogos de PS5 em 2026: exclusivos, multi-plataforma e indies imperdíveis. Do iniciante ao hardcore, veja quais jogos valem a pena.	\N	\N	Jogos	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	15678d8d-6091-4642-b77d-11e9e4e87654	Se você acabou de comprar um PS5 ou quer expandir sua biblioteca, confira nossa lista dos melhores jogos disponíveis em 2026 organizados por categoria.	[{"type": "paragraph", "children": [{"text": "2026 chegou com um catálogo impressionante para o PS5. Selecionamos os 13 jogos imperdíveis divididos por categoria."}]}, {"type": "heading", "children": [{"text": "Top 5 Exclusivos"}]}, {"type": "paragraph", "children": [{"text": "God of War Ragnarök, Spider-Man 3, Final Fantasy XVI, Horizon Forbidden West e Wolverine são os exclusivos que todo dono de PS5 precisa experimentar."}]}, {"type": "heading", "children": [{"text": "Top 5 Multi-plataforma"}]}, {"type": "paragraph", "children": [{"text": "GTA VI, Elden Ring, Call of Duty: Black Ops 6, EA Sports FC 26 e Baldur's Gate 3 são os melhores jogos disponíveis em todas as plataformas."}]}]	[{"answer": "Nosso foco é assistência técnica e montagem de PCs, mas podemos recomendar as melhores lojas de games em Santa Maria.", "question": "Vendem jogos na Virtual Games?"}, {"answer": "Pode ser superaquecimento ou problema no SSD. Traga para diagnóstico gratuito e identificamos a causa em minutos.", "question": "PS5 está com problema para rodar jogos pesados?"}]	\N	5	t
4ce7ed49-7127-4fc5-811b-cd2a02c3f357	Assistência Técnica de Games em Santa Maria: Guia Completo	assistencia-tecnica-games-santa-maria-guia	Assistência Técnica de Videogames em Santa Maria RS — Guia Completo	Guia completo de assistência técnica de videogames em Santa Maria RS: PS5, Xbox, Nintendo Switch, PC Gamer. Diagnóstico grátis, garantia 90 dias, orçamento em 24h.	\N	\N	Institucional	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	2026-05-17 14:34:47.269	ee6b8943-cd39-4dbd-8921-dd35f7a55b34	Tudo que você precisa saber sobre assistência técnica de videogames em Santa Maria: quais serviços oferecemos, quanto custa, quanto tempo leva e por que escolher a Virtual Games.	[{"type": "paragraph", "children": [{"text": "Procurando assistência técnica de videogames em Santa Maria RS? A Virtual Games é referência em reparos de consoles e PCs gamer na cidade desde 2010. Confira nosso guia completo."}]}, {"type": "heading", "children": [{"text": "Serviços Oferecidos"}]}, {"type": "paragraph", "children": [{"text": "Reparamos PlayStation (PS3, PS4, PS5), Xbox (360, One, Series), Nintendo (Switch, Wii U, 3DS) e PCs Gamer. Principais reparos: porta HDMI, superaquecimento, fonte, leitor de disco, drift em controles e upgrade de SSD."}]}, {"type": "heading", "children": [{"text": "Por que escolher a Virtual Games?"}]}, {"type": "paragraph", "children": [{"text": "Diagnóstico gratuito, orçamento sem compromisso, garantia de 90 dias em todos os serviços, técnicos certificados, peças de qualidade e atendimento via WhatsApp para sua comodidade."}]}]	[{"answer": "Rua Venâncio Aires, 1244, Centro, Santa Maria RS. Atendemos de segunda a sexta das 9h às 18h e sábados das 9h às 12h.", "question": "Onde fica a Virtual Games?"}, {"answer": "Não é necessário, mas para agilizar, mande uma mensagem no WhatsApp com o modelo do console e o problema. Respondemos com orçamento em até 24h.", "question": "Preciso agendar?"}, {"answer": "Sim! Oferecemos serviço de coleta e entrega em Santa Maria mediante agendamento. Consulte disponibilidade pelo WhatsApp.", "question": "Buscam o console em casa?"}]	/assistencia-tecnica-santa-maria	6	t
cmpd9tmbc0002zdl26qp7xrpv	PS5 Slim vs PS5 Pro: Vale a pena pagar mais pelo modelo Pro?	ps5-slim-vs-ps5-pro-vale-a-pena-pagar-mais-pelo-modelo-pro	PS5 Slim vs PS5 Pro: Vale a pena pagar mais pelo modelo Pro?	Comparamos o PS5 Slim e o PS5 Pro em desempenho, preço e recursos para ajudar você a decidir qual console comprar em 2025.	\N	\N	Comparativos	2026-05-19 23:35:27.285	2026-05-19 23:35:27.289	2026-05-19 23:35:27.289	cmpd9tmak0000zdl2ul4uefpw	Comparamos o PS5 Slim e o PS5 Pro em desempenho, preço e recursos para ajudar você a decidir qual console comprar em 2025.	[{"type": "paragraph", "children": [{"text": "Desde o lançamento do PlayStation 5 Pro, muitos gamers ficaram na dúvida: vale a pena investir a mais no modelo Pro ou o PS5 Slim já atende bem? Neste comparativo, analisamos as principais diferenças entre os dois consoles para ajudar na sua decisão."}]}, {"type": "paragraph", "children": [{"text": "O PS5 Slim é a versão mais compacta e acessível do console da Sony. Com 825 GB de armazenamento interno (cerca de 667 GB utilizáveis), ele é capaz de rodar jogos em 4K a 60 fps na maioria dos títulos, com suporte a ray tracing e tempos de carregamento ultrarrápidos graças ao SSD personalizado."}]}, {"type": "paragraph", "children": [{"text": "O PS5 Pro, por sua vez, traz um salto significativo de performance. Com 28 TFLOPS de poder gráfico (contra os 10,3 TFLOPS do Slim), ele utiliza a tecnologia PSSR (PlayStation Spectral Super Resolution) para alcançar resoluções superiores. O resultado é um verdadeiro 4K a 60 fps com ray tracing ativado na maioria dos jogos, podendo chegar a 120 fps em títulos competitivos."}]}, {"type": "paragraph", "children": [{"text": "Em termos de armazenamento, o PS5 Pro vem com 2 TB de SSD, praticamente o dobro do Slim. Isso significa mais jogos instalados sem precisar ficar gerenciando espaço. Ambos os consoles permitem expansão via SSD NVMe M.2."}]}, {"type": "paragraph", "children": [{"text": "A diferença de preço é significativa: enquanto o PS5 Slim pode ser encontrado a partir de R$ 3.500, o PS5 Pro chega ao mercado por volta de R$ 5.500 a R$ 6.000. A pergunta é: a diferença de performance justifica o investimento?"}]}, {"type": "paragraph", "children": [{"text": "Para gamers que têm uma TV 4K com taxas de atualização altas (120 Hz ou mais) e querem a melhor experiência visual possível em cada jogo, o PS5 Pro é a escolha certa. Jogos como Spider-Man 2, Final Fantasy VII Rebirth e Gran Turismo 7 rodam visivelmente melhores no Pro."}]}, {"type": "paragraph", "children": [{"text": "Por outro lado, se você joga em um monitor Full HD ou 4K padrão (60 Hz) e não se importa em abrir mão de alguns detalhes gráficos, o PS5 Slim entrega uma experiência excelente por um valor mais acessível. A diferença visual em uma TV comum é menos perceptível do que nos vídeos de comparação."}]}, {"type": "paragraph", "children": [{"text": "Conclusão: o PS5 Pro é para os entusiastas que querem o melhor da Sony. O PS5 Slim é a escolha inteligente para quem busca um console de altíssima qualidade sem gastar uma fortuna."}]}]	[{"a": "O PS5 Pro tem suporte teórico para 8K, mas na prática pouquíssimos jogos alcançarão essa resolução. O foco principal é o 4K com altas taxas de quadros e ray tracing de qualidade.", "q": "O PS5 Pro roda jogos em 8K?"}, {"a": "Se você já tem um PS5 Slim e está satisfeito, a troca não é essencial. O Pro faz diferença principalmente para quem tem TVs de alta qualidade e busca o máximo desempenho.", "q": "Vale a pena trocar o PS5 Slim pelo Pro?"}, {"a": "Sim, todos os jogos de PS5 e PS4 são compatíveis com o PS5 Pro. Muitos recebem patches gratuitos de otimização para aproveitar o hardware extra.", "q": "Os jogos do PS5 Slim funcionam no Pro?"}]	\N	6	t
cmpd9tmcb0004zdl20ji1hdee	Nintendo Switch 2 vs Steam Deck: Qual portátil escolher em 2025?	nintendo-switch-2-vs-steam-deck-qual-portatil-escolher-em-2025	Nintendo Switch 2 vs Steam Deck: Qual portátil escolher em 2025?	O Nintendo Switch 2 e o Steam Deck OLED 2 dominam o mercado de portáteis. Comparamos specs, biblioteca de jogos e preço para ajudar na escolha.	\N	\N	Comparativos	2026-05-19 23:35:27.319	2026-05-19 23:35:27.323	2026-05-19 23:35:27.323	cmpd9tmak0000zdl2ul4uefpw	O Nintendo Switch 2 e o Steam Deck OLED 2 dominam o mercado de portáteis. Comparamos specs, biblioteca de jogos e preço para ajudar na escolha.	[{"type": "paragraph", "children": [{"text": "O ano de 2025 trouxe dois gigantes no mercado de consoles portáteis: o Nintendo Switch 2 e o Steam Deck OLED 2. Ambos são excelentes, mas atendem a perfis de jogador muito diferentes. Vamos às comparações."}]}, {"type": "paragraph", "children": [{"text": "O Nintendo Switch 2 chega com uma tela OLED de 8 polegadas com resolução 1080p e taxa de atualização de 120 Hz. Seu grande trunfo é o formato híbrido: funciona como portátil e como console de mesa. O catálogo inclui os exclusivos da Nintendo como Mario Kart World, Zelda e Pokémon, além de total retrocompatibilidade com os jogos do Switch original."}]}, {"type": "paragraph", "children": [{"text": "O Steam Deck OLED 2 é um PC portátil. Com tela OLED de 90 Hz, processador AMD Zen 4 com gráficos RDNA 3 e bateria de 8.000 mAh, ele roda praticamente qualquer jogo de PC da Steam, inclusive títulos AAA como Cyberpunk 2077 e Black Myth: Wukong em configurações médias a altas."}]}, {"type": "paragraph", "children": [{"text": "Em termos de performance bruta, o Steam Deck OLED 2 leva vantagem. Ele é capaz de rodar jogos mais pesados e oferece acesso a bibliotecas de várias lojas (Steam, Epic, Game Pass). Porém, exige mais configurações e conhecimento técnico."}]}, {"type": "paragraph", "children": [{"text": "O Switch 2 é mais simples e direto. Você liga e joga. A Nintendo cuida da experiência do usuário com uma interface intuitiva e jogos otimizados para o hardware. A bateria também dura mais até 8 horas contra 5 a 7 horas do Steam Deck."}]}, {"type": "paragraph", "children": [{"text": "Quanto ao preço, o Switch 2 custa entre US$ 399 e US$ 449, enquanto o Steam Deck OLED 2 sai por US$ 599. No Brasil, a diferença é ainda maior devido à importação."}]}, {"type": "paragraph", "children": [{"text": "Conclusão: se você quer jogar os exclusivos da Nintendo e prefere simplicidade, vá de Switch 2. Se quer um PC portátil para jogar sua biblioteca Steam onde quiser, o Steam Deck OLED 2 é imbatível."}]}]	[{"a": "Não oficialmente. É possível usar emuladores, mas a Nintendo combate ativamente essa prática e pode haver questões legais envolvidas.", "q": "O Steam Deck roda jogos do Switch?"}, {"a": "O Nintendo Switch 2 tem melhor autonomia de bateria, chegando a até 8 horas de jogo contra 5 a 7 horas do Steam Deck OLED 2.", "q": "Qual tem melhor bateria?"}]	\N	5	t
cmpd9tmcw0008zdl2xi2oc1e0	PS5 vs Xbox Series X: Qual console comprar em 2025?	ps5-vs-xbox-series-x-qual-console-comprar-em-2025	PS5 vs Xbox Series X: Qual console comprar em 2025?	Comparação definitiva entre PlayStation 5 e Xbox Series X: jogos exclusivos, performance, serviços de assinatura e preço.	\N	\N	Comparativos	2026-05-19 23:35:27.342	2026-05-19 23:35:27.344	2026-05-19 23:35:27.344	cmpd9tmak0000zdl2ul4uefpw	Comparação definitiva entre PlayStation 5 e Xbox Series X: jogos exclusivos, performance, serviços de assinatura e preço.	[{"type": "paragraph", "children": [{"text": "A rivalidade entre PlayStation e Xbox continua mais acirrada do que nunca em 2025. Ambos os consoles são extremamente competentes, mas cada um tem seus pontos fortes que atendem a diferentes perfis de jogador."}]}, {"type": "paragraph", "children": [{"text": "O PS5 Slim e o PS5 Pro oferecem jogos exclusivos aclamados como Spider-Man 2, God of War Ragnarok, Final Fantasy VII Rebirth e The Last of Us. O controle DualSense é um diferencial imersivo, com gatilhos adaptáveis e resposta háptica que poucos jogos no Xbox aproveitam."}]}, {"type": "paragraph", "children": [{"text": "O Xbox Series X se destaca pelo Game Pass Ultimate, que oferece centenas de jogos por um valor mensal, incluindo lançamentos day one de todos os estúdios da Microsoft e Activision Blizzard. O Quick Resume permite alternar entre vários jogos instantaneamente."}]}, {"type": "paragraph", "children": [{"text": "Em performance bruta, o Xbox Series X tem ligeira vantagem em poder computacional (12 TFLOPS contra 10,3 TFLOPS do PS5 Slim), mas na prática a diferença é imperceptível na maioria dos jogos. O PS5 Pro, porém, supera ambos com seus 28 TFLOPS e tecnologia PSSR."}]}, {"type": "paragraph", "children": [{"text": "O ecossistema de cada um também pesa na decisão. A Sony investe em exclusivos cinematográficos single-player. A Microsoft foca em serviço e multiplataforma, com todos os jogos saindo também para PC."}]}, {"type": "paragraph", "children": [{"text": "Em termos de preço, o PS5 Slim e o Xbox Series X estão em patamares similares. O Xbox Series S é a opção mais barata do mercado."}]}, {"type": "paragraph", "children": [{"text": "Conclusão: se você valoriza jogos exclusivos single-player de alta qualidade, escolha PlayStation. Se prefere uma biblioteca enorme por assinatura e joga em várias plataformas, Xbox é a melhor escolha."}]}]	[{"a": "O Xbox Series X tem mais poder bruto (12 TFLOPS), mas o PS5 Pro (28 TFLOPS) é o console mais potente disponível atualmente.", "q": "Qual console é mais potente?"}, {"a": "Sim, muitos gamers optam por ter ambos para aproveitar os exclusivos de cada plataforma e escolher onde comprar jogos multiplataforma.", "q": "Vale a pena ter os dois consoles?"}]	\N	6	t
cmpd9tmd6000azdl22dzhbysw	Controle Original vs Controle Genérico: Qual comprar?	controle-original-vs-controle-generico-qual-comprar	Controle Original vs Controle Genérico: Qual comprar?	Comparamos controles originais de PS5, Xbox e Switch contra opções genéricas e de terceiros. Veja qual vale mais a pena.	\N	\N	Comparativos	2026-05-19 23:35:27.353	2026-05-19 23:35:27.354	2026-05-19 23:35:27.354	cmpd9tmak0000zdl2ul4uefpw	Comparamos controles originais de PS5, Xbox e Switch contra opções genéricas e de terceiros. Veja qual vale mais a pena.	[{"type": "paragraph", "children": [{"text": "Na hora de comprar um controle extra, surge a dúvida: investir em um controle original ou economizar com um modelo genérico ou de terceiros? A resposta depende do seu orçamento, plataforma e prioridades."}]}, {"type": "paragraph", "children": [{"text": "Os controles originais DualSense do PS5, Xbox Wireless Controller e Joy-Con do Switch oferecem a melhor experiência. O DualSense tem gatilhos adaptáveis e resposta háptica que poucos controles terceirizados replicam. O controle do Xbox é o mais confortável para mãos grandes e tem compatibilidade nativa com PC."}]}, {"type": "paragraph", "children": [{"text": "Os controles de terceiros de qualidade, como os da 8BitDo, Razer Wolverine e PowerA, oferecem boa construção e recursos extras como botões programáveis e paddles traseiros. Eles são ideais para jogadores competitivos que buscam vantagens extras."}]}, {"type": "paragraph", "children": [{"text": "Já os controles genéricos de baixo custo podem ser tentadores pelo preço, mas é preciso ter cuidado. Muitos têm problemas de deadzone nos analógicos, conectividade instável, construção frágil e drift precoce. A economia inicial pode se transformar em dor de cabeça."}]}, {"type": "paragraph", "children": [{"text": "Para uso casual, um controle de terceiros de marca confiável (como 8BitDo ou PowerA) é um bom meio-termo. Para jogadores que passam horas jogando e valorizam precisão, o original é sempre a melhor escolha."}]}, {"type": "paragraph", "children": [{"text": "Importante: ao comprar controles originais, desconfie de preços muito abaixo da média. O mercado de controles falsificados é grande, e a qualidade é muito inferior."}]}]	[{"a": "Depende da marca. Controles de marcas como 8BitDo e PowerA têm boa durabilidade. Já os genéricos sem marca costumam apresentar drift e falhas em poucos meses.", "q": "Controle genérico estraga rápido?"}, {"a": "Não diretamente. É necessário um adaptador como Brook Wingman para usar controle de Xbox no PS5, mas sem suporte a recursos como gatilhos adaptáveis.", "q": "Controle de Xbox funciona no PS5?"}]	\N	5	t
cmpd9tmdi000czdl2ghn613mq	PC Gamer vs Console: Qual plataforma escolher em 2025?	pc-gamer-vs-console-qual-plataforma-escolher-em-2025	PC Gamer vs Console: Qual plataforma escolher em 2025?	Análise completa das vantagens e desvantagens de PC Gamer e consoles para ajudar na sua escolha.	\N	\N	Comparativos	2026-05-19 23:35:27.363	2026-05-19 23:35:27.365	2026-05-19 23:35:27.365	cmpd9tmak0000zdl2ul4uefpw	Análise completa das vantagens e desvantagens de PC Gamer e consoles para ajudar na sua escolha.	[{"type": "paragraph", "children": [{"text": "A eterna dúvida dos gamers: montar um PC Gamer ou comprar um console? Em 2025, ambas as opções são excelentes, mas atendem a necessidades diferentes. Vamos analisar cada aspecto."}]}, {"type": "paragraph", "children": [{"text": "Os consoles oferecem simplicidade: ligou, jogou. Não precisa se preocupar com configurações, drivers ou requisitos mínimos. O custo inicial é mais baixo (um PS5 Slim custa a partir de R$ 3.500) e você tem garantia de que todos os jogos rodarão bem por anos."}]}, {"type": "paragraph", "children": [{"text": "O PC Gamer exige investimento inicial maior (um PC intermediário custa a partir de R$ 5.000), mas oferece vantagens como gráficos superiores, taxas de quadros mais altas, mods, upgrade de componentes e funcionalidades multitarefa. Jogos na Steam costumam ser mais baratos que nas lojas dos consoles."}]}, {"type": "paragraph", "children": [{"text": "O Game Pass está disponível em ambas as plataformas, mas no PC você também tem acesso a serviços como Epic Games Store (com jogos grátis semanais), Steam e lojas de terceiros."}]}, {"type": "paragraph", "children": [{"text": "Para quem joga casualmente e quer praticidade, o console é a melhor escolha. Para entusiastas que buscam máxima performance, personalização e não se importam em aprender sobre hardware, o PC Gamer é imbatível."}]}, {"type": "paragraph", "children": [{"text": "Uma tendência de 2025 são os PCs portáteis como Steam Deck e ROG Ally, que combinam a versatilidade do PC com a portabilidade dos consoles. Eles representam um meio-termo interessante."}]}]	[{"a": "Um PC pode durar mais tempo se você fizer upgrades periódicos. Um console tem vida útil de 6 a 7 anos sem necessidade de upgrade.", "q": "Qual dura mais: PC ou console?"}, {"a": "O investimento inicial é maior, mas os jogos são significativamente mais baratos em promoções da Steam, o que pode compensar a diferença ao longo do tempo.", "q": "Jogar no PC é mais caro que no console?"}]	\N	6	t
cmpd9tme2000ezdl22cdgz54x	Os consoles mais vendidos de todos os tempos	os-consoles-mais-vendidos-de-todos-os-tempos	Os consoles mais vendidos de todos os tempos	Ranking completo dos consoles mais vendidos da história, do PS2 ao Nintendo Switch 2.	\N	\N	Consoles	2026-05-19 23:35:27.384	2026-05-19 23:35:27.386	2026-05-19 23:35:27.386	cmpd9tmak0000zdl2ul4uefpw	Ranking completo dos consoles mais vendidos da história, do PS2 ao Nintendo Switch 2.	[{"type": "paragraph", "children": [{"text": "Você sabe quais são os consoles mais vendidos de todos os tempos? Preparamos um ranking completo para matar a curiosidade e mostrar como o mercado de videogames evoluiu ao longo das décadas."}]}, {"type": "paragraph", "children": [{"text": "1. PlayStation 2 com 155 milhões de unidades. Lançado em 2000, o PS2 reinou absoluto com seu vasto catálogo de jogos e função de DVD player. Até hoje é o console mais vendido da história."}]}, {"type": "paragraph", "children": [{"text": "2. Nintendo DS com 154 milhões. O portátil de tela dupla da Nintendo conquistou públicos de todas as idades com jogos inovadores como Nintendogs e Brain Training."}]}, {"type": "paragraph", "children": [{"text": "3. Nintendo Switch com 141 milhões (e contando). O console híbrido da Nintendo uniu o melhor dos dois mundos e se tornou o terceiro mais vendido da história."}]}, {"type": "paragraph", "children": [{"text": "4. Game Boy / Game Boy Color com 118 milhões. O pioneiro dos portáteis modernos, que apresentou Pokémon ao mundo."}]}, {"type": "paragraph", "children": [{"text": "5. PlayStation 4 com 117 milhões. O console mais vendido da geração anterior, com um catálogo forte de exclusivos."}]}, {"type": "paragraph", "children": [{"text": "6. PlayStation 5 com 92 milhões (e crescendo). Mesmo com desafios de estoque, o PS5 já é o sexto console mais vendido da história."}]}, {"type": "paragraph", "children": [{"text": "7. Nintendo Switch 2 com 20 milhões em apenas seis meses. O novo console da Nintendo teve o lançamento mais rápido da história dos videogames."}]}, {"type": "paragraph", "children": [{"text": "O mercado de consoles continua forte e crescendo. Com o Switch 2 quebrando recordes de vendas e o PS5 ainda em alta, a história dos videogames está longe do fim."}]}]	[{"a": "O console mais vendido da Microsoft é o Xbox 360, com 87 milhões de unidades, seguido pelo Xbox One com 58 milhões.", "q": "O Xbox já apareceu no ranking de mais vendidos?"}, {"a": "Sim, o PlayStation 2 mantém a liderança com 155 milhões de unidades vendidas, seguido de perto pelo Nintendo DS.", "q": "PS2 ainda é o mais vendido?"}]	\N	5	t
cmpd9tmeb000gzdl2sf770an9	Guia completo: Como aumentar a vida útil do seu console	guia-completo-como-aumentar-a-vida-util-do-seu-console	Guia completo: Como aumentar a vida útil do seu console	Dicas práticas de conservação para fazer seu PS5, Xbox ou Switch durar muitos anos.	\N	\N	Consoles	2026-05-19 23:35:27.393	2026-05-19 23:35:27.395	2026-05-19 23:35:27.395	cmpd9tmak0000zdl2ul4uefpw	Dicas práticas de conservação para fazer seu PS5, Xbox ou Switch durar muitos anos.	[{"type": "paragraph", "children": [{"text": "Seu console é um investimento, e com alguns cuidados simples você pode prolongar significativamente a vida útil dele. Reunimos as melhores práticas de conservação para consoles."}]}, {"type": "paragraph", "children": [{"text": "1. Posicionamento adequado: Nunca coloque o console em locais fechados ou com pouca ventilação. O superaquecimento é a principal causa de falhas em consoles modernos. Mantenha pelo menos 15 cm de espaço livre ao redor do aparelho."}]}, {"type": "paragraph", "children": [{"text": "2. Limpeza preventiva regular: A poeira acumulada obstrui as saídas de ar e faz o console trabalhar mais quente. Recomendamos uma limpeza interna a cada 12 meses. Em ambientes com mais poeira, a cada 6 meses."}]}, {"type": "paragraph", "children": [{"text": "3. Troca de pasta térmica: A pasta térmica entre o processador e o dissipador resseca com o tempo. Após 2 a 3 anos de uso, a troca pode reduzir a temperatura do console em até 15 graus."}]}, {"type": "paragraph", "children": [{"text": "4. Cuidado com cabos: Evite puxar cabos pelo fio. Segure sempre pelo conector. A porta HDMI é um dos componentes mais frágeis e mais caros para consertar."}]}, {"type": "paragraph", "children": [{"text": "5. Desligamento correto: Sempre desligue o console pelo menu e aguarde os ventiladores pararem antes de desconectar da tomada. Isso evita danos ao sistema de arquivos e componentes."}]}, {"type": "paragraph", "children": [{"text": "6. Evite quedas de energia: Use um filtro de linha ou nobreak. Quedas de energia podem danificar a fonte e o disco rígido do console."}]}, {"type": "paragraph", "children": [{"text": "7. Controle a umidade: Ambientes muito úmidos podem causar oxidação nos contatos da placa. Evite deixar o console em porões ou locais sujeitos a infiltrações."}]}, {"type": "paragraph", "children": [{"text": "Seguindo essas dicas, seu console pode durar tranquilamente de 7 a 10 anos sem apresentar problemas graves."}]}]	[{"a": "Sim, o modo descanso é seguro e permite atualizações automáticas. Mas uma vez por semana é bom desligar completamente.", "q": "Devo deixar o console ligado em modo descanso?"}, {"a": "Sim, a limpeza preventiva é o cuidado mais importante para a longevidade do console. Poeira acumulada é a principal causa de superaquecimento.", "q": "Limpeza preventiva realmente faz diferença?"}]	\N	6	t
cmpd9tmem000izdl2o5xro0es	Vale a pena comprar um console usado? Guia completo	vale-a-pena-comprar-um-console-usado-guia-completo	Vale a pena comprar um console usado? Guia completo	Tudo o que você precisa verificar antes de comprar um console usado. Dicas para não cair em golpes.	\N	\N	Consoles	2026-05-19 23:35:27.404	2026-05-19 23:35:27.406	2026-05-19 23:35:27.406	cmpd9tmak0000zdl2ul4uefpw	Tudo o que você precisa verificar antes de comprar um console usado. Dicas para não cair em golpes.	[{"type": "paragraph", "children": [{"text": "Comprar um console usado pode ser uma excelente forma de economizar, mas é preciso ter atenção a vários detalhes para não ter dor de cabeça. Preparamos um guia completo."}]}, {"type": "paragraph", "children": [{"text": "Antes de comprar, verifique o estado físico do console: carcaça sem trincas, entradas sem ferrugem, pés de borracha intactos. Consoles com sinais de queda podem ter danos internos imperceptíveis."}]}, {"type": "paragraph", "children": [{"text": "Ligue o console e teste: leitor de disco (se houver), portas USB, entrada HDMI, Wi-Fi, Bluetooth (com um controle), saída de áudio. Verifique se o console não desliga sozinho após alguns minutos de uso."}]}, {"type": "paragraph", "children": [{"text": "Peça para ver o funcionamento por pelo menos 20 minutos. Consoles com superaquecimento podem demorar alguns minutos para apresentar o problema."}]}, {"type": "paragraph", "children": [{"text": "Verifique o controle: todos os botões, analógicos (inclusive testando drift), gatilhos e funções especiais como touchpad e giroscópio."}]}, {"type": "paragraph", "children": [{"text": "Desconfie de preços muito baixos. Consoles com preço muito abaixo da média podem ter problemas ocultos. Consoles sem garantia do vendedor exigem ainda mais cautela."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, oferecemos diagnóstico gratuito para consoles recém-adquiridos. Se você comprou um console usado e quer garantir que está tudo certo, traga para avaliarmos sem custo."}]}]	[{"a": "Com cuidados adequados, um console dura de 7 a 10 anos. Consoles bem conservados podem durar ainda mais.", "q": "Qual a vida útil média de um console?"}, {"a": "Sim, principalmente se não foi bem cuidado. Por isso a verificação prévia é essencial.", "q": "Console usado tem risco de dar problema?"}]	\N	5	t
cmpd9tmes000kzdl2cwtuecm4	Como funciona o diagnóstico gratuito de consoles?	como-funciona-o-diagnostico-gratuito-de-consoles	Como funciona o diagnóstico gratuito de consoles?	Entenda como fazemos o diagnóstico gratuito do seu console e por que você não paga nada para saber o que tem de errado.	\N	\N	Consoles	2026-05-19 23:35:27.411	2026-05-19 23:35:27.412	2026-05-19 23:35:27.412	cmpd9tmak0000zdl2ul4uefpw	Entenda como fazemos o diagnóstico gratuito do seu console e por que você não paga nada para saber o que tem de errado.	[{"type": "paragraph", "children": [{"text": "Na Virtual Games, o diagnóstico de consoles é totalmente gratuito. Mas como funciona esse processo? Explicamos passo a passo."}]}, {"type": "paragraph", "children": [{"text": "Quando você traz seu console até nossa loja em Santa Maria, nosso primeiro passo é ouvir você: qual o problema, quando começou, o que você já tentou fazer. Essas informações são valiosas para direcionar o diagnóstico."}]}, {"type": "paragraph", "children": [{"text": "Em seguida, abrimos o console (quando necessário) e realizamos uma inspeção visual detalhada. Procuramos por sinais de oxidação, capacitores estufados, soldas rompidas e outros problemas visíveis."}]}, {"type": "paragraph", "children": [{"text": "Com equipamentos especializados, testamos a parte elétrica: fonte, tensões, circuitos de alimentação. Para problemas de vídeo, testamos a porta HDMI e o chip de vídeo. Para superaquecimento, medimos temperaturas em funcionamento."}]}, {"type": "paragraph", "children": [{"text": "Após a análise, apresentamos um relatório claro: qual é o problema, o que precisa ser feito para consertar, qual o valor do reparo e o prazo estimado. Tudo explicado em linguagem simples."}]}, {"type": "paragraph", "children": [{"text": "O diagnóstico gratuito é nossa forma de mostrar transparência. Você só paga se autorizar o reparo. E mesmo que decida não consertar conosco, não cobramos nada pela avaliação."}]}, {"type": "paragraph", "children": [{"text": "Essa é uma vantagem enorme em relação a muitas assistências que cobram pelo orçamento. Acreditamos que a confiança vem da transparência."}]}]	[{"a": "Sim, abrimos o console para inspeção interna quando necessário, tudo sem custo.", "q": "O diagnóstico gratuito inclui abertura do console?"}, {"a": "A maioria dos diagnósticos é concluída em até 24h. Casos simples podem ser resolvidos em poucas horas.", "q": "Quanto tempo leva o diagnóstico?"}]	\N	5	t
cmpd9tmex000mzdl2ymdb4lxa	Problemas comuns em consoles e como identificar	problemas-comuns-em-consoles-e-como-identificar	Problemas comuns em consoles e como identificar	Guia para identificar os problemas mais frequentes em PS5, Xbox e Nintendo Switch antes de levar à assistência.	\N	\N	Consoles	2026-05-19 23:35:27.416	2026-05-19 23:35:27.417	2026-05-19 23:35:27.417	cmpd9tmak0000zdl2ul4uefpw	Guia para identificar os problemas mais frequentes em PS5, Xbox e Nintendo Switch antes de levar à assistência.	[{"type": "paragraph", "children": [{"text": "Conhecer os sinais de problemas no seu console pode ajudar a buscar o reparo certo mais rapidamente. Listamos os problemas mais comuns em cada plataforma."}]}, {"type": "paragraph", "children": [{"text": "PS5: O problema mais frequente é a porta HDMI danificada, geralmente causada por puxar o cabo sem segurar o conector. Sintomas: tela preta ou imagem piscando. Outro problema comum é o superaquecimento, que causa desligamentos após 20 a 30 minutos de uso."}]}, {"type": "paragraph", "children": [{"text": "Xbox Series X/S: Superaquecimento e disco que não lê (no Series X) estão entre os problemas mais relatados. O console pode desligar sozinho ou apresentar ruídos no cooler. A limpeza interna e troca de pasta térmica costumam resolver."}]}, {"type": "paragraph", "children": [{"text": "Nintendo Switch: Drift nos Joy-Cons é o problema mais famoso. Os analógicos começam a registrar movimento sem comando. Também são comuns problemas de bateria que não carrega e tela quebrada."}]}, {"type": "paragraph", "children": [{"text": "Em todos os consoles, os sinais de alerta incluem: ruídos anormais (cooler barulhento), superaquecimento, desligamentos aleatórios, lentidão na interface e artefatos gráficos."}]}, {"type": "paragraph", "children": [{"text": "Ao notar qualquer desses sintomas, o ideal é buscar o diagnóstico o quanto antes. Problemas pequenos podem se agravar rapidamente se ignorados."}]}]	[{"a": "Barulho do cooler é normal, mas se estiver muito alto ou irregular, pode indicar acúmulo de poeira ou falha no rolamento do ventilador.", "q": "Console fazendo barulho é normal?"}, {"a": "Sim, desligamentos aleatórios geralmente indicam superaquecimento ou problema na fonte. Quanto antes diagnosticar, menor o risco de danos permanentes.", "q": "Desligamento aleatório indica problema grave?"}]	\N	6	t
cmpd9tmf0000ozdl2c4wi9gwe	Como limpar e cuidar dos seus controles corretamente	como-limpar-e-cuidar-dos-seus-controles-corretamente	Como limpar e cuidar dos seus controles corretamente	Guia prático de limpeza e conservação para controles de PS5, Xbox e Nintendo Switch.	\N	\N	Controles e Acessórios	2026-05-19 23:35:27.419	2026-05-19 23:35:27.42	2026-05-19 23:35:27.42	cmpd9tmak0000zdl2ul4uefpw	Guia prático de limpeza e conservação para controles de PS5, Xbox e Nintendo Switch.	[{"type": "paragraph", "children": [{"text": "Os controles são a parte do console que mais usamos e também a que mais sofre com desgaste. Com alguns cuidados simples, você pode prolongar significativamente a vida útil deles."}]}, {"type": "paragraph", "children": [{"text": "A limpeza regular é essencial. Use um pano de microfibra levemente umedecido com álcool isopropílico (não use álcool comum, que pode danificar o acabamento) para limpar a superfície do controle. Evite que líquidos entrem pelas frestas."}]}, {"type": "paragraph", "children": [{"text": "Os analógicos são a parte mais crítica. Com o tempo, o atrito pode desgastar o mecanismo interno, causando drift. Para prevenir, evite pressionar os analógicos com força excessiva e mantenha as mãos limpas ao jogar."}]}, {"type": "paragraph", "children": [{"text": "A sujeira acumulada nos cantos do controle pode ser removida com um palito de dente ou ferramenta de plástico própria para eletrônicos. Nunca use objetos metálicos que possam arranhar."}]}, {"type": "paragraph", "children": [{"text": "Para limpeza mais profunda, como troca de analógicos com drift, recomendamos procurar uma assistência especializada. A Virtual Games realiza esse serviço com peças de qualidade e garantia de 90 dias."}]}, {"type": "paragraph", "children": [{"text": "Guarde os controles em local seco e arejado. Evite deixá-los expostos ao sol ou em locais úmidos. Se for guardar por muito tempo, remova as pilhas ou baterias."}]}]	[{"a": "Não é recomendado. O álcool 70 tem água na composição, que pode infiltrar no controle. Prefira álcool isopropílico (90% ou superior).", "q": "Pode usar álcool 70 para limpar controle?"}, {"a": "Evite pressionar os analógicos com força, não jogue com as mãos sujas e faça a manutenção preventiva anualmente.", "q": "Como evitar drift nos analógicos?"}]	\N	4	t
cmpd9tmf3000qzdl2tnuo6wdh	Melhores headsets gamers custo-benefício em 2025	melhores-headsets-gamers-custo-beneficio-em-2025	Melhores headsets gamers custo-benefício em 2025	Seleção dos melhores headsets gamers com bom custo-benefício para todas as plataformas.	\N	\N	Controles e Acessórios	2026-05-19 23:35:27.423	2026-05-19 23:35:27.424	2026-05-19 23:35:27.424	cmpd9tmak0000zdl2ul4uefpw	Seleção dos melhores headsets gamers com bom custo-benefício para todas as plataformas.	[{"type": "paragraph", "children": [{"text": "Um bom headset faz toda a diferença na imersão dos jogos e na comunicação com o time. Selecionamos os melhores headsets custo-benefício de 2025."}]}, {"type": "paragraph", "children": [{"text": "1. HyperX Cloud Stinger 2: O clássico custo-benefício. Confortável, som equilibrado e microfone decente por um preço acessível. Funciona em PC, PS5, Xbox e Switch."}]}, {"type": "paragraph", "children": [{"text": "2. Razer BlackShark V2 X: Leve (240g) e com bom isolamento de ruído. Os drivers de 50 mm entregam som com qualidade para jogos competitivos."}]}, {"type": "paragraph", "children": [{"text": "3. Corsair HS55 Surround: Surround 7.1 virtual, construção leve e almofadas de espuma de memória. Ótimo para longas sessões de jogo."}]}, {"type": "paragraph", "children": [{"text": "4. Logitech G435 Lightspeed: Headset sem fio acessível, pesa apenas 165g e tem bateria de 18 horas. Compatível com PC, PlayStation e Nintendo Switch."}]}, {"type": "paragraph", "children": [{"text": "5. JBL Quantum 100: A opção mais barata da lista, mas com som surpreendentemente bom para o preço. Microfone com cancelamento de ruído."}]}, {"type": "paragraph", "children": [{"text": "Na hora de escolher, considere: conforto (almofadas e peso), som (drivers maiores geralmente são melhores), microfone e compatibilidade com sua plataforma."}]}]	[{"a": "Os modelos modernos têm latência imperceptível, principalmente os que usam conexão USB de 2,4 GHz em vez de Bluetooth.", "q": "Headset sem fio tem latência?"}, {"a": "Depende do seu nível de exigência. Para uso casual, headsets de R$ 150 a R$ 300 já entregam boa qualidade.", "q": "Vale a pena investir em headset caro?"}]	\N	5	t
cmpd9tmf6000szdl2no8rxb3k	Guia de compatibilidade de acessórios entre plataformas	guia-de-compatibilidade-de-acessorios-entre-plataformas	Guia de compatibilidade de acessórios entre plataformas	Saiba quais acessórios funcionam entre PS5, Xbox, Nintendo Switch e PC.	\N	\N	Controles e Acessórios	2026-05-19 23:35:27.426	2026-05-19 23:35:27.427	2026-05-19 23:35:27.427	cmpd9tmak0000zdl2ul4uefpw	Saiba quais acessórios funcionam entre PS5, Xbox, Nintendo Switch e PC.	[{"type": "paragraph", "children": [{"text": "Comprar acessórios para múltiplas plataformas pode ser confuso. Organizamos um guia prático de compatibilidade para ajudar."}]}, {"type": "paragraph", "children": [{"text": "Controles: O controle do Xbox funciona nativamente em PC e Xbox. No PS5, funciona apenas via adaptador. O DualSense do PS5 funciona no PC com fio ou Bluetooth, mas sem os recursos avançados de resposta háptica. O Pro Controller do Switch funciona no PC, mas não nos outros consoles."}]}, {"type": "paragraph", "children": [{"text": "Headsets: Headsets com conexão USB ou P2 funcionam em todas as plataformas. Headsets Xbox Wireless funcionam apenas no Xbox e PC. Headsets PlayStation funcionam no PS5, PC e às vezes no Switch via P2."}]}, {"type": "paragraph", "children": [{"text": "Volantes: A maioria dos volantes de marcas como Logitech e Thrustmaster tem compatibilidade multiplataforma, mas verifique o modelo específico."}]}, {"type": "paragraph", "children": [{"text": "Teclado e mouse: Funcionam nativamente em PC e em alguns jogos de PS5 e Xbox. O Nintendo Switch tem suporte limitado via adaptador."}]}, {"type": "paragraph", "children": [{"text": "Dica: acessórios com conexão USB padrão ou P2 tendem a ser mais universais. Para compatibilidade garantida, verifique a caixa do produto ou o site do fabricante."}]}]	[{"a": "Não diretamente. É necessário um adaptador específico como Brook Wingman, e mesmo assim com funcionalidades limitadas.", "q": "Controle de PS5 funciona no Xbox?"}, {"a": "Se for headset com conector P2 de 3,5 mm, sim. Headsets Xbox Wireless não funcionam no PS5.", "q": "Headset de Xbox funciona no PS5?"}]	\N	5	t
cmpd9tmfj000uzdl29up9af7h	Drift nos controles: O que é, causas e soluções definitivas	drift-nos-controles-o-que-e-causas-e-solucoes-definitivas	Drift nos controles: O que é, causas e soluções definitivas	Entenda de uma vez por todas o que causa o drift nos analógicos e como resolver definitivamente.	\N	\N	Controles e Acessórios	2026-05-19 23:35:27.429	2026-05-19 23:35:27.43	2026-05-19 23:35:27.43	cmpd9tmak0000zdl2ul4uefpw	Entenda de uma vez por todas o que causa o drift nos analógicos e como resolver definitivamente.	[{"type": "paragraph", "children": [{"text": "O drift é um dos problemas mais frustrantes para qualquer gamer. O personagem se move sozinho, a câmera gira sem comando e a precisão em jogos competitivos vai por água abaixo."}]}, {"type": "paragraph", "children": [{"text": "O drift acontece quando o sensor do analógico registra movimento mesmo sem o jogador estar tocando no manípulo. Isso ocorre pelo desgaste natural do componente, que acumula partículas de poeira e perde a calibragem com o uso."}]}, {"type": "paragraph", "children": [{"text": "Em controles de PS5 (DualSense), Xbox Series e Joy-Con do Switch, o drift é mais comum devido ao design compacto dos analógicos. O Joy-Con é particularmente suscetível por seu tamanho reduzido."}]}, {"type": "paragraph", "children": [{"text": "Soluções caseiras como soprar ar comprimido ou usar álcool podem dar resultado temporário, mas não resolvem o problema de raiz. A única solução definitiva é a substituição do módulo analógico completo."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, realizamos a troca dos analógicos com solda profissional e calibragem pós-reparo. O serviço inclui garantia de 90 dias: se o drift voltar nesse período, trocamos novamente sem custo."}]}, {"type": "paragraph", "children": [{"text": "Após o reparo, o controle volta a funcionar como novo. Analógicos novos têm deadzone zerada e resposta precisa. Recomendamos trocar ambos os analógicos quando um apresenta drift, pois o outro também está com desgaste avançado."}]}]	[{"a": "Sim, a troca do módulo analógico com calibragem profissional resolve o drift de forma definitiva.", "q": "Drift tem conserto definitivo?"}, {"a": "O reparo de drift no DualSense custa a partir de R$ 120 por analógico, com garantia de 90 dias. Diagnóstico gratuito.", "q": "Quanto custa para consertar drift no PS5?"}]	\N	5	t
cmpd9tmfs000wzdl2u313dj66	Guia de controles: Qual modelo escolher para cada estilo de jogo	guia-de-controles-qual-modelo-escolher-para-cada-estilo-de-jogo	Guia de controles: Qual modelo escolher para cada estilo de jogo	Dos fight sticks aos volantes, saiba qual controle é ideal para cada gênero de jogo.	\N	\N	Controles e Acessórios	2026-05-19 23:35:27.447	2026-05-19 23:35:27.448	2026-05-19 23:35:27.448	cmpd9tmak0000zdl2ul4uefpw	Dos fight sticks aos volantes, saiba qual controle é ideal para cada gênero de jogo.	[{"type": "paragraph", "children": [{"text": "Nem todo controle é igual, e cada gênero de jogo pode se beneficiar de um tipo específico de controle. Veja nosso guia completo."}]}, {"type": "paragraph", "children": [{"text": "Para jogos de luta: Fight sticks (arcade sticks) oferecem precisão superior para comandos especiais e combos. Se preferir controle padrão, opte por modelos com direcional digital preciso (D-pad) como o Xbox Elite ou o DualSense Edge."}]}, {"type": "paragraph", "children": [{"text": "Para jogos de corrida: Volantes com force feedback transformam a experiência. Logitech G29 e Thrustmaster T300 são excelentes opções de entrada."}]}, {"type": "paragraph", "children": [{"text": "Para FPS e jogos competitivos: Controles com paddles traseiros (como Xbox Elite, DualSense Edge ou Scuf) permitem pular, recarregar e agachar sem tirar o polegar do analógico."}]}, {"type": "paragraph", "children": [{"text": "Para jogos de plataforma e ação: O controle padrão do console já é suficiente. O Pro Controller do Nintendo Switch é um dos mais confortáveis para jogos de plataforma."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, você encontra orientação especializada para escolher o acessório ideal para seu estilo de jogo."}]}]	[{"a": "Para jogadores casuais, não. Para quem joga competitivamente e busca vantagens como paddles e botões programáveis, pode fazer diferença.", "q": "Vale a pena comprar um controle profissional?"}, {"a": "Muitos jogadores profissionais preferem fight sticks pela precisão, mas há campeões que usam controle padrão. É uma questão de preferência.", "q": "Fight stick é melhor que controle para jogos de luta?"}]	\N	5	t
cmpd9tmfx000yzdl2x9cn1b5s	Conheça a história da Virtual Games	conheca-a-historia-da-virtual-games	Conheça a história da Virtual Games	Saiba como nasceu a Virtual Games, nossa missão e o que nos motiva a oferecer o melhor serviço de assistência técnica gamer.	\N	\N	Institucional	2026-05-19 23:35:27.452	2026-05-19 23:35:27.454	2026-05-19 23:35:27.454	cmpd9tmak0000zdl2ul4uefpw	Saiba como nasceu a Virtual Games, nossa missão e o que nos motiva a oferecer o melhor serviço de assistência técnica gamer.	[{"type": "paragraph", "children": [{"text": "A Virtual Games nasceu da paixão por games e da dificuldade de encontrar assistência técnica especializada em consoles e PC Gamer em Santa Maria, RS. Fundada por Emerson Gabriel de Mello Graeff, a empresa começou como um serviço entre amigos e se transformou na assistência técnica mais especializada da região."}]}, {"type": "paragraph", "children": [{"text": "Desde 2020, já realizamos mais de 2.000 reparos em consoles e computadores. O que nos motiva é ver cada gamer voltar a jogar com seu equipamento funcionando perfeitamente."}]}, {"type": "paragraph", "children": [{"text": "Nossa equipe é formada por gamers que entendem a urgência de ter o equipamento de volta. Sabemos o que é ficar sem jogar no fim de semana porque o console quebrou. Por isso, trabalhamos com agilidade sem abrir mão da qualidade."}]}, {"type": "paragraph", "children": [{"text": "Nossos valores são simples: transparência no diagnóstico, qualidade nas peças, respeito ao cliente e paixão pelo universo gamer. Não somos uma assistência genérica, somos especialistas em consoles."}]}, {"type": "paragraph", "children": [{"text": "A Virtual Games está localizada na Rua Venâncio Aires, 1434, Torre Divindade, Sala 106 D-2, Centro, Santa Maria. Funcionamos de segunda a sexta das 9h às 18h30 e aos sábados das 9h às 13h."}]}, {"type": "paragraph", "children": [{"text": "Se você ainda não nos conhece, passe na loja ou mande uma mensagem no WhatsApp. Ficaremos felizes em ajudar."}]}]	[{"a": "Desde 2020. Começamos como um serviço entre amigos gamers e nos tornamos referência em assistência técnica em Santa Maria.", "q": "Desde quando a Virtual Games existe?"}, {"a": "Já realizamos mais de 2.000 reparos em consoles, PC Gamer e celulares.", "q": "Quantos reparos a Virtual Games já realizou?"}]	\N	4	t
cmpd9tmg10010zdl2s7oy1vlz	Por que escolher uma assistência técnica especializada?	por-que-escolher-uma-assistencia-tecnica-especializada	Por que escolher uma assistência técnica especializada?	Entenda os riscos de levar seu console para assistências não especializadas e por que a especialização faz diferença.	\N	\N	Institucional	2026-05-19 23:35:27.457	2026-05-19 23:35:27.458	2026-05-19 23:35:27.458	cmpd9tmak0000zdl2ul4uefpw	Entenda os riscos de levar seu console para assistências não especializadas e por que a especialização faz diferença.	[{"type": "paragraph", "children": [{"text": "Muitas pessoas tentam economizar levando seus consoles para assistências técnicas genéricas ou técnicos que trabalham com qualquer tipo de eletrônico. Essa economia pode sair cara."}]}, {"type": "paragraph", "children": [{"text": "Consoles como PS5, Xbox Series e Nintendo Switch têm particularidades que só quem é especialista conhece. A porta HDMI do PS5, por exemplo, tem um padrão de solda específico."}]}, {"type": "paragraph", "children": [{"text": "Uma assistência genérica pode: usar peças incompatíveis, danificar a placa durante o reparo, não identificar corretamente o defeito ou simplesmente piorar o problema. Já recebemos diversos consoles que foram danificados em outras assistências."}]}, {"type": "paragraph", "children": [{"text": "Além disso, assistências especializadas investem em equipamentos próprios: estação de retrabalho para microsoldagem, osciloscópio para diagnóstico de placa, fontes ajustáveis para testes."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, somos especialistas exclusivamente em consoles e PC Gamer. Não fazemos reparo de eletrodomésticos ou equipamentos genéricos. Nosso foco total é no universo gamer."}]}, {"type": "paragraph", "children": [{"text": "Outra vantagem: oferecemos garantia de 90 dias em todos os reparos, enquanto assistências genéricas costumam dar apenas 30 dias. Isso mostra a confiança que temos no nosso trabalho."}]}]	[{"a": "Pode, mas o risco de um reparo mal feito é alto. Consoles exigem conhecimento específico que assistências genéricas não têm.", "q": "Posso levar meu console em qualquer assistência?"}, {"a": "Traga para a Virtual Games. Avaliamos o dano e informamos se há possibilidade de recuperação.", "q": "O que fazer se outra assistência danificou meu console?"}]	\N	5	t
cmpd9tmg50012zdl2xk5mn44c	Como funciona a garantia de 90 dias da Virtual Games	como-funciona-a-garantia-de-90-dias-da-virtual-games	Como funciona a garantia de 90 dias da Virtual Games	Saiba tudo sobre a garantia dos nossos serviços: o que cobre, o que não cobre e como acionar.	\N	\N	Institucional	2026-05-19 23:35:27.46	2026-05-19 23:35:27.461	2026-05-19 23:35:27.461	cmpd9tmak0000zdl2ul4uefpw	Saiba tudo sobre a garantia dos nossos serviços: o que cobre, o que não cobre e como acionar.	[{"type": "paragraph", "children": [{"text": "Na Virtual Games, todos os reparos têm garantia de 90 dias em peças e mão de obra. Esse é nosso compromisso com a qualidade do serviço prestado."}]}, {"type": "paragraph", "children": [{"text": "A garantia cobre: defeitos relacionados ao serviço realizado, falha de peças instaladas durante o reparo e problemas de mão de obra como solda, montagem e configuração."}]}, {"type": "paragraph", "children": [{"text": "A garantia não cobre: danos físicos causados após a retirada do equipamento (queda, impacto, líquido), mau uso, intervenção de terceiros e desgaste natural de componentes não relacionados ao reparo."}]}, {"type": "paragraph", "children": [{"text": "Para acionar a garantia, entre em contato pelo WhatsApp informando o número da sua OS. Traga o equipamento até nossa loja em Santa Maria, reavaliamos e, se for caso de garantia, corrigimos na hora."}]}, {"type": "paragraph", "children": [{"text": "Nosso diferencial: enquanto a maioria das assistências oferece 30 a 90 dias de garantia, nós oferecemos 90 dias para todos os serviços. Isso mostra o nível de confiança no nosso trabalho e na qualidade das peças que usamos."}]}, {"type": "paragraph", "children": [{"text": "Importante: guarde o comprovante da ordem de serviço. Ele é essencial para acionar a garantia."}]}]	[{"a": "Não. Danos físicos causados após a retirada do equipamento não são cobertos pela garantia.", "q": "A garantia cobre queda após o reparo?"}, {"a": "Sim, o número da OS é necessário para localizar seu histórico de reparo.", "q": "Preciso do comprovante para acionar a garantia?"}]	\N	4	t
cmpd9tmg90014zdl2uaamn872	Dicas para escolher uma assistência técnica de confiança	dicas-para-escolher-uma-assistencia-tecnica-de-confianca	Dicas para escolher uma assistência técnica de confiança	Saiba o que observar ao escolher uma assistência técnica para seu console ou PC Gamer.	\N	\N	Institucional	2026-05-19 23:35:27.464	2026-05-19 23:35:27.465	2026-05-19 23:35:27.465	cmpd9tmak0000zdl2ul4uefpw	Saiba o que observar ao escolher uma assistência técnica para seu console ou PC Gamer.	[{"type": "paragraph", "children": [{"text": "Escolher uma assistência técnica para seu console não é tarefa simples. Separamos dicas para fazer a escolha certa."}]}, {"type": "paragraph", "children": [{"text": "1. Especialização: A assistência é especializada em consoles ou é genérica? Quanto mais específico o foco, maior o conhecimento técnico."}]}, {"type": "paragraph", "children": [{"text": "2. Diagnóstico gratuito: Assistências sérias oferecem diagnóstico sem custo. Desconfie de quem cobra apenas para olhar o equipamento."}]}, {"type": "paragraph", "children": [{"text": "3. Transparência: O diagnóstico deve ser claro e explicado em linguagem simples. Você deve saber exatamente qual é o problema antes de autorizar."}]}, {"type": "paragraph", "children": [{"text": "4. Garantia: Toda assistência de qualidade oferece garantia. A média do mercado é de 90 dias. Desconfie de quem não dá garantia nenhuma."}]}, {"type": "paragraph", "children": [{"text": "5. Referências: Procure avaliações no Google e redes sociais. Clientes satisfeitos são o melhor indicador da qualidade do serviço."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, atendemos a todos esses critérios. Temos diagnóstico gratuito, garantia de 90 dias, transparência total e mais de 2.000 reparos realizados."}]}]	[{"a": "Sim, em assistências confiáveis. Na Virtual Games, seu equipamento fica registrado em nosso sistema com OS e você acompanha o status online.", "q": "É seguro deixar o console na assistência?"}, {"a": "Procure o Procon se houver má fé. Se for incompetência técnica, leve a outro profissional.", "q": "O que fazer se a assistência não resolver?"}]	\N	5	t
cmpd9tmgd0016zdl2n4w7m2yt	LGPD e privacidade: Como protegemos seus dados na Virtual Games	lgpd-e-privacidade-como-protegemos-seus-dados-na-virtual-games	LGPD e privacidade: Como protegemos seus dados na Virtual Games	Saiba como a Virtual Games trata seus dados pessoais em conformidade com a Lei Geral de Proteção de Dados.	\N	\N	Institucional	2026-05-19 23:35:27.469	2026-05-19 23:35:27.47	2026-05-19 23:35:27.47	cmpd9tmak0000zdl2ul4uefpw	Saiba como a Virtual Games trata seus dados pessoais em conformidade com a Lei Geral de Proteção de Dados.	[{"type": "paragraph", "children": [{"text": "A privacidade dos nossos clientes é levada a sério na Virtual Games. Em conformidade com a Lei Geral de Proteção de Dados (LGPD, Lei 13.709/2018), adotamos práticas rigorosas para proteger suas informações."}]}, {"type": "paragraph", "children": [{"text": "Coletamos apenas os dados necessários para a prestação dos serviços: nome completo, WhatsApp/telefone, CPF (para nota fiscal e garantia), e-mail (opcional) e informações sobre o equipamento."}]}, {"type": "paragraph", "children": [{"text": "Seus dados são utilizados exclusivamente para: emissão de ordem de serviço, comunicação sobre o andamento do reparo, emissão de nota fiscal, acionamento de garantia e contato para autorização de orçamento."}]}, {"type": "paragraph", "children": [{"text": "Não compartilhamos seus dados com terceiros, exceto quando exigido por lei. Seus dados são armazenados em servidores seguros conforme as exigências legais."}]}, {"type": "paragraph", "children": [{"text": "Você tem direito de acessar, corrigir, excluir seus dados ou revogar consentimento a qualquer momento. Para exercer esses direitos, entre em contato pelo e-mail contato@virtualgames.com."}]}, {"type": "paragraph", "children": [{"text": "Nosso site pode utilizar cookies essenciais para funcionamento. Não utilizamos cookies de rastreamento publicitário."}]}]	[{"a": "Sim, o CPF é necessário para emissão de nota fiscal e registro da garantia. Não utilizamos para outros fins.", "q": "Preciso fornecer CPF para o reparo?"}, {"a": "Pelo tempo necessário para cumprir as obrigações legais e fiscais, conforme determina a legislação brasileira.", "q": "Meus dados ficam salvos por quanto tempo?"}]	\N	4	t
cmpd9tmgh0018zdl2xvypajho	Os jogos mais aguardados de 2026	os-jogos-mais-aguardados-de-2026	Os jogos mais aguardados de 2026	Confira a lista dos jogos mais esperados para 2026, com lançamentos para PS5, Xbox, Switch 2 e PC.	\N	\N	Jogos	2026-05-19 23:35:27.472	2026-05-19 23:35:27.473	2026-05-19 23:35:27.473	cmpd9tmak0000zdl2ul4uefpw	Confira a lista dos jogos mais esperados para 2026, com lançamentos para PS5, Xbox, Switch 2 e PC.	[{"type": "paragraph", "children": [{"text": "O ano de 2026 promete ser um dos mais empolgantes da história dos videogames. Com o Nintendo Switch 2 já consolidado, o PS5 Pro em pleno vapor e o PC Gamer cada vez mais forte, a safra de lançamentos é de tirar o fôlego."}]}, {"type": "paragraph", "children": [{"text": "Grand Theft Auto VI: O jogo mais esperado da década finalmente chega em 2026. A Rockstar promete uma experiência ainda mais imersiva em Vice City, com gráficos de ponta e um mundo aberto sem precedentes."}]}, {"type": "paragraph", "children": [{"text": "Ghost of Yotei: A sequência de Ghost of Tsushima leva os jogadores para o Japão feudal do século XVII, com novos personagens e mecânicas refinadas. Exclusivo para PS5."}]}, {"type": "paragraph", "children": [{"text": "Metroid Prime 4: Depois de anos de espera, a Samus Aran finalmente retorna em um novo capítulo da aclamada série Metroid Prime para Nintendo Switch 2."}]}, {"type": "paragraph", "children": [{"text": "Death Stranding 2: Hideo Kojima continua sua obra surreal com Death Stranding 2, prometendo uma narrativa ainda mais profunda e mecânicas de gameplay expandidas."}]}, {"type": "paragraph", "children": [{"text": "Fable: A série clássica da Microsoft retorna em um reboot para Xbox Series e PC, prometendo o humor e a liberdade característicos da franquia com gráficos de nova geração."}]}, {"type": "paragraph", "children": [{"text": "Marvel's Wolverine: A Insomniac Games, responsável por Spider-Man, traz Wolverine em uma aventura solo. Promete ser um dos exclusivos mais violentos e emocionantes do PS5."}]}, {"type": "paragraph", "children": [{"text": "Além desses, 2026 terá novos títulos de franquias como Assassin's Creed, Final Fantasy e Pokémon. Será um ano para o gamer gastar o 13o salário!"}]}]	[{"a": "Historicamente, a Rockstar lança GTA primeiro nos consoles e depois no PC. GTA 6 deve chegar aos consoles em 2026 e ao PC em 2027.", "q": "GTA 6 vai sair para PC no lançamento?"}, {"a": "Ghost of Yotei e Marvel's Wolverine são exclusivos PlayStation. Metroid Prime 4 é exclusivo Nintendo Switch 2. Fable é exclusivo Xbox/PC.", "q": "Quais jogos de 2026 são exclusivos?"}]	\N	5	t
cmpd9tmgl001azdl2gy7xlypm	Melhores jogos gratuitos para jogar em 2025	melhores-jogos-gratuitos-para-jogar-em-2025	Melhores jogos gratuitos para jogar em 2025	Seleção dos melhores jogos gratuitos disponíveis para todas as plataformas.	\N	\N	Jogos	2026-05-19 23:35:27.476	2026-05-19 23:35:27.477	2026-05-19 23:35:27.477	cmpd9tmak0000zdl2ul4uefpw	Seleção dos melhores jogos gratuitos disponíveis para todas as plataformas.	[{"type": "paragraph", "children": [{"text": "Jogar bem não precisa custar caro. Existe uma vasta biblioteca de jogos gratuitos de alta qualidade disponíveis em todas as plataformas. Selecionamos os melhores."}]}, {"type": "paragraph", "children": [{"text": "1. Fortnite: O battle royale da Epic Games continua sendo um dos jogos mais populares do mundo. Constantes atualizações, eventos ao vivo e modos criativos garantem diversão sem fim."}]}, {"type": "paragraph", "children": [{"text": "2. Call of Duty: Warzone 2.0: O battle royale da Activision segue forte, com mecânicas refinadas e gráficos impressionantes para um jogo gratuito."}]}, {"type": "paragraph", "children": [{"text": "3. Apex Legends: O shooter de heróis da Respawn oferece gameplay rápido e competitivo."}]}, {"type": "paragraph", "children": [{"text": "4. Rocket League: Carros jogando futebol. Simples, viciante e gratuito. Um dos jogos mais originais e divertidos da última década."}]}, {"type": "paragraph", "children": [{"text": "5. Genshin Impact: RPG de mundo aberto com gráficos dignos de console de última geração. Gratuito para jogar, com conteúdo novo a cada mês."}]}, {"type": "paragraph", "children": [{"text": "6. Valorant: O FPS tático da Riot Games é uma excelente alternativa gratuita ao CS2."}]}, {"type": "paragraph", "children": [{"text": "7. Overwatch 2: O hero shooter da Blizzard está gratuito e oferece uma experiência de alta qualidade para quem gosta de FPS com classes."}]}]	[{"a": "Sim, são totalmente gratuitos para baixar e jogar. Alguns têm microtransações para itens cosméticos, mas não são necessárias.", "q": "Jogos gratuitos realmente são de graça?"}, {"a": "No PS5 e Xbox, sim. No PC e Nintendo Switch, o online é gratuito.", "q": "Preciso de assinatura para jogar online?"}]	\N	5	t
cmpd9tmgo001czdl2c0zinrxj	Jogos que marcaram a história dos videogames	jogos-que-marcaram-a-historia-dos-videogames	Jogos que marcaram a história dos videogames	Uma viagem pelos jogos que definiram gerações e mudaram para sempre a indústria dos games.	\N	\N	Jogos	2026-05-19 23:35:27.48	2026-05-19 23:35:27.481	2026-05-19 23:35:27.481	cmpd9tmak0000zdl2ul4uefpw	Uma viagem pelos jogos que definiram gerações e mudaram para sempre a indústria dos games.	[{"type": "paragraph", "children": [{"text": "Alguns jogos transcendem o entretenimento e se tornam verdadeiros marcos culturais. Selecionamos aqueles que, de alguma forma, mudaram o rumo da indústria."}]}, {"type": "paragraph", "children": [{"text": "Super Mario Bros. (1985): O jogo que salvou a indústria dos videogames após a crise de 1983. Definiu o gênero de plataforma e apresentou ao mundo o personagem mais icônico dos games."}]}, {"type": "paragraph", "children": [{"text": "The Legend of Zelda: Ocarina of Time (1998): Considerado por muitos o melhor jogo de todos os tempos. Pioneiro em jogos 3D de aventura."}]}, {"type": "paragraph", "children": [{"text": "Grand Theft Auto III (2001): Revolucionou o conceito de mundo aberto e mostrou que videogames podiam contar histórias maduras."}]}, {"type": "paragraph", "children": [{"text": "Half-Life 2 (2004): Estabeleceu novos padrões para narrativa em primeira pessoa, física de objetos e inteligência artificial."}]}, {"type": "paragraph", "children": [{"text": "World of Warcraft (2004): Levou os MMOs ao mainstream e criou uma comunidade global que existe até hoje."}]}, {"type": "paragraph", "children": [{"text": "The Last of Us (2013): Elevou a narrativa nos videogames a um patamar cinematográfico."}]}, {"type": "paragraph", "children": [{"text": "Elden Ring (2022): Redefiniu o gênero soulslike com um mundo aberto magistral e se tornou um dos jogos mais premiados da história."}]}]	[{"a": "Não há consenso, mas The Legend of Zelda: Ocarina of Time, The Last of Us e Elden Ring estão frequentemente no topo das listas.", "q": "Qual é considerado o melhor jogo de todos os tempos?"}, {"a": "Minecraft é o jogo mais vendido de todos os tempos, com mais de 300 milhões de cópias.", "q": "Qual jogo vendeu mais cópias da história?"}]	\N	6	t
cmpd9tmhh001qzdl2hkd2gb48	Os melhores acessórios para Nintendo Switch em 2025	os-melhores-acessorios-para-nintendo-switch-em-2025	Os melhores acessórios para Nintendo Switch em 2025	Guia de acessórios essenciais para aproveitar ao máximo seu Nintendo Switch e Switch 2.	\N	\N	Nintendo	2026-05-19 23:35:27.509	2026-05-19 23:35:27.51	2026-05-19 23:35:27.51	cmpd9tmak0000zdl2ul4uefpw	Guia de acessórios essenciais para aproveitar ao máximo seu Nintendo Switch e Switch 2.	[{"type": "paragraph", "children": [{"text": "Alguns acessórios podem transformar a experiência com seu Nintendo Switch. Selecionamos os melhores para 2025."}]}, {"type": "paragraph", "children": [{"text": "1. Pro Controller: O controle oficial da Nintendo é muito mais confortável que os Joy-Con para longas sessões no modo dock."}]}, {"type": "paragraph", "children": [{"text": "2. Carregador portátil (Power Bank): A bateria do Switch dura de 4 a 8 horas. Um power bank de 20.000 mAh é essencial para viagens."}]}, {"type": "paragraph", "children": [{"text": "3. Case de transporte: Protege o console durante viagens. Modelos com espaço para jogos são os mais práticos."}]}, {"type": "paragraph", "children": [{"text": "4. Suporte ajustável: Para usar o Switch no modo mesa de forma confortável."}]}, {"type": "paragraph", "children": [{"text": "5. Controle 8BitDo Pro 2: Excelente alternativa ao Pro Controller, com botões programáveis."}]}, {"type": "paragraph", "children": [{"text": "6. Cartão microSD: Um cartão de 256 GB ou 512 GB é essencial para quem compra jogos digitais."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, você encontra orientação sobre os melhores acessórios para seu modelo de Switch."}]}]	[{"a": "Recomendamos cartões UHS-I de 256 GB ou 512 GB. Marcas como Samsung EVO e SanDisk Extreme são confiáveis.", "q": "Qual microSD comprar para o Switch?"}, {"a": "Sim, especialmente se você joga muito no modo dock. É muito mais ergonômico que os Joy-Con.", "q": "Vale a pena comprar o Pro Controller?"}]	\N	5	t
cmpd9tmhl001szdl2d0m4l3h4	Como montar um PC Gamer custo-benefício em 2025	como-montar-um-pc-gamer-custo-beneficio-em-2025	Como montar um PC Gamer custo-benefício em 2025	Guia completo para montar um PC Gamer com o melhor custo-benefício em 2025, com opções para todos os orçamentos.	\N	\N	PC Gamer	2026-05-19 23:35:27.512	2026-05-19 23:35:27.513	2026-05-19 23:35:27.513	cmpd9tmak0000zdl2ul4uefpw	Guia completo para montar um PC Gamer com o melhor custo-benefício em 2025, com opções para todos os orçamentos.	[{"type": "paragraph", "children": [{"text": "Montar um PC Gamer em 2025 está mais acessível do que nunca. Com a competição acirrada entre Intel e AMD e entre Nvidia e AMD, é possível montar máquinas excelentes para diferentes orçamentos."}]}, {"type": "paragraph", "children": [{"text": "Orçamento de R$ 4.000 a R$ 5.000: Um PC de entrada capaz de rodar eSports (Valorant, CS2, Fortnite) em 1080p a 60+ fps com Ryzen 5 8600G (com vídeo integrado) ou Ryzen 5 5500 + RX 6600."}]}, {"type": "paragraph", "children": [{"text": "Orçamento de R$ 6.000 a R$ 8.000: O ponto ideal de custo-benefício. Ryzen 7 5700X ou Intel i5-13400F com uma RTX 4060 ou RX 7700 XT. Roda qualquer jogo em 1080p/1440p no alto."}]}, {"type": "paragraph", "children": [{"text": "Orçamento de R$ 10.000 a R$ 15.000: PC de alto desempenho. Ryzen 7 7800X3D ou Intel i7-14700K com RTX 4070 Super ou RX 7800 XT. 1440p no ultra ou 4K no médio/alto."}]}, {"type": "paragraph", "children": [{"text": "Acima de R$ 15.000: O topo de linha. Ryzen 9 7950X3D ou Intel i9-14900K com RTX 4080 Super ou RTX 4090. 4K no ultra com altas taxas de quadros."}]}, {"type": "paragraph", "children": [{"text": "Dica importante: invista mais na placa de vídeo que no processador para jogos. Um Ryzen 5 com RTX 4070 entrega mais fps que um Ryzen 9 com RTX 4060."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, oferecemos consultoria gratuita para montagem de PC Gamer."}]}]	[{"a": "A AMD lidera em jogos com os processadores 3D V-Cache (X3D). A Intel lidera em tarefas profissionais.", "q": "Qual a diferença entre Intel e AMD em 2025?"}, {"a": "Montar você mesmo pode economizar de 10% a 20%. Se não tem experiência, contrate uma assistência.", "q": "Vale a pena montar PC ou comprar montado?"}]	\N	6	t
cmpd9tmhp001uzdl2s89ueq2r	Placa de vídeo: Qual escolher para cada orçamento em 2025	placa-de-video-qual-escolher-para-cada-orcamento-em-2025	Placa de vídeo: Qual escolher para cada orçamento em 2025	Guia completo de placas de vídeo para PC Gamer em 2025, da RTX 4060 à RTX 5090.	\N	\N	PC Gamer	2026-05-19 23:35:27.517	2026-05-19 23:35:27.518	2026-05-19 23:35:27.518	cmpd9tmak0000zdl2ul4uefpw	Guia completo de placas de vídeo para PC Gamer em 2025, da RTX 4060 à RTX 5090.	[{"type": "paragraph", "children": [{"text": "A placa de vídeo é o componente mais importante para jogos. Em 2025, o mercado está repleto de opções para todos os orçamentos."}]}, {"type": "paragraph", "children": [{"text": "Nvidia RTX 4060 (R$ 1.800 a R$ 2.200): A porta de entrada para jogos em 1080p no ultra e 1440p no médio. DLSS 3.5 e bom consumo de energia."}]}, {"type": "paragraph", "children": [{"text": "AMD RX 7700 XT (R$ 2.500 a R$ 3.000): Excelente custo-benefício para 1440p. Performance superior à RTX 4060 Ti por um preço menor."}]}, {"type": "paragraph", "children": [{"text": "Nvidia RTX 4070 Super (R$ 3.500 a R$ 4.200): O padrão ouro para 1440p no ultra. DLSS 3.5 e bom desempenho em ray tracing."}]}, {"type": "paragraph", "children": [{"text": "AMD RX 7800 XT (R$ 3.200 a R$ 3.800): Concorrente direta da RTX 4070, com mais VRAM (16 GB)."}]}, {"type": "paragraph", "children": [{"text": "Nvidia RTX 4080 Super (R$ 6.000 a R$ 7.500): Para 4K no alto/ultra. Desempenho excepcional em ray tracing."}]}, {"type": "paragraph", "children": [{"text": "Nvidia RTX 5090 (R$ 12.000+): A mais potente do mercado. 4K no ultra com ray tracing máximo."}]}, {"type": "paragraph", "children": [{"text": "Dica: para 1080p, RTX 4060 é suficiente. Para 1440p, RTX 4070 Super ou RX 7800 XT. Para 4K, RTX 4080 Super ou superior."}]}]	[{"a": "Sim, mas com cautela. Prefira placas que não foram usadas para mineração.", "q": "Vale a pena comprar placa de vídeo usada?"}, {"a": "A RX 7800 XT é a concorrente direta, com performance similar e mais VRAM (16 GB contra 12 GB).", "q": "Qual placa da AMD é equivalente à RTX 4070?"}]	\N	6	t
cmpd9tmgr001ezdl2jpe6fm81	Guia para montar sua biblioteca de jogos com economia	guia-para-montar-sua-biblioteca-de-jogos-com-economia	Guia para montar sua biblioteca de jogos com economia	Dicas para comprar jogos mais baratos, aproveitar promoções e montar uma biblioteca sem gastar uma fortuna.	\N	\N	Jogos	2026-05-19 23:35:27.483	2026-05-19 23:35:27.484	2026-05-19 23:35:27.484	cmpd9tmak0000zdl2ul4uefpw	Dicas para comprar jogos mais baratos, aproveitar promoções e montar uma biblioteca sem gastar uma fortuna.	[{"type": "paragraph", "children": [{"text": "Manter uma biblioteca de jogos atualizada pode pesar no bolso, mas com algumas estratégias é possível jogar muito gastando pouco."}]}, {"type": "paragraph", "children": [{"text": "1. Assine serviços de assinatura: PlayStation Plus Extra, Game Pass Ultimate e Nintendo Switch Online dão acesso a centenas de jogos por um valor mensal."}]}, {"type": "paragraph", "children": [{"text": "2. Aproveite promoções: Steam, PlayStation Store e Microsoft Store fazem promoções sazonais com descontos de 50% a 90%."}]}, {"type": "paragraph", "children": [{"text": "3. Compre jogos em mídia física usada: Jogos físicos usados podem custar de 30% a 50% menos que os novos."}]}, {"type": "paragraph", "children": [{"text": "4. Epic Games Store: A Epic dá pelo menos dois jogos grátis por semana. Ao longo de um ano, você acumula dezenas de jogos sem pagar nada."}]}, {"type": "paragraph", "children": [{"text": "5. Não compre no lançamento: Jogos dropsam de preço rapidamente. Em 3 a 6 meses, muitos títulos AAA já estão com 30% a 50% de desconto."}]}, {"type": "paragraph", "children": [{"text": "Com essas dicas, é possível manter uma biblioteca de dezenas de jogos gastando uma fração do valor de mercado."}]}]	[{"a": "Depende do seu tempo de jogo. Se joga muito, sim. Se joga poucas horas por semana, comprar jogos avulsos em promoção compensa mais.", "q": "Vale a pena assinar vários serviços?"}, {"a": "Sim, uma vez resgatados, ficam na sua biblioteca para sempre, mesmo sem assinatura.", "q": "Jogos da Epic Store são realmente grátis?"}]	\N	5	t
cmpd9tmgx001gzdl23pb5q29r	Jogos cooperativos para jogar com amigos em 2025	jogos-cooperativos-para-jogar-com-amigos-em-2025	Jogos cooperativos para jogar com amigos em 2025	Seleção dos melhores jogos coop para jogar com amigos, online ou no mesmo sofá.	\N	\N	Jogos	2026-05-19 23:35:27.487	2026-05-19 23:35:27.489	2026-05-19 23:35:27.489	cmpd9tmak0000zdl2ul4uefpw	Seleção dos melhores jogos coop para jogar com amigos, online ou no mesmo sofá.	[{"type": "paragraph", "children": [{"text": "Nada melhor que jogar com os amigos. Selecionamos os melhores jogos cooperativos de 2025 para todas as plataformas."}]}, {"type": "paragraph", "children": [{"text": "1. It Takes Two: O jogo cooperativo mais premiado da história. Exclusivamente cooperativo, conta a história de um casal que precisa trabalhar junto para superar desafios."}]}, {"type": "paragraph", "children": [{"text": "2. Overcooked 2: Caos na cozinha. Testa a amizade e a comunicação. Perfeito para jogar no mesmo sofá com até 4 jogadores."}]}, {"type": "paragraph", "children": [{"text": "3. Minecraft: O clássico dos clássicos. Construir, explorar e sobreviver juntos nunca envelhece."}]}, {"type": "paragraph", "children": [{"text": "4. Baldur's Gate 3: O RPG do ano permite campanha completa em coop com até 4 jogadores."}]}, {"type": "paragraph", "children": [{"text": "5. Fortnite: Battle royale gratuito com suporte a squad de até 4 jogadores."}]}, {"type": "paragraph", "children": [{"text": "6. Sea of Thieves: Pirataria em mundo aberto com tripulação de até 4 jogadores."}]}, {"type": "paragraph", "children": [{"text": "7. Super Mario Party Jamboree (Switch 2): O party game definitivo da Nintendo."}]}]	[{"a": "It Takes Two foi projetado especificamente para jogar a dois e é a melhor experiência cooperativa para casais.", "q": "Qual o melhor jogo cooperativo para casais?"}, {"a": "Depende do jogo. A maioria suporta 2 a 4 controles no mesmo console.", "q": "Preciso de quantos controles para jogar no mesmo sofá?"}]	\N	5	t
cmpd9tmh2001izdl2mwepo1u4	Nintendo Switch 2: Tudo o que você precisa saber	nintendo-switch-2-tudo-o-que-voce-precisa-saber	Nintendo Switch 2: Tudo o que você precisa saber	Guia completo sobre o Nintendo Switch 2: specs, preço, lançamentos e se vale a pena comprar.	\N	\N	Nintendo	2026-05-19 23:35:27.493	2026-05-19 23:35:27.494	2026-05-19 23:35:27.494	cmpd9tmak0000zdl2ul4uefpw	Guia completo sobre o Nintendo Switch 2: specs, preço, lançamentos e se vale a pena comprar.	[{"type": "paragraph", "children": [{"text": "O Nintendo Switch 2 foi lançado em junho de 2025 e já se tornou um fenômeno de vendas, ultrapassando 10 milhões de unidades nos primeiros meses. Reunimos tudo o que você precisa saber sobre o novo console da Nintendo."}]}, {"type": "paragraph", "children": [{"text": "O Switch 2 traz uma tela OLED de 8 polegadas com resolução de 1080p (no modo portátil) e suporte a 120 Hz. No modo dock, ele alcança 4K a 60 fps. Os novos Joy-Con 2 têm hall effect sensors, que eliminam o drift, um dos maiores problemas do Switch original."}]}, {"type": "paragraph", "children": [{"text": "O console é totalmente compatível com os jogos do Switch original, tanto físicos quanto digitais. Isso significa que sua biblioteca de jogos não fica para trás."}]}, {"type": "paragraph", "children": [{"text": "Os títulos de lançamento incluem Mario Kart World, The Legend of Zelda: Echoes of Wisdom, Metroid Prime 4, Pokémon Legends: Z-A e Super Mario Party Jamboree."}]}, {"type": "paragraph", "children": [{"text": "Com preço sugerido de US$ 399 (modelo básico) a US$ 449 (com Mario Kart World incluso), o Switch 2 custa menos que PS5 Pro e Xbox Series X."}]}, {"type": "paragraph", "children": [{"text": "A bateria dura até 8 horas no modo portátil, dependendo do jogo. O carregamento é via USB-C e o dock mantém o design híbrido característico da Nintendo."}]}, {"type": "paragraph", "children": [{"text": "Vale a pena comprar? Se você já tem um Switch e está satisfeito, pode esperar. Mas se quer a melhor experiência Nintendo com gráficos modernos e sem drift nos controles, o Switch 2 é a escolha certa."}]}]	[{"a": "Sim, total compatibilidade retroativa com jogos físicos e digitais do Nintendo Switch original.", "q": "Switch 2 roda jogos do Switch antigo?"}, {"a": "Não. Os novos Joy-Con 2 usam sensores hall effect, que são imunes ao desgaste que causa drift.", "q": "Switch 2 tem drift?"}]	\N	6	t
cmpd9tmh6001kzdl2au89hq41	Melhores jogos de Nintendo Switch 2 para comprar em 2025	melhores-jogos-de-nintendo-switch-2-para-comprar-em-2025	Melhores jogos de Nintendo Switch 2 para comprar em 2025	Seleção dos melhores jogos já disponíveis para o Nintendo Switch 2.	\N	\N	Nintendo	2026-05-19 23:35:27.498	2026-05-19 23:35:27.499	2026-05-19 23:35:27.499	cmpd9tmak0000zdl2ul4uefpw	Seleção dos melhores jogos já disponíveis para o Nintendo Switch 2.	[{"type": "paragraph", "children": [{"text": "O Nintendo Switch 2 chegou com uma biblioteca de lançamento impressionante. Selecionamos os melhores títulos já disponíveis para o novo console."}]}, {"type": "paragraph", "children": [{"text": "Mario Kart World: O novo Mario Kart é um show à parte. Pistas enormes, 24 jogadores simultâneos, gráficos em 4K e novas mecânicas como paredes escaláveis e circuitos aéreos."}]}, {"type": "paragraph", "children": [{"text": "The Legend of Zelda: Echoes of Wisdom: Pela primeira vez, a princesa Zelda é a protagonista. Uma aventura que expande o conceito de Tears of the Kingdom com novos poderes."}]}, {"type": "paragraph", "children": [{"text": "Metroid Prime 4: Após anos de desenvolvimento, a nova aventura de Samus Aran finalmente chegou. Gráficos de tirar o fôlego e combate refinado."}]}, {"type": "paragraph", "children": [{"text": "Pokémon Legends: Z-A: Ambientado na região de Kalos, com a cidade de Lumiose como cenário principal. Combates em tempo real e mecânicas de captura inovadoras."}]}, {"type": "paragraph", "children": [{"text": "Super Mario Party Jamboree: O party game definitivo, com 7 tabuleiros, mais de 110 minigames e modos online."}]}, {"type": "paragraph", "children": [{"text": "Todos esses jogos aproveitam o hardware do Switch 2 com gráficos superiores, carregamento mais rápido e recursos exclusivos dos Joy-Con 2."}]}]	[{"a": "O bundle de US$ 449 inclui Mario Kart World digital. O modelo básico de US$ 399 não vem com jogo incluso.", "q": "Quais jogos vêm no pacote do Switch 2?"}, {"a": "Sim, todos os jogos de Switch são compatíveis e muitos recebem patches gratuitos de melhoria.", "q": "Vale a pena comprar jogos de Switch no Switch 2?"}]	\N	5	t
cmpd9tmha001mzdl22i3cdadq	Como resolver problemas comuns no Nintendo Switch	como-resolver-problemas-comuns-no-nintendo-switch	Como resolver problemas comuns no Nintendo Switch	Guia de soluções para os problemas mais frequentes no Nintendo Switch, Switch Lite e Switch OLED.	\N	\N	Nintendo	2026-05-19 23:35:27.501	2026-05-19 23:35:27.502	2026-05-19 23:35:27.502	cmpd9tmak0000zdl2ul4uefpw	Guia de soluções para os problemas mais frequentes no Nintendo Switch, Switch Lite e Switch OLED.	[{"type": "paragraph", "children": [{"text": "Mesmo sendo um console robusto, o Nintendo Switch pode apresentar problemas com o tempo. Listamos os mais comuns e como resolvê-los."}]}, {"type": "paragraph", "children": [{"text": "Drift nos Joy-Con: O problema mais famoso do Switch. Os analógicos registram movimento sem comando. A solução definitiva é a troca dos módulos analógicos."}]}, {"type": "paragraph", "children": [{"text": "Switch não liga: Pode ser bateria descarregada, fonte com problema ou defeito na placa. Tente manter o botão power pressionado por 15 segundos."}]}, {"type": "paragraph", "children": [{"text": "Bateria não carrega: Geralmente é a porta USB-C danificada ou a bateria que chegou ao fim da vida útil."}]}, {"type": "paragraph", "children": [{"text": "Tela quebrada ou trincada: Infelizmente, a tela do Switch é frágil. A troca deve ser feita por profissionais."}]}, {"type": "paragraph", "children": [{"text": "Console superaquecendo: Poeira acumulada no sistema de ventilação é a causa mais comum. A limpeza preventiva resolve o problema."}]}, {"type": "paragraph", "children": [{"text": "Para qualquer desses problemas, a Virtual Games oferece diagnóstico gratuito em Santa Maria."}]}]	[{"a": "Sim, realizamos troca de tela para Switch, Switch Lite e Switch OLED. Consulte-nos para mais informações sobre o serviço.", "q": "Fazem troca de tela de todos os modelos de Switch?"}, {"a": "É possível, mas requer ferramentas específicas. Recomendamos procurar assistência especializada.", "q": "Posso trocar a bateria do Switch em casa?"}]	\N	6	t
cmpd9tmhe001ozdl21398bwo1	Nintendo Switch OLED vs Switch 2: Vale a pena fazer o upgrade?	nintendo-switch-oled-vs-switch-2-vale-a-pena-fazer-o-upgrade	Nintendo Switch OLED vs Switch 2: Vale a pena fazer o upgrade?	Comparativo entre o Nintendo Switch OLED e o Switch 2 para ajudar na decisão de upgrade.	\N	\N	Nintendo	2026-05-19 23:35:27.505	2026-05-19 23:35:27.506	2026-05-19 23:35:27.506	cmpd9tmak0000zdl2ul4uefpw	Comparativo entre o Nintendo Switch OLED e o Switch 2 para ajudar na decisão de upgrade.	[{"type": "paragraph", "children": [{"text": "Com o lançamento do Nintendo Switch 2, muitos donos do Switch OLED se perguntam: vale a pena fazer o upgrade? A resposta depende do seu perfil de uso."}]}, {"type": "paragraph", "children": [{"text": "O Switch OLED tem uma tela OLED de 7 polegadas (contra 8 polegadas do Switch 2), resolução de 720p no portátil e 1080p no dock. Ele roda os mesmos jogos desde 2021."}]}, {"type": "paragraph", "children": [{"text": "O Switch 2 dá um salto significativo: tela OLED de 8 polegadas com 1080p e 120 Hz no portátil, 4K a 60 fps no dock, Joy-Con 2 sem drift e desempenho muito superior."}]}, {"type": "paragraph", "children": [{"text": "Para quem joga apenas no modo portátil e está satisfeito com os jogos atuais, o OLED ainda é um excelente console."}]}, {"type": "paragraph", "children": [{"text": "Para quem joga no dock em uma TV 4K e quer aproveitar os novos lançamentos com a melhor qualidade possível, o upgrade faz todo sentido."}]}, {"type": "paragraph", "children": [{"text": "Outro fator: os Joy-Con 2 com hall effect sensors eliminam o drift. Se você já trocou de Joy-Con por drift, isso é um bom motivo para considerar o upgrade."}]}]	[{"a": "Carregadores, cases e cabos funcionam. Os Joy-Con originais não encaixam no Switch 2, mas podem ser conectados via Bluetooth.", "q": "Os acessórios do Switch OLED funcionam no Switch 2?"}, {"a": "Sim, é ligeiramente mais pesado devido à tela maior, mas a diferença é pequena.", "q": "O Switch 2 é mais pesado que o OLED?"}]	\N	5	t
cmpd9tmhu001wzdl2debxrdms	Refrigeração: Air cooling vs Water cooling para PC Gamer	refrigeracao-air-cooling-vs-water-cooling-para-pc-gamer	Refrigeração: Air cooling vs Water cooling para PC Gamer	Comparativo completo entre refrigeração a ar e water cooler para PC Gamer. Qual escolher?	\N	\N	PC Gamer	2026-05-19 23:35:27.521	2026-05-19 23:35:27.523	2026-05-19 23:35:27.523	cmpd9tmak0000zdl2ul4uefpw	Comparativo completo entre refrigeração a ar e water cooler para PC Gamer. Qual escolher?	[{"type": "paragraph", "children": [{"text": "Na hora de montar ou fazer upgrade do PC Gamer, uma dúvida comum é: qual sistema de refrigeração escolher?"}]}, {"type": "paragraph", "children": [{"text": "Air cooling (cooler a ar): Mais simples, mais barato e praticamente livre de manutenção. Um bom air cooler como o Cooler Master Hyper 212 ou o Noctua NH-D15 tem desempenho comparável a water coolers de 240 mm."}]}, {"type": "paragraph", "children": [{"text": "Water cooling (water cooler AIO): Mais eficiente na dissipação de calor, permite overclock mais agressivo e deixa o visual do PC mais limpo. Modelos de 240 mm e 360 mm são os mais comuns."}]}, {"type": "paragraph", "children": [{"text": "Para processadores de entrada e médio (Ryzen 5, Intel i5), um air cooler de qualidade é suficiente. Para processadores high-end (Ryzen 7/9, Intel i7/i9), um water cooler de 240 mm ou 360 mm é recomendado."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, realizamos instalação de sistemas de refrigeração e troca de pasta térmica com garantia de 90 dias."}]}]	[{"a": "É raro em modelos de marcas confiáveis (Corsair, NZXT, Cooler Master). Modelos mais baratos têm maior risco.", "q": "Water cooler pode vazar?"}, {"a": "Em média, de 3 a 5 anos. Após esse período, a bomba pode começar a falhar.", "q": "Qual a vida útil de um water cooler?"}]	\N	5	t
cmpd9tmhy001yzdl2uz4zbx0w	Guia de manutenção preventiva para PC Gamer	guia-de-manutencao-preventiva-para-pc-gamer	Guia de manutenção preventiva para PC Gamer	Passo a passo para manter seu PC Gamer funcionando como novo por mais tempo.	\N	\N	PC Gamer	2026-05-19 23:35:27.525	2026-05-19 23:35:27.526	2026-05-19 23:35:27.526	cmpd9tmak0000zdl2ul4uefpw	Passo a passo para manter seu PC Gamer funcionando como novo por mais tempo.	[{"type": "paragraph", "children": [{"text": "A manutenção preventiva é essencial para a longevidade do seu PC Gamer. Com cuidados regulares, você evita problemas de superaquecimento e falhas prematuras."}]}, {"type": "paragraph", "children": [{"text": "Limpeza interna: A cada 6 meses, abra o gabinete e remova a poeira acumulada nos fans, filtros e dissipadores. Use ar comprimido ou pincel antiestático."}]}, {"type": "paragraph", "children": [{"text": "Troca de pasta térmica: A cada 12 a 18 meses, troque a pasta térmica do processador e da placa de vídeo."}]}, {"type": "paragraph", "children": [{"text": "Gerenciamento de cabos: Cabos mal organizados obstruem o fluxo de ar. Um bom cable management reduz a temperatura interna em 3 a 5 graus."}]}, {"type": "paragraph", "children": [{"text": "Atualização de drivers: Mantenha os drivers da placa de vídeo, chipset e BIOS atualizados."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, oferecemos serviço completo de limpeza e manutenção preventiva para PC Gamer, com garantia de 90 dias."}]}]	[{"a": "Recomendamos limpeza interna a cada 6 meses. Se o ambiente tiver muita poeira, a cada 3 meses.", "q": "Com que frequência devo limpar meu PC Gamer?"}, {"a": "Não use aspirador comum, que gera estática. Use ar comprimido ou aspirador próprio para eletrônicos.", "q": "Posso limpar o PC com aspirador?"}]	\N	5	t
cmpd9tmi00020zdl2via1siub	SSD vs NVMe: Qual a diferença e qual escolher em 2025?	ssd-vs-nvme-qual-a-diferenca-e-qual-escolher-em-2025	SSD vs NVMe: Qual a diferença e qual escolher em 2025?	Entenda as diferenças entre SSD SATA, SSD NVMe e NVMe PCIe 5.0 para seu PC Gamer.	\N	\N	PC Gamer	2026-05-19 23:35:27.528	2026-05-19 23:35:27.529	2026-05-19 23:35:27.529	cmpd9tmak0000zdl2ul4uefpw	Entenda as diferenças entre SSD SATA, SSD NVMe e NVMe PCIe 5.0 para seu PC Gamer.	[{"type": "paragraph", "children": [{"text": "Na hora de escolher o armazenamento do seu PC Gamer, as opções podem confundir. Vamos explicar as diferenças."}]}, {"type": "paragraph", "children": [{"text": "SSD SATA: O padrão mais antigo, com velocidade de até 550 MB/s. Ainda é uma boa opção para upgrades em PCs mais antigos."}]}, {"type": "paragraph", "children": [{"text": "SSD NVMe PCIe 3.0: Velocidades de até 3.500 MB/s. Até 7 vezes mais rápido que o SATA. Excelente custo-benefício."}]}, {"type": "paragraph", "children": [{"text": "SSD NVMe PCIe 4.0: Velocidades de até 7.000 MB/s. O padrão atual para PCs Gamer de médio e alto desempenho."}]}, {"type": "paragraph", "children": [{"text": "SSD NVMe PCIe 5.0: Velocidades de até 10.000 MB/s ou mais. Ainda caro, mas ideal para quem quer o máximo de performance."}]}, {"type": "paragraph", "children": [{"text": "Para jogos, a diferença prática entre um NVMe 3.0 e um 5.0 é de apenas alguns segundos nos carregamentos."}]}, {"type": "paragraph", "children": [{"text": "Recomendação: use um NVMe PCIe 4.0 de 1 TB para o sistema e jogos principais, e um SSD SATA ou HD de 2 TB para armazenamento secundário."}]}]	[{"a": "Não, um SSD SATA já elimina os gargalos de carregamento. O NVMe faz diferença em transferência de arquivos.", "q": "Preciso de SSD NVMe para jogar?"}, {"a": "Samsung (990 Pro), WD (SN850X), Kingston (KC3000) e Corsair (MP600) são marcas confiáveis.", "q": "Qual marca de SSD recomendar?"}]	\N	5	t
cmpd9tmi40022zdl232rzv9bt	Processador: Intel vs AMD em 2025 Qual escolher?	processador-intel-vs-amd-em-2025-qual-escolher	Processador: Intel vs AMD em 2025 Qual escolher?	Comparativo completo entre processadores Intel e AMD para PC Gamer em 2025.	\N	\N	PC Gamer	2026-05-19 23:35:27.532	2026-05-19 23:35:27.533	2026-05-19 23:35:27.533	cmpd9tmak0000zdl2ul4uefpw	Comparativo completo entre processadores Intel e AMD para PC Gamer em 2025.	[{"type": "paragraph", "children": [{"text": "A rivalidade entre Intel e AMD está mais acirrada do que nunca. Em 2025, ambas as marcas oferecem processadores excelentes para jogos."}]}, {"type": "paragraph", "children": [{"text": "AMD Ryzen 7000 e 9000: Os processadores da AMD continuam liderando em jogos graças à tecnologia 3D V-Cache. O Ryzen 7 7800X3D é considerado o melhor processador para jogos puros."}]}, {"type": "paragraph", "children": [{"text": "Intel Core 13a, 14a e Ultra: A Intel aposta em altas frequências e bom desempenho multitarefa. Excelentes para quem também edita vídeo ou faz streaming."}]}, {"type": "paragraph", "children": [{"text": "Em jogos, o Ryzen 7 7800X3D lidera na maioria dos títulos. O Intel i7-14700K empata ou supera em alguns jogos que favorecem altas frequências."}]}, {"type": "paragraph", "children": [{"text": "A plataforma AM5 da AMD tem suporte prometido para futuras gerações. A Intel troca de soquete com mais frequência."}]}, {"type": "paragraph", "children": [{"text": "Conclusão: para jogos puros, AMD Ryzen 7 7800X3D é a melhor escolha. Para uso misto, Intel i7-14700K ou i9-14900K são excelentes."}]}]	[{"a": "Qualquer placa-mãe AM5 com chipset B650 ou X670. O B650 oferece o melhor custo-benefício.", "q": "Qual placa-mãe usar com Ryzen 7800X3D?"}, {"a": "AMD leva vantagem porque a plataforma AM5 tem suporte prometido para várias gerações.", "q": "Intel ou AMD é melhor para upgrade futuro?"}]	\N	6	t
cmpd9tmi80024zdl2k6hkvdtj	Xbox Game Pass: Vale a pena assinar em 2025?	xbox-game-pass-vale-a-pena-assinar-em-2025	Xbox Game Pass: Vale a pena assinar em 2025?	Análise completa do Xbox Game Pass em 2025: catálogo, preços, vantagens e se realmente compensa.	\N	\N	Xbox	2026-05-19 23:35:27.535	2026-05-19 23:35:27.536	2026-05-19 23:35:27.536	cmpd9tmak0000zdl2ul4uefpw	Análise completa do Xbox Game Pass em 2025: catálogo, preços, vantagens e se realmente compensa.	[{"type": "paragraph", "children": [{"text": "O Xbox Game Pass é o serviço de assinatura de jogos mais famoso do mundo. Mas será que ainda vale a pena em 2025? Vamos analisar."}]}, {"type": "paragraph", "children": [{"text": "O Game Pass Ultimate custa cerca de R$ 60 por mês e dá acesso a centenas de jogos no console e PC, jogos de lançamento day one (como Call of Duty, Diablo e novos títulos da Activision Blizzard), EA Play, Xbox Cloud Gaming e multiplayer online."}]}, {"type": "paragraph", "children": [{"text": "O catálogo em 2025 está impressionante. Com a aquisição da Activision Blizzard pela Microsoft, jogos como Call of Duty: Black Ops 7, Diablo V e Overwatch 3 chegam day one no serviço."}]}, {"type": "paragraph", "children": [{"text": "Para quem joga de 2 a 3 jogos completos por ano, o Game Pass já se paga. Três jogos novos custariam de R$ 750 a R$ 1.200, contra R$ 720 do Game Pass anual."}]}, {"type": "paragraph", "children": [{"text": "O Cloud Gaming é um diferencial enorme. Você pode jogar títulos de Xbox em celulares, tablets e PCs fracos via streaming."}]}, {"type": "paragraph", "children": [{"text": "Para quem joga casualmente ou gosta de experimentar jogos diferentes, o Game Pass é imbatível."}]}]	[{"a": "Sim, jogos de terceiros entram e saem. Jogos first party (Microsoft, Activision, Bethesda) ficam permanentemente.", "q": "Jogos do Game Pass saem do catálogo?"}, {"a": "Sim, o Game Pass Ultimate e o PC Game Pass dão acesso aos jogos no computador.", "q": "Game Pass funciona no PC?"}]	\N	6	t
cmpd9tmih0026zdl2q6ki0v18	Problemas comuns no Xbox e como resolver	problemas-comuns-no-xbox-e-como-resolver	Problemas comuns no Xbox e como resolver	Guia de soluções para os problemas mais frequentes em Xbox Series X, Series S e Xbox One.	\N	\N	Xbox	2026-05-19 23:35:27.545	2026-05-19 23:35:27.546	2026-05-19 23:35:27.546	cmpd9tmak0000zdl2ul4uefpw	Guia de soluções para os problemas mais frequentes em Xbox Series X, Series S e Xbox One.	[{"type": "paragraph", "children": [{"text": "O Xbox é um console confiável, mas como qualquer eletrônico, pode apresentar problemas. Listamos os mais comuns."}]}, {"type": "paragraph", "children": [{"text": "Xbox não liga: Verifique o cabo de força e a tomada. Se o console emitir um bipe mas não ligar, pode ser problema na fonte."}]}, {"type": "paragraph", "children": [{"text": "Superaquecimento e desligamento: O Xbox desliga sozinho para proteger os componentes. A limpeza preventiva com troca de pasta térmica resolve."}]}, {"type": "paragraph", "children": [{"text": "Porta HDMI sem sinal: Geralmente causado por puxar o cabo HDMI sem segurar o conector. A troca da porta HDMI resolve."}]}, {"type": "paragraph", "children": [{"text": "Disco que não lê (Series X): Pode ser sujeira no leitor ou falha mecânica."}]}, {"type": "paragraph", "children": [{"text": "Ruído excessivo do cooler: Indica acúmulo de poeira ou desgaste do rolamento do ventilador."}]}, {"type": "paragraph", "children": [{"text": "Na Virtual Games, oferecemos diagnóstico gratuito para todos os modelos de Xbox em Santa Maria."}]}]	[{"a": "Superaquecimento é a causa mais provável. A limpeza interna resolve na maioria dos casos.", "q": "Meu Xbox desliga sozinho, o que pode ser?"}, {"a": "A partir de R$ 250, com garantia de 90 dias. O diagnóstico é gratuito.", "q": "Quanto custa o reparo da porta HDMI do Xbox?"}]	\N	6	t
cmpd9tmil0028zdl2t9sko8sj	Xbox Series X vs Xbox Series S: Guia de compra definitivo	xbox-series-x-vs-xbox-series-s-guia-de-compra-definitivo	Xbox Series X vs Xbox Series S: Guia de compra definitivo	Comparativo completo entre Xbox Series X e Series S para ajudar na sua escolha.	\N	\N	Xbox	2026-05-19 23:35:27.548	2026-05-19 23:35:27.549	2026-05-19 23:35:27.549	cmpd9tmak0000zdl2ul4uefpw	Comparativo completo entre Xbox Series X e Series S para ajudar na sua escolha.	[{"type": "paragraph", "children": [{"text": "A Microsoft oferece duas opções de console de nona geração: o potente Xbox Series X e o acessível Xbox Series S."}]}, {"type": "paragraph", "children": [{"text": "O Xbox Series X é o console topo de linha com 12 TFLOPS, 1 TB de SSD e leitor de disco 4K. Ele roda jogos em 4K nativo a 60 fps (até 120 fps em títulos competitivos)."}]}, {"type": "paragraph", "children": [{"text": "O Xbox Series S é a opção de entrada. Com 4 TFLOPS e sem leitor de disco, ele foca em resolução 1440p (com upscale para 4K). É o console mais compacto e silencioso da geração."}]}, {"type": "paragraph", "children": [{"text": "Na prática: o Series X é para quem tem TV 4K e quer a máxima qualidade. O Series S é perfeito para quem joga em monitor Full HD ou 1440p."}]}, {"type": "paragraph", "children": [{"text": "Ambos têm acesso aos mesmos jogos e serviços (Game Pass) e funcionalidades como Quick Resume."}]}, {"type": "paragraph", "children": [{"text": "Conclusão: Series X para entusiastas com TV 4K. Series S para quem busca custo-benefício."}]}]	[{"a": "Ele faz upscale para 4K, mas a resolução nativa é 1440p.", "q": "O Series S roda em 4K?"}, {"a": "Não, o Series S é totalmente digital.", "q": "O Series S tem saída de disco?"}]	\N	5	t
cmpd9tmiq002azdl2w1guwnfs	Como melhorar o desempenho do seu Xbox	como-melhorar-o-desempenho-do-seu-xbox	Como melhorar o desempenho do seu Xbox	Dicas práticas para extrair o máximo de performance do seu Xbox Series X, Series S ou Xbox One.	\N	\N	Xbox	2026-05-19 23:35:27.553	2026-05-19 23:35:27.554	2026-05-19 23:35:27.554	cmpd9tmak0000zdl2ul4uefpw	Dicas práticas para extrair o máximo de performance do seu Xbox Series X, Series S ou Xbox One.	[{"type": "paragraph", "children": [{"text": "Seu Xbox pode estar entregando menos desempenho do que deveria. Algumas configurações podem fazer diferença."}]}, {"type": "paragraph", "children": [{"text": "1. Ative o Modo Jogo: Vá em Configurações > Geral > Modo Jogo e ative. Isso prioriza recursos para jogos."}]}, {"type": "paragraph", "children": [{"text": "2. Mantenha o console ventilado: O superaquecimento causa redução automática de desempenho."}]}, {"type": "paragraph", "children": [{"text": "3. Limpeza regular: Poeira acumulada reduz a eficiência da refrigeração."}]}, {"type": "paragraph", "children": [{"text": "4. Ajuste as configurações de vídeo: Ative 4K, HDR e 120 Hz nas configurações de tela."}]}, {"type": "paragraph", "children": [{"text": "5. Manter o sistema atualizado: A Microsoft lança atualizações regulares que melhoram desempenho."}]}, {"type": "paragraph", "children": [{"text": "Se o desempenho não estiver bom, pode ser problema de hardware. Traga para diagnóstico gratuito na Virtual Games."}]}]	[{"a": "Sim, para jogos de Xbox One, um SSD externo reduz muito os tempos de carregamento.", "q": "Vale a pena usar SSD externo no Xbox?"}, {"a": "Sintomas: desligamento repentino, barulho excessivo do cooler e lentidão na interface.", "q": "Como saber se meu Xbox está superaquecendo?"}]	\N	5	t
cmpd9tmiu002czdl2sfgnhd8c	Melhores jogos de Xbox em 2025	melhores-jogos-de-xbox-em-2025	Melhores jogos de Xbox em 2025	Seleção dos melhores jogos disponíveis para Xbox Series X, Series S e Xbox One em 2025.	\N	\N	Xbox	2026-05-19 23:35:27.557	2026-05-19 23:35:27.558	2026-05-19 23:35:27.558	cmpd9tmak0000zdl2ul4uefpw	Seleção dos melhores jogos disponíveis para Xbox Series X, Series S e Xbox One em 2025.	[{"type": "paragraph", "children": [{"text": "O ecossistema Xbox está mais forte do que nunca em 2025. Com a Activision Blizzard no grupo Microsoft, a biblioteca do Xbox está repleta de títulos imperdíveis."}]}, {"type": "paragraph", "children": [{"text": "Call of Duty: Black Ops 7: Campanha cinematográfica e multiplayer viciante. Day one no Game Pass."}]}, {"type": "paragraph", "children": [{"text": "Fable (reboot): O aguardado retorno da série clássica da Microsoft. Exclusivo Xbox e PC."}]}, {"type": "paragraph", "children": [{"text": "Starfield: Shattered Space: A expansão do RPG espacial da Bethesda adiciona novas missões e planetas."}]}, {"type": "paragraph", "children": [{"text": "Forza Motorsport 8: A série de corrida mais realista do Xbox está de volta."}]}, {"type": "paragraph", "children": [{"text": "Diablo V: Novo sistema de habilidades, classes inéditas e endgame profundo. Day one no Game Pass."}]}, {"type": "paragraph", "children": [{"text": "Gears of War: E-Day: A prequência da série de ação da The Coalition com gráficos impressionantes."}]}]	[{"a": "Sim, o Game Pass Core ou Ultimate é necessário para jogar online no Xbox.", "q": "Preciso de Game Pass para jogar online no Xbox?"}, {"a": "Sim, a grande maioria é compatível, muitos com melhorias de desempenho.", "q": "Jogos de Xbox One rodam no Series X/S?"}]	\N	6	t
\.


--
-- Data for Name: CashMovement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CashMovement" (id, date, "createdAt", description, "payableId", "receivableId", type, "userId", value) FROM stdin;
cmp8s4z59000ew6aqy8pad4e0	2026-05-16 20:09:19.28	2026-05-16 20:09:19.342	CAT:Caixa Diário|ACC:Caixa Físico|DESC:[ABERTURA] Abertura do caixa	\N	\N	IN	cmndrx24x005oxpl63njyr4ps	10.00
cmp8x2ezf001yw6aqjs0irde2	2026-05-16 22:27:17.978	2026-05-16 22:27:17.979	Payment for OS #R40AT1 - Entrega	\N	cmp8x2ez1001ww6aqq6h8x7pg	IN	cmp44a4po0006m1n742wbaa42	250.00
\.


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Category" (id, name, description, active, "createdAt", "updatedAt", slug) FROM stdin;
cmndrx2cp0060xpl69fqhprbq	Console	Produtos da categoria Console	t	2026-03-30 22:42:36.457	2026-03-30 22:42:36.457	console
cmndrx2cz0063xpl6g8j5nn4x	Jogo	Produtos da categoria Jogo	t	2026-03-30 22:42:36.468	2026-03-30 22:42:36.468	jogo
cmndrx2d60066xpl6nc7btcxn	Computador	Produtos da categoria Computador	t	2026-03-30 22:42:36.474	2026-03-30 22:42:36.474	computador
cmndrx2dd0069xpl6ddqh77tl	Placa	Produtos da categoria Placa	t	2026-03-30 22:42:36.481	2026-03-30 22:42:36.481	placa
cmndrx2dk006cxpl6rtdo5nnt	Hardware	Produtos da categoria Hardware	t	2026-03-30 22:42:36.488	2026-03-30 22:42:36.488	hardware
cmndrx2dr006fxpl6inufoqdt	Periférico	Produtos da categoria Periférico	t	2026-03-30 22:42:36.495	2026-03-30 22:42:36.495	periferico
cmndrx2dx006ixpl6vsx8qxdb	Smartphone	Produtos da categoria Smartphone	t	2026-03-30 22:42:36.502	2026-03-30 22:42:36.502	smartphone
cmndrx2e5006lxpl613j3lba5	Tablet	Produtos da categoria Tablet	t	2026-03-30 22:42:36.509	2026-03-30 22:42:36.509	tablet
cmndrx2eb006oxpl6v9f1vglh	Wearable	Produtos da categoria Wearable	t	2026-03-30 22:42:36.515	2026-03-30 22:42:36.515	wearable
cmndrx2ei006rxpl6mxknd5s9	Televisor	Produtos da categoria Televisor	t	2026-03-30 22:42:36.522	2026-03-30 22:42:36.522	televisor
cmndrx2eo006uxpl61ofifoig	Monitor	Produtos da categoria Monitor	t	2026-03-30 22:42:36.529	2026-03-30 22:42:36.529	monitor
cmndrx2ev006xxpl63n3jy2az	Áudio e Vídeo	Produtos da categoria Áudio e Vídeo	t	2026-03-30 22:42:36.535	2026-03-30 22:42:36.535	audio-e-video
cmndrx2f20070xpl6dbckhnh5	Armazenamento	Produtos da categoria Armazenamento	t	2026-03-30 22:42:36.542	2026-03-30 22:42:36.542	armazenamento
cmndrx2f80073xpl6v83yzabd	Rede	Produtos da categoria Rede	t	2026-03-30 22:42:36.549	2026-03-30 22:42:36.549	rede
cmndrx2fg0076xpl61iv6rtgj	Energia	Produtos da categoria Energia	t	2026-03-30 22:42:36.556	2026-03-30 22:42:36.556	energia
cmndrx2fm0079xpl62qt3j22j	Peça	Produtos da categoria Peça	t	2026-03-30 22:42:36.562	2026-03-30 22:42:36.562	peca
cmndrx2ft007cxpl6zucv9gip	Acessório	Produtos da categoria Acessório	t	2026-03-30 22:42:36.569	2026-03-30 22:42:36.569	acessorio
cmndrx2fz007fxpl68zusnpei	Diverso	Produtos da categoria Diverso	t	2026-03-30 22:42:36.576	2026-03-30 22:42:36.576	diverso
\.


--
-- Data for Name: CostCenter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CostCenter" (id, name, type, active) FROM stdin;
cmndrx2cg005vxpl62o4lz70v	Vendas de Produtos	REVENUE	t
cmndrx2cg005wxpl6b9amrrl5	Serviços Técnicos	REVENUE	t
cmndrx2cg005xxpl6fzhtnqus	Compra de Mercadoria	EXPENSE	t
cmndrx2cg005yxpl6ihlf51no	Peças de Reposição	EXPENSE	t
cmndrx2cg005zxpl6seba7cp7	Despesas Operacionais	EXPENSE	t
cmnf3hwew002jlyycb43b99uv	Pagamento de Comissão Técnica	EXPENSE	t
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, name, email, document, type, phone, "zipCode", street, number, complement, neighborhood, city, state, active, "createdAt", "updatedAt") FROM stdin;
cmp8o5xtu0001w6aqrcyex0mq	João	\N	LEAD-WPP-555596270266-122834	PF	555596270266	\N	\N	\N	\N	\N	\N	\N	t	2026-05-16 18:18:05.826	2026-05-16 18:18:05.826
cmp8s3n2v000cw6aqlssmcyvi	Vagner V.	\N	CF-1778962097047-3	PF	(55) 99271-0404	\N	\N	\N	\N	\N	\N	\N	t	2026-05-16 20:08:17.048	2026-05-16 20:08:17.048
\.


--
-- Data for Name: CustomerFunnelCard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CustomerFunnelCard" (id, "customerId", stage, "sellerNote", "itemInterest", active, "archivedAt", "createdAt", "updatedAt", "lastStageChangeAt", "hasNewMessage") FROM stdin;
cmp8o5xwu0003w6aqovt9jfht	cmp8o5xtu0001w6aqrcyex0mq	NOVO_CONTATO	Pego meu dinheiro dia 25	\N	t	\N	2026-05-16 18:18:05.932	2026-05-16 18:19:01.754	2026-05-16 18:18:05.932	t
\.


--
-- Data for Name: CustomerInteraction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CustomerInteraction" (id, "customerId", type, content, "createdAt") FROM stdin;
cmp8o5xx60005w6aq9bx86hna	cmp8o5xtu0001w6aqrcyex0mq	WHATSAPP	Pego meu dinheiro dia 25	2026-05-16 18:18:05.947
cmp8o6xu10008w6aqx4kdylvc	cmp8o5xtu0001w6aqrcyex0mq	WHATSAPP	Só me passa o endereço daí	2026-05-16 18:18:52.489
cmp8o74z4000bw6aqui2hj9ur	cmp8o5xtu0001w6aqrcyex0mq	WHATSAPP	Que eu dou uma passada aí semana que vem	2026-05-16 18:19:01.744
\.


--
-- Data for Name: DailyMetrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DailyMetrics" (id, date, "totalSales", "totalCost", "totalRevenue", "osCount", "saleCount", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Employee" (id, "nomeCompleto", cpf, "dataNascimento", "celularWhatsapp", "emailPessoal", "dataAdmissao", "cargoFuncao", "tipoContrato", "salarioBase", "percentualComissao", "chavePix", status, "userId", "createdAt", "updatedAt", "descricaoPerfil", "fotoUrl") FROM stdin;
cmndvxqpi0001hbtat6zvkeqd	Emerson Gabriel de Mello Graeff	123.456.789-00	2000-01-01 00:00:00	(55) 99999-9999	email@email.com	2020-01-01 00:00:00	CEO da Virtual Games	SOCIO	2000.00	\N	\N	ATIVO	cmndrx24x005oxpl63njyr4ps	2026-03-31 00:35:06.486	2026-03-31 22:17:17.257	Minha história com videogames começou lá atrás, em2010, com um Nintendo. Desde então, o controle nunca mais saiu da minha mão. Eu entendo que um jogo não é apenas um passatempo; é uma história, uma aventura e, muitas vezes, o nosso refúgio.\nCriei a Virtual Games porque sentia falta de um lugar feito de jogadores para jogadores. Um espaço onde a qualidade do produto é garantida e o atendimento é feito por quem realmente entende do assunto.\nAqui, eu pessoalmente seleciono cada produto que chega à prateleira. Se eu não jogaria, eu não vendo.\nMais do que vender games, meu objetivo é garantir que você tenha a melhor experiência possível, do unboxing à platina.	/uploads/employees/1774917247114-e746f8a9-fac3-4fef-8cbd-e0bb8e4712c1.png
cmp443t1t0004m1n7bkyfppcb	Kevin de Mello Graeff	042.679.000-60	2000-10-20 00:00:00	(55) 98448-5987	kevinmgraeff@gmail.com	2019-11-19 00:00:00	Tecnico 	PJ	1615.00	\N	\N	ATIVO	cmp443t1j0002m1n7kthmw1bm	2026-05-13 13:45:29.296	2026-05-13 13:45:29.296	\N	\N
cmp44a4pt0008m1n7n4rvq4b0	Elias Rodrigues Fagundes 	045.602.420-46	1998-10-18 00:00:00	(51) 98951-1818	erfagundes20@gmail.com	2025-03-03 00:00:00	Tecnico 	AUTONOMO	1200.00	30.00	\N	ATIVO	cmp44a4po0006m1n742wbaa42	2026-05-13 13:50:24.353	2026-05-13 13:50:24.353	\N	\N
cmp44djes000cm1n7zsw3cqyq	Gabriel Rae da Silva Castro 	016.275.440-03	1988-05-10 00:00:00	(55) 99112-7580	gabrielrs2castro@gmail.com	2023-04-23 00:00:00	Vendedor	CLT	1200.00	\N	\N	ATIVO	cmp44djem000am1n7zkj8zkfs	2026-05-13 13:53:03.364	2026-05-13 13:53:03.364	\N	\N
\.


--
-- Data for Name: Item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Item" (id, "productId", "serialNumber", imei, condition, grade, "costPrice", "warrantyDays", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Manufacturer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Manufacturer" (id, name, slug, website, active, "createdAt", "updatedAt") FROM stdin;
cmndrx2i4007ixpl60whgubn4	Samsung	samsung	https://www.samsung.com	t	2026-03-30 22:42:36.653	2026-03-30 22:42:36.653
cmndrx2ib007jxpl6khptry9f	Apple	apple	https://www.apple.com	t	2026-03-30 22:42:36.659	2026-03-30 22:42:36.659
cmndrx2ie007kxpl6bhlkery8	Sony	sony	https://www.sony.com	t	2026-03-30 22:42:36.662	2026-03-30 22:42:36.662
cmndrx2ih007lxpl6qxemgyj6	Dell	dell	https://www.dell.com	t	2026-03-30 22:42:36.665	2026-03-30 22:42:36.665
cmndrx2ik007mxpl6ur5aht5q	HP	hp	https://www.hp.com	t	2026-03-30 22:42:36.668	2026-03-30 22:42:36.668
cmndrx2in007nxpl6mnfj2qb3	Logitech	logitech	https://www.logitech.com	t	2026-03-30 22:42:36.672	2026-03-30 22:42:36.672
cmndrx2iq007oxpl6otrp4c7h	Asus	asus	https://www.asus.com	t	2026-03-30 22:42:36.675	2026-03-30 22:42:36.675
cmndrx2iu007pxpl603iz4ii7	Acer	acer	https://www.acer.com	t	2026-03-30 22:42:36.678	2026-03-30 22:42:36.678
cmndrx2ix007qxpl6pc6856ln	Microsoft	microsoft	https://www.microsoft.com	t	2026-03-30 22:42:36.681	2026-03-30 22:42:36.681
cmndrx2j0007rxpl6jt5ajc76	Nintendo	nintendo	https://www.nintendo.com	t	2026-03-30 22:42:36.684	2026-03-30 22:42:36.684
cmndrx2j4007sxpl6wsbts5ml	LG	lg	https://www.lg.com	t	2026-03-30 22:42:36.689	2026-03-30 22:42:36.689
cmndrx2j8007txpl615nemtld	Motorola	motorola	https://www.motorola.com	t	2026-03-30 22:42:36.692	2026-03-30 22:42:36.692
cmndrx2jc007uxpl6r2ikhhoc	Xiaomi	xiaomi	https://www.mi.com	t	2026-03-30 22:42:36.696	2026-03-30 22:42:36.696
cmndrx2jg007vxpl6qc7t5a50	Intel	intel	https://www.intel.com	t	2026-03-30 22:42:36.7	2026-03-30 22:42:36.7
cmndrx2jk007wxpl613yz2y7h	AMD	amd	https://www.amd.com	t	2026-03-30 22:42:36.704	2026-03-30 22:42:36.704
cmndrx2jn007xxpl68i3iwhli	Nvidia	nvidia	https://www.nvidia.com	t	2026-03-30 22:42:36.708	2026-03-30 22:42:36.708
cmndrx2jr007yxpl67a5mad0n	Kingston	kingston	https://www.kingston.com	t	2026-03-30 22:42:36.711	2026-03-30 22:42:36.711
cmndrx2ju007zxpl632wqeb1t	SanDisk	sandisk	https://www.westerndigital.com	t	2026-03-30 22:42:36.714	2026-03-30 22:42:36.714
cmndrx2jx0080xpl6h4fsu3vc	TP-Link	tp-link	https://www.tp-link.com	t	2026-03-30 22:42:36.718	2026-03-30 22:42:36.718
cmndrx2k10081xpl6y30i96u2	JBL	jbl	https://www.jbl.com	t	2026-03-30 22:42:36.721	2026-03-30 22:42:36.721
cmndrx2k40082xpl6dp62yfwf	Corsair	corsair	https://www.corsair.com	t	2026-03-30 22:42:36.724	2026-03-30 22:42:36.724
cmndrx2k70083xpl6ufrfw864	Razer	razer	https://www.razer.com	t	2026-03-30 22:42:36.727	2026-03-30 22:42:36.727
cmp4l9r40001aivh634fhy8db	KNUP	knup	\N	t	2026-05-13 21:46:00.19	2026-05-13 21:46:00.19
cmp4lb1fh001iivh6rs8an7h1	HMASTON	hmaston	\N	t	2026-05-13 21:47:00.221	2026-05-13 21:47:00.221
cmp4lcq04001uivh6h6qmo7ms	DELTA	delta	\N	t	2026-05-13 21:48:18.724	2026-05-13 21:48:18.724
cmp4leyte0029ivh64n6fimlg	IT BLUE	it-blue	\N	t	2026-05-13 21:50:03.458	2026-05-13 21:50:03.458
cmp4lg2ap002hivh637gwfgrq	MOX	mox	\N	t	2026-05-13 21:50:54.625	2026-05-13 21:50:54.625
cmp4lhp6p002rivh6kzvkna6t	TOMATE	tomate	\N	t	2026-05-13 21:52:10.946	2026-05-13 21:52:10.946
cmp4ljeck0031ivh6ojhvx0ig	KAPBOOM	kapboom	\N	t	2026-05-13 21:53:30.212	2026-05-13 21:53:30.212
cmp8xck2x0022w6aq785z24tm	Redeagon	redeagon	\N	t	2026-05-16 22:35:11.145	2026-05-16 22:35:11.145
cmp8xdqs0002cw6aqrna35rcd	Redragon	redragon	\N	t	2026-05-16 22:36:06.481	2026-05-16 22:36:06.481
cmp8xi7gz002vw6aqpvtqsdbr	KAPBOM	kapbom	\N	t	2026-05-16 22:39:34.739	2026-05-16 22:39:34.739
cmp8xjis70035w6aqw8365eym	LEHMOX	lehmox	\N	t	2026-05-16 22:40:36.055	2026-05-16 22:40:36.055
cmp8xl52r003fw6aqarjmmay1	VERDE	verde	\N	t	2026-05-16 22:41:51.604	2026-05-16 22:41:51.604
cmp8xmnes003pw6aq8ycf6jpw	INFOKIT	infokit	\N	t	2026-05-16 22:43:02.02	2026-05-16 22:43:02.02
cmp8xqgx8004fw6aqw8rnorrv	B-MAX	b-max	\N	t	2026-05-16 22:46:00.236	2026-05-16 22:46:00.236
cmp8xs21l004pw6aqywjz0gqz	DOBE	dobe	\N	t	2026-05-16 22:47:14.266	2026-05-16 22:47:14.266
cmp8xsyu6004zw6aq7m8wbe2h	X-FIRE	x-fire	\N	t	2026-05-16 22:47:56.767	2026-05-16 22:47:56.767
cmpbd7a6x0000hp9z1jcoiyu3	AUTONOMO	autonomo	\N	t	2026-05-18 15:34:31.257	2026-05-18 15:34:31.257
\.


--
-- Data for Name: Marketplace; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Marketplace" (id, name, "apiCode", active, "createdAt", "updatedAt") FROM stdin;
cmndrx2l7008dxpl674b53e49	Mercado Livre	MLB	t	2026-03-30 22:42:36.764	2026-03-30 22:42:36.764
cmndrx2lh008expl6xsyo98sz	Shopee	SHOPEE	t	2026-03-30 22:42:36.773	2026-03-30 22:42:36.773
\.


--
-- Data for Name: MarketplaceCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MarketplaceCategory" (id, "marketplaceId", "externalCode", "externalName", "categoryId") FROM stdin;
\.


--
-- Data for Name: MarketplaceListing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MarketplaceListing" (id, "marketplaceId", "productId", "variationId", "externalId", "publishedTitle", "publishedPrice", status, "publicLink", "syncStock", "syncPrice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Payable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payable" (id, description, "dueDate", value, "createdAt", "updatedAt", "costCenterId", "supplierId", status, "attachmentUrl", "competenceMonth", "competenceYear", "payableType", "technicianUserId") FROM stdin;
\.


--
-- Data for Name: PaymentFeeSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PaymentFeeSettings" (id, "creditFixedFee", "creditVariableFee", "debitFixedFee", "debitVariableFee", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Permission" (id, action, resource, description, "createdAt", "updatedAt") FROM stdin;
cmndrx1bg0001xpl6e47ioyhi	create	users	Create users	2026-03-30 22:42:35.116	2026-03-30 22:42:35.116
cmndrx1bj0002xpl6xaen492k	read	users	Read users	2026-03-30 22:42:35.12	2026-03-30 22:42:35.12
cmndrx1bn0003xpl6r9oqvl0k	update	users	Update users	2026-03-30 22:42:35.123	2026-03-30 22:42:35.123
cmndrx1br0004xpl6u8dzy2c2	delete	users	Delete users	2026-03-30 22:42:35.127	2026-03-30 22:42:35.127
cmndrx1bv0005xpl6vrg8iwbv	create	clients	Create clients	2026-03-30 22:42:35.131	2026-03-30 22:42:35.131
cmndrx1bz0006xpl608pa99r5	read	clients	Read clients	2026-03-30 22:42:35.135	2026-03-30 22:42:35.135
cmndrx1c30007xpl6i83t4ffk	update	clients	Update clients	2026-03-30 22:42:35.139	2026-03-30 22:42:35.139
cmndrx1c70008xpl6ai01tcxl	delete	clients	Delete clients	2026-03-30 22:42:35.144	2026-03-30 22:42:35.144
cmndrx1cb0009xpl6t0zi9su3	create	products	Create products	2026-03-30 22:42:35.147	2026-03-30 22:42:35.147
cmndrx1cf000axpl65qtnzp9f	read	products	Read products	2026-03-30 22:42:35.151	2026-03-30 22:42:35.151
cmndrx1cj000bxpl6r86rzy8x	update	products	Update products	2026-03-30 22:42:35.155	2026-03-30 22:42:35.155
cmndrx1cn000cxpl6ugq0a971	delete	products	Delete products	2026-03-30 22:42:35.159	2026-03-30 22:42:35.159
cmndrx1cr000dxpl6qqha1it0	read	stock	View stock	2026-03-30 22:42:35.164	2026-03-30 22:42:35.164
cmndrx1cv000expl6gl2fdmfx	manage	stock	Manage stock movements	2026-03-30 22:42:35.168	2026-03-30 22:42:35.168
cmndrx1d0000fxpl63dfm9pus	create	sales	Create sales	2026-03-30 22:42:35.172	2026-03-30 22:42:35.172
cmndrx1d7000hxpl6p4sgwtgv	update	sales	Update sales	2026-03-30 22:42:35.179	2026-03-30 22:42:35.179
cmndrx1da000ixpl6skph158a	delete	sales	Cancel/Delete sales	2026-03-30 22:42:35.182	2026-03-30 22:42:35.182
cmndrx1dd000jxpl61qafwy17	create	os	Create OS	2026-03-30 22:42:35.186	2026-03-30 22:42:35.186
cmndrx1dk000lxpl6wy8uuv3a	update	os	Update OS	2026-03-30 22:42:35.193	2026-03-30 22:42:35.193
cmndrx1do000mxpl6jjrk0psx	delete	os	Delete OS	2026-03-30 22:42:35.196	2026-03-30 22:42:35.196
cmndrx1dr000nxpl66autecuy	read	finance	View financial data	2026-03-30 22:42:35.2	2026-03-30 22:42:35.2
cmndrx1dv000oxpl6h812i6yp	manage	finance	Manage finances	2026-03-30 22:42:35.204	2026-03-30 22:42:35.204
cmndrx1e7000rxpl6wvezoy8c	manage	settings	Manage settings	2026-03-30 22:42:35.216	2026-03-30 22:42:35.216
cmndrx1eb000sxpl6mggqk7s7	manage	admin	System administration	2026-03-30 22:42:35.22	2026-03-30 22:42:35.22
cmndrx1b70000xpl6jccigi0q	read	dashboard	Acesso ao Dashboard	2026-03-30 22:42:35.108	2026-05-16 20:30:15.363
cmnds00rp0002yzzkebdjsz39	read	cash-daily	Acesso ao Caixa Diário	2026-03-30 22:44:54.373	2026-05-16 20:30:15.364
cmnds00sg0003yzzk9z7kham2	read	atendimento	Acesso ao Atendimento	2026-03-30 22:44:54.401	2026-05-16 20:30:15.365
cmnds00t30004yzzkuth4mfti	read	customers	Acesso aos Clientes	2026-03-30 22:44:54.423	2026-05-16 20:30:15.366
cmndvm3rc0004zv1yic8z4jt8	read	employees	Acesso aos Funcionários	2026-03-31 00:26:03.528	2026-05-16 20:30:15.367
cmnds00tb0005yzzkf6wa5kra	read	registers	Acesso ao Controle (Cadastros)	2026-03-30 22:44:54.431	2026-05-16 20:30:15.368
cmndrx1d3000gxpl6q7m2ps0y	read	sales	Acesso a Vendas	2026-03-30 22:42:35.176	2026-05-16 20:30:15.369
cmndrx1dh000kxpl6u4n3rleq	read	os	Acesso às OS	2026-03-30 22:42:35.189	2026-05-16 20:30:15.37
cmnds00vi0008yzzk00nxraxn	read	financial	Acesso ao Financeiro	2026-03-30 22:44:54.51	2026-05-16 20:30:15.371
cmndrx1dz000pxpl6xabhqxke	read	reports	Acesso aos Relatórios	2026-03-30 22:42:35.208	2026-05-16 20:30:15.372
cmnds00wq000ayzzk0qaf0grf	read	admin	Acesso ao Admin	2026-03-30 22:44:54.554	2026-05-16 20:30:15.373
cmndrx1e3000qxpl6qvxu5970	read	settings	Acesso às Configurações	2026-03-30 22:42:35.211	2026-05-16 20:30:15.374
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, price, barcode, "createdAt", "updatedAt", active, condition, "originClientId", "supplierId", type, ncm, unit, "allowUsed", "baseSku", "commercialName", commission, "controlSerialNumber", height, length, location, "longDescription", margin, "shortDescription", "warrantyMonths", weight, width, "categoryId", "manufacturerId") FROM stdin;
cmp4l4eyr000civh64zs9vk28	120.00	999397990985	2026-05-13 21:41:51.164	2026-05-13 21:41:51.164	t	NEW	\N	\N	PRODUCT	\N	6	t	\N	Controle de PS3	0.00	f	0.00	0.00	\N		0.00	Controle  de Ps3	3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2ie007kxpl6bhlkery8
cmp4l5x73000livh6e8dqb5ct	350.00	046271272696	2026-05-13 21:43:01.456	2026-05-13 21:43:01.456	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Controle de PS4	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2ie007kxpl6bhlkery8
cmp4l7hx0000uivh6gnj2o86a	50.00	986981864441	2026-05-13 21:44:14.964	2026-05-13 21:44:14.964	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Momory Card	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2f20070xpl6dbckhnh5	cmndrx2ie007kxpl6bhlkery8
cmp4l8p1b0013ivh6ntebyikt	150.00	761970424664	2026-05-13 21:45:10.847	2026-05-13 21:45:10.847	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Controle de Xbox 360 com fio	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2ix007qxpl6pc6856ln
cmp4lakm1001divh6kn1gvdj9	110.00	290656382213	2026-05-13 21:46:38.426	2026-05-13 21:46:38.426	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Teclado Gamer KNUP membrana	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4l9r40001aivh634fhy8db
cmpbd8mg80003hp9ziap0erdt	50.00	583461755504	2026-05-18 15:35:33.8	2026-05-18 15:35:33.8	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Dragon Ball Z	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbda5e1000chp9zgwxvbz4o	50.00	423447752656	2026-05-18 15:36:45.001	2026-05-18 15:36:45.001	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Adão Negro	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmp4lbcuf001livh64rv7tig2	70.00	806668657705	2026-05-13 21:47:15.015	2026-05-13 21:47:59.647	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Mouse Gamer Hmaston	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4lb1fh001iivh6rs8an7h1
cmp4lddeu001xivh6o1ao0yq9	70.00	678333443785	2026-05-13 21:48:49.062	2026-05-13 21:48:49.062	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Mousepad com led DELTA	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4lcq04001uivh6h6qmo7ms
cmp4lefz70024ivh6a7uukowt	50.00	373782694112	2026-05-13 21:49:39.044	2026-05-13 21:49:39.044	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Bateria controle Xbox One	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2ix007qxpl6pc6856ln
cmp4lfmc5002civh6vvzrcyg2	120.00	137157834507	2026-05-13 21:50:33.942	2026-05-13 21:50:33.942	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Fone Gamer BT	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4leyte0029ivh64n6fimlg
cmp4lh2kr002kivh6c6jsf9ui	90.00	847707617137	2026-05-13 21:51:41.644	2026-05-13 21:51:41.644	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Kit pilha 2A MOX	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4lg2ap002hivh637gwfgrq
cmp4lisdw002uivh6t1fs2q78	150.00	511187674956	2026-05-13 21:53:01.748	2026-05-13 21:53:01.748	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Kit controle extra games stick	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4lhp6p002rivh6kzvkna6t
cmp4lk7ug0034ivh6osmxceyv	70.00	549742114442	2026-05-13 21:54:08.44	2026-05-13 21:54:08.44	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Antena WI-FI	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4ljeck0031ivh6ojhvx0ig
cmp4lnahr003divh671q78k09	4500.00	135664116205	2026-05-13 21:56:31.839	2026-05-13 21:56:31.839	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Playstation 5 Slim Digital	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2cp0060xpl69fqhprbq	cmndrx2ie007kxpl6bhlkery8
cmp5hyf7f003mivh6x5pngsbj	50.00	389282939870	2026-05-14 13:00:58.874	2026-05-14 13:00:58.874	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Bateria controle Xbox One	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2ix007qxpl6pc6856ln
cmp5hz7u0003vivh6rfw9jfkc	110.00	230429773247	2026-05-14 13:01:35.976	2026-05-14 13:01:35.976	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Teclado Gamer KNUP membrana	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp4l9r40001aivh634fhy8db
cmp8xd6px0025w6aqald884sd	170.00	977796835896	2026-05-16 22:35:40.485	2026-05-16 22:35:40.485	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset Ares	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xck2x0022w6aq785z24tm
cmp8xfzhd002fw6aqb65s3zq5	320.00	012687024554	2026-05-16 22:37:51.074	2026-05-16 22:37:51.074	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset Cronus	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xdqs0002cw6aqrna35rcd
cmp8xh6z1002ow6aq8gjqrmf5	280.00	328027933351	2026-05-16 22:38:47.438	2026-05-16 22:38:47.438	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headser Hylas	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xdqs0002cw6aqrna35rcd
cmp8xj0hc002yw6aqc6o6wbom	150.00	435174242269	2026-05-16 22:40:12.337	2026-05-16 22:40:12.337	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset Model KA-903	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xi7gz002vw6aqpvtqsdbr
cmp8xkive0038w6aqaqm8ygam	150.00	879194645755	2026-05-16 22:41:22.826	2026-05-16 22:41:22.826	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset Hyper G.T 7.1	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xjis70035w6aqw8365eym
cmp8xlthk003iw6aq3kue5jwy	0.00	405791167670	2026-05-16 22:42:23.24	2026-05-16 22:42:23.24	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset EJ-010	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xl52r003fw6aqarjmmay1
cmp8xnqkm003sw6aqya7j8i8l	200.00	298005317579	2026-05-16 22:43:52.774	2026-05-16 22:43:52.774	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset GH-X2700	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xmnes003pw6aq8ycf6jpw
cmp8xodpv0041w6aq38bt6apn	140.00	991404044229	2026-05-16 22:44:22.771	2026-05-16 22:44:22.771	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset EJ-010	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xl52r003fw6aqarjmmay1
cmp8xq3nr0048w6aqvvmgykon	370.00	361305272636	2026-05-16 22:45:43.048	2026-05-16 22:45:43.048	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	FONE JBL TUNE 520	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2k10081xpl6y30i96u2
cmp8xrmml004iw6aqmbmmoygm	200.00	972973396355	2026-05-16 22:46:54.285	2026-05-16 22:46:54.285	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset BM218	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xqgx8004fw6aqw8rnorrv
cmp8xsm4g004sw6aqbp05fdt6	300.00	267699677469	2026-05-16 22:47:40.288	2026-05-16 22:47:40.288	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset Multifuncional	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xs21l004pw6aqywjz0gqz
cmp8xtick0052w6aqqi1jmxy7	400.00	403863532497	2026-05-16 22:48:22.053	2026-05-16 22:48:22.053	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Headset Profissional	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmp8xsyu6004zw6aq7m8wbe2h
cmp8xvi13005bw6aqe072x78g	3500.00	413535568386	2026-05-16 22:49:54.952	2026-05-16 22:49:54.952	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Playstation 5 FAT com leitor (semi)	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2ft007cxpl6zucv9gip	cmndrx2ie007kxpl6bhlkery8
cmp8xwcvd005kw6aqp1zizakm	2500.00	983549359458	2026-05-16 22:50:34.922	2026-05-16 22:50:34.922	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Xbox Series S (semi)	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2cp0060xpl69fqhprbq	cmndrx2ix007qxpl6pc6856ln
cmp8xynx1005rw6aq15rqp8be	2500.00	656404365601	2026-05-16 22:52:22.55	2026-05-16 22:52:22.55	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Xbox One x (semi)	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2cp0060xpl69fqhprbq	cmndrx2ix007qxpl6pc6856ln
cmp8y1zkw0060w6aqi7z6z3e0	2000.00	329541225036	2026-05-16 22:54:57.632	2026-05-16 22:54:57.632	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Playstation 4 slim 1 TB	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2cp0060xpl69fqhprbq	cmndrx2ie007kxpl6bhlkery8
cmpbdbc68000lhp9zjo4hiwjz	50.00	170077712976	2026-05-18 15:37:40.448	2026-05-18 15:37:40.448	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Guile Street Fight	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdcfdm000uhp9zeei3saot	50.00	984799115488	2026-05-18 15:38:31.258	2026-05-18 15:38:31.258	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Kuririm	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbddvxl0013hp9z5i19u8wp	50.00	322657640105	2026-05-18 15:39:39.369	2026-05-18 15:39:39.369	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Ken Street Fighter	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdek2f001chp9z269415qv	50.00	516173965133	2026-05-18 15:40:10.646	2026-05-18 15:40:10.646	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Hulk	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdfm2m001lhp9zc7tdf878	50.00	441697450120	2026-05-18 15:40:59.902	2026-05-18 15:40:59.902	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Flash	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdgdyw001uhp9zukj9f6te	50.00	008104225104	2026-05-18 15:41:36.056	2026-05-18 15:41:36.056	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdig6i002chp9zouqpo40z	50.00	564810325675	2026-05-18 15:43:12.235	2026-05-18 15:43:12.235	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Rainden MK	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdk1bc002uhp9zipdjiekq	100.00	953086813211	2026-05-18 15:44:26.28	2026-05-18 15:44:26.28	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Busto Thanos	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdhayi0023hp9z2ome0gtx	50.00	918185074860	2026-05-18 15:42:18.81	2026-05-18 15:42:18.81	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Pinguim Batman	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdjemj002lhp9zdcphsrho	50.00	816715920160	2026-05-18 15:43:56.875	2026-05-18 15:43:56.875	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Sub Zero ROXO	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdl8be0033hp9za0ang19e	50.00	580235290513	2026-05-18 15:45:22.01	2026-05-18 15:45:22.01	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Cyborg	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdmr4j003chp9zlcnvcdus	50.00	324313962616	2026-05-18 15:46:33.043	2026-05-18 15:46:33.043	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Jason	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdninq003lhp9zy3kgn3kg	50.00	486291677709	2026-05-18 15:47:08.726	2026-05-18 15:47:08.726	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta IT a coisa	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdpmfc003uhp9zzc4ipa94	50.00	592615074822	2026-05-18 15:48:46.921	2026-05-18 15:48:46.921	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Youndu	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdr8wd0043hp9z703u4pbn	50.00	697982575491	2026-05-18 15:50:02.702	2026-05-18 15:50:02.702	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Falcão Capitão América	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbds2g7004chp9zvoquqrsq	50.00	006998268088	2026-05-18 15:50:40.999	2026-05-18 15:50:40.999	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta DRAX	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdtj26004lhp9z5kux5916	50.00	617568694516	2026-05-18 15:51:49.182	2026-05-18 15:51:49.182	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Blanka Street Fighter	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
cmpbdw91j004uhp9zi74rdcwq	50.00	366627958801	2026-05-18 15:53:56.168	2026-05-18 15:53:56.168	t	NEW	\N	\N	PRODUCT	\N	UN	t	\N	Estatueta Aquamen	0.00	f	0.00	0.00	\N		0.00		3	0.000	0.00	cmndrx2fz007fxpl68zusnpei	cmpbd7a6x0000hp9z1jcoiyu3
\.


--
-- Data for Name: ProductAttribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductAttribute" (id, "productId", "attributeId", value) FROM stdin;
cmp4l4eyr000eivh6z0qey8me	cmp4l4eyr000civh64zs9vk28	cmndrx2ky008axpl6rsxpx90g	3
cmp4l5x74000nivh67dlxm6tb	cmp4l5x73000livh6e8dqb5ct	cmndrx2ky008axpl6rsxpx90g	3
cmp4l7hx0000wivh6m39z3pdi	cmp4l7hx0000uivh6gnj2o86a	cmndrx2ky008axpl6rsxpx90g	3
cmp4l8p1b0015ivh6od1xi79p	cmp4l8p1b0013ivh6ntebyikt	cmndrx2ky008axpl6rsxpx90g	3
cmp4lakm1001fivh6i6wb7lqp	cmp4lakm1001divh6kn1gvdj9	cmndrx2ky008axpl6rsxpx90g	3
cmp4lcbai001rivh68jlsyb8s	cmp4lbcuf001livh64rv7tig2	cmndrx2ky008axpl6rsxpx90g	3
cmp4lddeu001zivh6uk6zcr4f	cmp4lddeu001xivh6o1ao0yq9	cmndrx2ky008axpl6rsxpx90g	3
cmp4lefz70026ivh6z3hp0ylq	cmp4lefz70024ivh6a7uukowt	cmndrx2ky008axpl6rsxpx90g	3
cmp4lfmc5002eivh68pbt8inq	cmp4lfmc5002civh6vvzrcyg2	cmndrx2ky008axpl6rsxpx90g	3
cmp4lh2kr002mivh6b6o09l0a	cmp4lh2kr002kivh6c6jsf9ui	cmndrx2ky008axpl6rsxpx90g	3
cmp4lisdw002wivh6i2gmnuh6	cmp4lisdw002uivh6t1fs2q78	cmndrx2ky008axpl6rsxpx90g	3
cmp4lk7ug0036ivh6i9oz130d	cmp4lk7ug0034ivh6osmxceyv	cmndrx2ky008axpl6rsxpx90g	3
cmp4lnahr003fivh6mlw92x58	cmp4lnahr003divh671q78k09	cmndrx2ky008axpl6rsxpx90g	3
cmp5hyf7f003oivh6jvjrt0uk	cmp5hyf7f003mivh6x5pngsbj	cmndrx2ky008axpl6rsxpx90g	3
cmp5hz7u0003xivh6xcalnq9h	cmp5hz7u0003vivh6rfw9jfkc	cmndrx2ky008axpl6rsxpx90g	3
cmp8xd6q00027w6aqd308j4qp	cmp8xd6px0025w6aqald884sd	cmndrx2ky008axpl6rsxpx90g	3
cmp8xfzhe002hw6aqqcemnfyw	cmp8xfzhd002fw6aqb65s3zq5	cmndrx2ky008axpl6rsxpx90g	3
cmp8xh6z2002qw6aqpvdqseo6	cmp8xh6z1002ow6aq8gjqrmf5	cmndrx2ky008axpl6rsxpx90g	3
cmp8xj0hc0030w6aqniznmpcb	cmp8xj0hc002yw6aqc6o6wbom	cmndrx2ky008axpl6rsxpx90g	3
cmp8xkive003aw6aqmn1b5786	cmp8xkive0038w6aqaqm8ygam	cmndrx2ky008axpl6rsxpx90g	3
cmp8xlthk003kw6aq2ryovnsr	cmp8xlthk003iw6aq3kue5jwy	cmndrx2ky008axpl6rsxpx90g	3
cmp8xnqkm003uw6aqo0wc42cg	cmp8xnqkm003sw6aqya7j8i8l	cmndrx2ky008axpl6rsxpx90g	3
cmp8xodpv0043w6aqx2z756ex	cmp8xodpv0041w6aq38bt6apn	cmndrx2ky008axpl6rsxpx90g	3
cmp8xq3ns004aw6aq6cbp3cwx	cmp8xq3nr0048w6aqvvmgykon	cmndrx2ky008axpl6rsxpx90g	3
cmp8xrmml004kw6aqzlk7k016	cmp8xrmml004iw6aqmbmmoygm	cmndrx2ky008axpl6rsxpx90g	3
cmp8xsm4g004uw6aqhzra5i58	cmp8xsm4g004sw6aqbp05fdt6	cmndrx2ky008axpl6rsxpx90g	3
cmp8xtick0054w6aqb804l0ja	cmp8xtick0052w6aqqi1jmxy7	cmndrx2ky008axpl6rsxpx90g	3
cmp8xvi13005dw6aqgftijvg2	cmp8xvi13005bw6aqe072x78g	cmndrx2ky008axpl6rsxpx90g	3
cmp8xwcvd005mw6aqbkc9nx74	cmp8xwcvd005kw6aqp1zizakm	cmndrx2ky008axpl6rsxpx90g	3
cmp8xynx2005tw6aqo49cm91w	cmp8xynx1005rw6aq15rqp8be	cmndrx2ky008axpl6rsxpx90g	3
cmp8y1zkw0062w6aqk348s3pt	cmp8y1zkw0060w6aqi7z6z3e0	cmndrx2ky008axpl6rsxpx90g	3
cmpbd8mg90005hp9zcvmxu3ie	cmpbd8mg80003hp9ziap0erdt	cmndrx2ky008axpl6rsxpx90g	3
cmpbda5e1000ehp9z2wxyltfq	cmpbda5e1000chp9zgwxvbz4o	cmndrx2ky008axpl6rsxpx90g	3
cmpbdbc68000nhp9z827fxbya	cmpbdbc68000lhp9zjo4hiwjz	cmndrx2ky008axpl6rsxpx90g	3
cmpbdcfdm000whp9zaatzmzvq	cmpbdcfdm000uhp9zeei3saot	cmndrx2ky008axpl6rsxpx90g	3
cmpbddvxl0015hp9zv6q337ih	cmpbddvxl0013hp9z5i19u8wp	cmndrx2ky008axpl6rsxpx90g	3
cmpbdek2f001ehp9z9xajjmnb	cmpbdek2f001chp9z269415qv	cmndrx2ky008axpl6rsxpx90g	3
cmpbdfm2m001nhp9zviwpqclu	cmpbdfm2m001lhp9zc7tdf878	cmndrx2ky008axpl6rsxpx90g	3
cmpbdgdyw001whp9zcp6ctfgb	cmpbdgdyw001uhp9zukj9f6te	cmndrx2ky008axpl6rsxpx90g	3
cmpbdhayi0025hp9zdlaegtjv	cmpbdhayi0023hp9z2ome0gtx	cmndrx2ky008axpl6rsxpx90g	3
cmpbdig6j002ehp9zlm86hmlz	cmpbdig6i002chp9zouqpo40z	cmndrx2ky008axpl6rsxpx90g	3
cmpbdjemj002nhp9zqp8nl462	cmpbdjemj002lhp9zdcphsrho	cmndrx2ky008axpl6rsxpx90g	3
cmpbdk1bc002whp9zx1nlmrck	cmpbdk1bc002uhp9zipdjiekq	cmndrx2ky008axpl6rsxpx90g	3
cmpbdl8be0035hp9z1xz2zfxq	cmpbdl8be0033hp9za0ang19e	cmndrx2ky008axpl6rsxpx90g	3
cmpbdmr4j003ehp9ziynrzeic	cmpbdmr4j003chp9zlcnvcdus	cmndrx2ky008axpl6rsxpx90g	3
cmpbdninq003nhp9zpdcg78hc	cmpbdninq003lhp9zy3kgn3kg	cmndrx2ky008axpl6rsxpx90g	3
cmpbdpmfc003whp9zy6axil16	cmpbdpmfc003uhp9zzc4ipa94	cmndrx2ky008axpl6rsxpx90g	3
cmpbdr8wd0045hp9zl2gq57nj	cmpbdr8wd0043hp9z703u4pbn	cmndrx2ky008axpl6rsxpx90g	3
cmpbds2g7004ehp9z3hrsyug8	cmpbds2g7004chp9zvoquqrsq	cmndrx2ky008axpl6rsxpx90g	3
cmpbdtj26004nhp9zxi7pbpx0	cmpbdtj26004lhp9z5kux5916	cmndrx2ky008axpl6rsxpx90g	3
cmpbdw91j004whp9zv8dxa1og	cmpbdw91j004uhp9zi74rdcwq	cmndrx2ky008axpl6rsxpx90g	3
\.


--
-- Data for Name: ProductPriceHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductPriceHistory" (id, "productId", "oldPrice", "newPrice", "changedBy", "createdAt") FROM stdin;
\.


--
-- Data for Name: ProductVariation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductVariation" (id, "productId", sku, title, "basePrice", active) FROM stdin;
\.


--
-- Data for Name: RateLimit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RateLimit" (key, timestamps, "updatedAt") FROM stdin;
public-os:31.97.241.127	[1779215565120]	2026-05-19 18:32:45.137222
\.


--
-- Data for Name: Receivable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Receivable" (id, description, "dueDate", value, "createdAt", "updatedAt", "costCenterId", "customerId", "saleId", "serviceOrderId", status, "paymentMethod", "cardFeePercent", "cardFeeValue", "netValue", "paidAt", origin) FROM stdin;
cmp8x2ez1001ww6aqq6h8x7pg	OS #R40AT1 - Entrega	2026-05-16 22:27:17.964	250.00	2026-05-16 22:27:17.965	2026-05-16 22:27:17.981	cmndrx2cg005vxpl62o4lz70v	cmp8s3n2v000cw6aqlssmcyvi	\N	cmp8s5rah000hw6aqd7r40at1	PAID	CREDITO	\N	\N	250.00	2026-05-16 22:27:17.978	SERVICE
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Role" (id, name, description, "createdAt", "updatedAt") FROM stdin;
cmndrx1ej000txpl6qndp3u9o	ADMIN	Administrator	2026-03-30 22:42:35.227	2026-03-30 22:42:35.227
cmndrx1wl0041xpl6b8kfhqng	SELLER	Sales Person	2026-03-30 22:42:35.878	2026-03-30 22:42:35.878
cmndrx1zl004wxpl61rok9i7m	TECH	Technician	2026-03-30 22:42:35.985	2026-03-30 22:42:35.985
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RolePermission" (id, "roleId", "permissionId", "createdAt", "updatedAt") FROM stdin;
cmndrx1eo000vxpl6269wldht	cmndrx1ej000txpl6qndp3u9o	cmndrx1b70000xpl6jccigi0q	2026-03-30 22:42:35.232	2026-03-30 22:42:35.232
cmndrx1f0000xxpl6ijs37qg5	cmndrx1ej000txpl6qndp3u9o	cmndrx1bg0001xpl6e47ioyhi	2026-03-30 22:42:35.244	2026-03-30 22:42:35.244
cmndrx1fb000zxpl6czsad50y	cmndrx1ej000txpl6qndp3u9o	cmndrx1bj0002xpl6xaen492k	2026-03-30 22:42:35.255	2026-03-30 22:42:35.255
cmndrx1fi0011xpl64n4uq0vc	cmndrx1ej000txpl6qndp3u9o	cmndrx1bn0003xpl6r9oqvl0k	2026-03-30 22:42:35.262	2026-03-30 22:42:35.262
cmndrx1fp0013xpl6507f7djd	cmndrx1ej000txpl6qndp3u9o	cmndrx1br0004xpl6u8dzy2c2	2026-03-30 22:42:35.269	2026-03-30 22:42:35.269
cmndrx1fv0015xpl670r808wl	cmndrx1ej000txpl6qndp3u9o	cmndrx1bv0005xpl6vrg8iwbv	2026-03-30 22:42:35.276	2026-03-30 22:42:35.276
cmndrx1g20017xpl6cll72cdi	cmndrx1ej000txpl6qndp3u9o	cmndrx1bz0006xpl608pa99r5	2026-03-30 22:42:35.283	2026-03-30 22:42:35.283
cmndrx1g90019xpl6rlreke49	cmndrx1ej000txpl6qndp3u9o	cmndrx1c30007xpl6i83t4ffk	2026-03-30 22:42:35.289	2026-03-30 22:42:35.289
cmndrx1gg001bxpl6n5b21ja1	cmndrx1ej000txpl6qndp3u9o	cmndrx1c70008xpl6ai01tcxl	2026-03-30 22:42:35.297	2026-03-30 22:42:35.297
cmndrx1go001dxpl6zet9pln9	cmndrx1ej000txpl6qndp3u9o	cmndrx1cb0009xpl6t0zi9su3	2026-03-30 22:42:35.304	2026-03-30 22:42:35.304
cmndrx1gv001fxpl6aqlepr1m	cmndrx1ej000txpl6qndp3u9o	cmndrx1cf000axpl65qtnzp9f	2026-03-30 22:42:35.311	2026-03-30 22:42:35.311
cmndrx1h2001hxpl6nzvu9tws	cmndrx1ej000txpl6qndp3u9o	cmndrx1cj000bxpl6r86rzy8x	2026-03-30 22:42:35.318	2026-03-30 22:42:35.318
cmndrx1h9001jxpl6yptd3y4r	cmndrx1ej000txpl6qndp3u9o	cmndrx1cn000cxpl6ugq0a971	2026-03-30 22:42:35.325	2026-03-30 22:42:35.325
cmndrx1hg001lxpl6y0knnhof	cmndrx1ej000txpl6qndp3u9o	cmndrx1cr000dxpl6qqha1it0	2026-03-30 22:42:35.332	2026-03-30 22:42:35.332
cmndrx1hn001nxpl60anyjxsw	cmndrx1ej000txpl6qndp3u9o	cmndrx1cv000expl6gl2fdmfx	2026-03-30 22:42:35.339	2026-03-30 22:42:35.339
cmndrx1hw001pxpl6d9tqprhg	cmndrx1ej000txpl6qndp3u9o	cmndrx1d0000fxpl63dfm9pus	2026-03-30 22:42:35.349	2026-03-30 22:42:35.349
cmndrx1i6001rxpl6m5mclquo	cmndrx1ej000txpl6qndp3u9o	cmndrx1d3000gxpl6q7m2ps0y	2026-03-30 22:42:35.359	2026-03-30 22:42:35.359
cmndrx1ih001txpl61ecrarqf	cmndrx1ej000txpl6qndp3u9o	cmndrx1d7000hxpl6p4sgwtgv	2026-03-30 22:42:35.369	2026-03-30 22:42:35.369
cmndrx1is001vxpl6kpnadpg9	cmndrx1ej000txpl6qndp3u9o	cmndrx1da000ixpl6skph158a	2026-03-30 22:42:35.38	2026-03-30 22:42:35.38
cmndrx1j4001xxpl6ao1m42la	cmndrx1ej000txpl6qndp3u9o	cmndrx1dd000jxpl61qafwy17	2026-03-30 22:42:35.393	2026-03-30 22:42:35.393
cmndrx1jh001zxpl6ko8dpp6l	cmndrx1ej000txpl6qndp3u9o	cmndrx1dh000kxpl6u4n3rleq	2026-03-30 22:42:35.405	2026-03-30 22:42:35.405
cmndrx1k20021xpl6k18l0m18	cmndrx1ej000txpl6qndp3u9o	cmndrx1dk000lxpl6wy8uuv3a	2026-03-30 22:42:35.426	2026-03-30 22:42:35.426
cmndrx1kd0023xpl6ayhm4816	cmndrx1ej000txpl6qndp3u9o	cmndrx1do000mxpl6jjrk0psx	2026-03-30 22:42:35.437	2026-03-30 22:42:35.437
cmndrx1kq0025xpl6ifzownu5	cmndrx1ej000txpl6qndp3u9o	cmndrx1dr000nxpl66autecuy	2026-03-30 22:42:35.45	2026-03-30 22:42:35.45
cmndrx1l00027xpl6gta8ki6v	cmndrx1ej000txpl6qndp3u9o	cmndrx1dv000oxpl6h812i6yp	2026-03-30 22:42:35.46	2026-03-30 22:42:35.46
cmndrx1l80029xpl6aaqk6wjg	cmndrx1ej000txpl6qndp3u9o	cmndrx1dz000pxpl6xabhqxke	2026-03-30 22:42:35.469	2026-03-30 22:42:35.469
cmndrx1lg002bxpl6gbezirim	cmndrx1ej000txpl6qndp3u9o	cmndrx1e3000qxpl6qvxu5970	2026-03-30 22:42:35.476	2026-03-30 22:42:35.476
cmndrx1lt002dxpl6rzvkd50h	cmndrx1ej000txpl6qndp3u9o	cmndrx1e7000rxpl6wvezoy8c	2026-03-30 22:42:35.489	2026-03-30 22:42:35.489
cmndrx1m5002fxpl6s0mrdg7z	cmndrx1ej000txpl6qndp3u9o	cmndrx1eb000sxpl6mggqk7s7	2026-03-30 22:42:35.501	2026-03-30 22:42:35.501
cmndrx1wp0043xpl6oi026ncc	cmndrx1wl0041xpl6b8kfhqng	cmndrx1b70000xpl6jccigi0q	2026-03-30 22:42:35.881	2026-03-30 22:42:35.881
cmndrx1wv0045xpl6c2qeafc2	cmndrx1wl0041xpl6b8kfhqng	cmndrx1bv0005xpl6vrg8iwbv	2026-03-30 22:42:35.888	2026-03-30 22:42:35.888
cmndrx1x20047xpl6issk77q4	cmndrx1wl0041xpl6b8kfhqng	cmndrx1bz0006xpl608pa99r5	2026-03-30 22:42:35.895	2026-03-30 22:42:35.895
cmndrx1xa0049xpl6sctepul3	cmndrx1wl0041xpl6b8kfhqng	cmndrx1c30007xpl6i83t4ffk	2026-03-30 22:42:35.902	2026-03-30 22:42:35.902
cmndrx1xh004bxpl6ro22055y	cmndrx1wl0041xpl6b8kfhqng	cmndrx1c70008xpl6ai01tcxl	2026-03-30 22:42:35.909	2026-03-30 22:42:35.909
cmndrx1xo004dxpl6vb0bwh53	cmndrx1wl0041xpl6b8kfhqng	cmndrx1cb0009xpl6t0zi9su3	2026-03-30 22:42:35.916	2026-03-30 22:42:35.916
cmndrx1xu004fxpl6dcgcyu9k	cmndrx1wl0041xpl6b8kfhqng	cmndrx1cf000axpl65qtnzp9f	2026-03-30 22:42:35.922	2026-03-30 22:42:35.922
cmndrx1y0004hxpl663crqgfd	cmndrx1wl0041xpl6b8kfhqng	cmndrx1cj000bxpl6r86rzy8x	2026-03-30 22:42:35.929	2026-03-30 22:42:35.929
cmndrx1y6004jxpl6534d7265	cmndrx1wl0041xpl6b8kfhqng	cmndrx1cn000cxpl6ugq0a971	2026-03-30 22:42:35.935	2026-03-30 22:42:35.935
cmndrx1ye004lxpl6ny7hvl4z	cmndrx1wl0041xpl6b8kfhqng	cmndrx1cr000dxpl6qqha1it0	2026-03-30 22:42:35.943	2026-03-30 22:42:35.943
cmndrx1yl004nxpl66363u6sb	cmndrx1wl0041xpl6b8kfhqng	cmndrx1cv000expl6gl2fdmfx	2026-03-30 22:42:35.95	2026-03-30 22:42:35.95
cmndrx1yt004pxpl63azzz9g1	cmndrx1wl0041xpl6b8kfhqng	cmndrx1d0000fxpl63dfm9pus	2026-03-30 22:42:35.957	2026-03-30 22:42:35.957
cmndrx1z0004rxpl6liivb824	cmndrx1wl0041xpl6b8kfhqng	cmndrx1d3000gxpl6q7m2ps0y	2026-03-30 22:42:35.964	2026-03-30 22:42:35.964
cmndrx1z7004txpl69zn8bn3a	cmndrx1wl0041xpl6b8kfhqng	cmndrx1d7000hxpl6p4sgwtgv	2026-03-30 22:42:35.971	2026-03-30 22:42:35.971
cmndrx1ze004vxpl62sly61jv	cmndrx1wl0041xpl6b8kfhqng	cmndrx1da000ixpl6skph158a	2026-03-30 22:42:35.978	2026-03-30 22:42:35.978
cmndrx1zo004yxpl6j1fv8rc1	cmndrx1zl004wxpl61rok9i7m	cmndrx1b70000xpl6jccigi0q	2026-03-30 22:42:35.989	2026-03-30 22:42:35.989
cmndrx1zw0050xpl6w67xpqal	cmndrx1zl004wxpl61rok9i7m	cmndrx1bv0005xpl6vrg8iwbv	2026-03-30 22:42:35.996	2026-03-30 22:42:35.996
cmndrx2030052xpl6ok71k7pp	cmndrx1zl004wxpl61rok9i7m	cmndrx1bz0006xpl608pa99r5	2026-03-30 22:42:36.003	2026-03-30 22:42:36.003
cmndrx20a0054xpl6oaxait2r	cmndrx1zl004wxpl61rok9i7m	cmndrx1c30007xpl6i83t4ffk	2026-03-30 22:42:36.011	2026-03-30 22:42:36.011
cmndrx20h0056xpl6qv7o64cw	cmndrx1zl004wxpl61rok9i7m	cmndrx1c70008xpl6ai01tcxl	2026-03-30 22:42:36.017	2026-03-30 22:42:36.017
cmndrx20n0058xpl6njuvle97	cmndrx1zl004wxpl61rok9i7m	cmndrx1cb0009xpl6t0zi9su3	2026-03-30 22:42:36.023	2026-03-30 22:42:36.023
cmndrx20t005axpl6r57wh608	cmndrx1zl004wxpl61rok9i7m	cmndrx1cf000axpl65qtnzp9f	2026-03-30 22:42:36.029	2026-03-30 22:42:36.029
cmndrx210005cxpl65gfgbpjq	cmndrx1zl004wxpl61rok9i7m	cmndrx1cj000bxpl6r86rzy8x	2026-03-30 22:42:36.036	2026-03-30 22:42:36.036
cmndrx218005expl6yks5qfp1	cmndrx1zl004wxpl61rok9i7m	cmndrx1cn000cxpl6ugq0a971	2026-03-30 22:42:36.044	2026-03-30 22:42:36.044
cmndrx21f005gxpl63l9xp955	cmndrx1zl004wxpl61rok9i7m	cmndrx1dd000jxpl61qafwy17	2026-03-30 22:42:36.051	2026-03-30 22:42:36.051
cmndrx21m005ixpl63ln0xzc5	cmndrx1zl004wxpl61rok9i7m	cmndrx1dh000kxpl6u4n3rleq	2026-03-30 22:42:36.058	2026-03-30 22:42:36.058
cmndrx21u005kxpl6hih7y5h0	cmndrx1zl004wxpl61rok9i7m	cmndrx1dk000lxpl6wy8uuv3a	2026-03-30 22:42:36.066	2026-03-30 22:42:36.066
cmndrx221005mxpl6k3zjcsio	cmndrx1zl004wxpl61rok9i7m	cmndrx1do000mxpl6jjrk0psx	2026-03-30 22:42:36.073	2026-03-30 22:42:36.073
cmnds2mr9003qyzzkfrigwzza	cmndrx1ej000txpl6qndp3u9o	cmnds00rp0002yzzkebdjsz39	2026-03-30 22:46:56.172	2026-03-30 22:46:56.172
cmnds2msd003syzzk7tkusvje	cmndrx1ej000txpl6qndp3u9o	cmnds00tb0005yzzkf6wa5kra	2026-03-30 22:46:56.199	2026-03-30 22:46:56.199
cmnds2mtq003wyzzkiv1aqpgi	cmndrx1ej000txpl6qndp3u9o	cmnds00vi0008yzzk00nxraxn	2026-03-30 22:46:56.271	2026-03-30 22:46:56.271
cmnds2mtl003uyzzk9kxlvo4w	cmndrx1ej000txpl6qndp3u9o	cmnds00t30004yzzkuth4mfti	2026-03-30 22:46:56.255	2026-03-30 22:46:56.255
cmnds2mxu0040yzzk6k4onhrj	cmndrx1ej000txpl6qndp3u9o	cmnds00wq000ayzzk0qaf0grf	2026-03-30 22:46:56.318	2026-03-30 22:46:56.318
cmnds2mxt003yyzzkhxq5h77z	cmndrx1ej000txpl6qndp3u9o	cmnds00sg0003yzzk9z7kham2	2026-03-30 22:46:56.265	2026-03-30 22:46:56.265
cmndvmcvo0017zv1y16bcye0y	cmndrx1ej000txpl6qndp3u9o	cmndvm3rc0004zv1yic8z4jt8	2026-03-31 00:26:15.346	2026-03-31 00:26:15.346
\.


--
-- Data for Name: Sale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Sale" (id, date, total, "createdAt", "updatedAt", "createdBy", "customerId", discount, installments, "paymentMethod", status) FROM stdin;
\.


--
-- Data for Name: SaleItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SaleItem" (id, "saleId", "productId", quantity, "unitPrice", "costPrice", total, "warrantyMonths") FROM stdin;
\.


--
-- Data for Name: SaleReturn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SaleReturn" (id, "saleId", "customerId", reason, notes, status, type, "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: SaleReturnItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SaleReturnItem" (id, "saleReturnId", "productId", quantity, "unitPrice", reason) FROM stdin;
\.


--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Service" (id, name, active, "createdAt", "updatedAt", "commissionType", "commissionValue", "descriptionShort", "estimatedTimeMin", "internalCode", "marketplaceCategoryId", "marketplaceDescTemplate", "marketplaceTitleTemplate", "priceBase", "priceType", "warrantyMonths") FROM stdin;
cmndrx2lq008fxpl6w6niczts	Diagnóstico básico de desktop	t	2026-03-30 22:42:36.783	2026-03-30 22:42:36.783	PERCENT	0.00	Diagnóstico básico de desktop	\N	SRV-0001	\N	\N	\N	60.00	FIXED	\N
cmndrx2lw008gxpl6ri2q6i25	Diagnóstico básico de notebook	t	2026-03-30 22:42:36.788	2026-03-30 22:42:36.788	PERCENT	0.00	Diagnóstico básico de notebook	\N	SRV-0002	\N	\N	\N	70.00	FIXED	\N
cmndrx2m0008hxpl6rcwcroco	Diagnóstico avançado de hardware	t	2026-03-30 22:42:36.792	2026-03-30 22:42:36.792	PERCENT	0.00	Diagnóstico avançado de hardware	\N	SRV-0003	\N	\N	\N	120.00	FIXED	\N
cmndrx2m3008ixpl6dipo2bf9	Formatação de desktop sem backup	t	2026-03-30 22:42:36.795	2026-03-30 22:42:36.795	PERCENT	0.00	Formatação de desktop sem backup	\N	SRV-0004	\N	\N	\N	100.00	FIXED	\N
cmndrx2m6008jxpl6xftcmhf2	Formatação de notebook sem backup	t	2026-03-30 22:42:36.799	2026-03-30 22:42:36.799	PERCENT	0.00	Formatação de notebook sem backup	\N	SRV-0005	\N	\N	\N	100.00	FIXED	\N
cmndrx2ma008kxpl6s1dzku38	Reinstalação de Windows com drivers	t	2026-03-30 22:42:36.802	2026-03-30 22:42:36.802	PERCENT	0.00	Reinstalação de Windows com drivers	\N	SRV-0006	\N	\N	\N	150.00	FIXED	\N
cmndrx2me008lxpl6idac4sb6	Instalação de distribuição Linux	t	2026-03-30 22:42:36.806	2026-03-30 22:42:36.806	PERCENT	0.00	Instalação de distribuição Linux	\N	SRV-0007	\N	\N	\N	150.00	FIXED	\N
cmndrx2mh008mxpl68qjmt9yr	Limpeza de vírus e malware	t	2026-03-30 22:42:36.809	2026-03-30 22:42:36.809	PERCENT	0.00	Limpeza de vírus e malware	\N	SRV-0008	\N	\N	\N	120.00	FIXED	\N
cmndrx2mk008nxpl617fde4of	Otimização de sistema	t	2026-03-30 22:42:36.812	2026-03-30 22:42:36.812	PERCENT	0.00	Otimização de sistema	\N	SRV-0009	\N	\N	\N	100.00	FIXED	\N
cmndrx2mn008oxpl6bfkvu205	Limpeza interna completa de desktop	t	2026-03-30 22:42:36.816	2026-03-30 22:42:36.816	PERCENT	0.00	Limpeza interna completa de desktop	\N	SRV-0010	\N	\N	\N	80.00	FIXED	\N
cmndrx2mq008pxpl6otjzj23p	Limpeza interna completa de notebook	t	2026-03-30 22:42:36.819	2026-03-30 22:42:36.819	PERCENT	0.00	Limpeza interna completa de notebook	\N	SRV-0011	\N	\N	\N	120.00	FIXED	\N
cmndrx2mu008qxpl6dapeavb3	Troca de pasta térmica desktop	t	2026-03-30 22:42:36.822	2026-03-30 22:42:36.822	PERCENT	0.00	Troca de pasta térmica desktop	\N	SRV-0012	\N	\N	\N	80.00	FIXED	\N
cmndrx2mx008rxpl6hr4qs2na	Troca de pasta térmica notebook	t	2026-03-30 22:42:36.825	2026-03-30 22:42:36.825	PERCENT	0.00	Troca de pasta térmica notebook	\N	SRV-0013	\N	\N	\N	120.00	FIXED	\N
cmndrx2n0008sxpl6k48juhea	Instalação de memória RAM em desktop	t	2026-03-30 22:42:36.828	2026-03-30 22:42:36.828	PERCENT	0.00	Instalação de memória RAM em desktop	\N	SRV-0014	\N	\N	\N	60.00	FIXED	\N
cmndrx2n3008txpl6cmrs67ow	Instalação de memória RAM em notebook	t	2026-03-30 22:42:36.831	2026-03-30 22:42:36.831	PERCENT	0.00	Instalação de memória RAM em notebook	\N	SRV-0015	\N	\N	\N	80.00	FIXED	\N
cmndrx2n6008uxpl60o9md8ld	Instalação de SSD com clonagem	t	2026-03-30 22:42:36.834	2026-03-30 22:42:36.834	PERCENT	0.00	Instalação de SSD com clonagem	\N	SRV-0016	\N	\N	\N	200.00	FIXED	\N
cmndrx2n9008vxpl6qzt75d4b	Instalação de placa de vídeo dedicada	t	2026-03-30 22:42:36.838	2026-03-30 22:42:36.838	PERCENT	0.00	Instalação de placa de vídeo dedicada	\N	SRV-0017	\N	\N	\N	120.00	FIXED	\N
cmndrx2nc008wxpl6eypvrhho	Instalação de kit placa-mãe/CPU/RAM	t	2026-03-30 22:42:36.841	2026-03-30 22:42:36.841	PERCENT	0.00	Instalação de kit placa-mãe/CPU/RAM	\N	SRV-0018	\N	\N	\N	150.00	FIXED	\N
cmndrx2ng008xxpl6lqwf8vbx	Troca de tela de smartphone	t	2026-03-30 22:42:36.844	2026-03-30 22:42:36.844	PERCENT	0.00	Troca de tela de smartphone	\N	SRV-0019	\N	\N	\N	850.00	FIXED	\N
cmndrx2nj008yxpl60xd8uo9k	Troca de bateria de smartphone	t	2026-03-30 22:42:36.847	2026-03-30 22:42:36.847	PERCENT	0.00	Troca de bateria de smartphone	\N	SRV-0020	\N	\N	\N	180.00	FIXED	\N
cmndrx2nm008zxpl6k8t75rx2	Troca de conector de carga smartphone	t	2026-03-30 22:42:36.85	2026-03-30 22:42:36.85	PERCENT	0.00	Troca de conector de carga smartphone	\N	SRV-0021	\N	\N	\N	150.00	FIXED	\N
cmndrx2np0090xpl66xy5ryb1	Reparo em botão power smartphone	t	2026-03-30 22:42:36.854	2026-03-30 22:42:36.854	PERCENT	0.00	Reparo em botão power smartphone	\N	SRV-0022	\N	\N	\N	150.00	FIXED	\N
cmndrx2ns0091xpl6uizga83z	Desoxidação de placa smartphone	t	2026-03-30 22:42:36.857	2026-03-30 22:42:36.857	PERCENT	0.00	Desoxidação de placa smartphone	\N	SRV-0023	\N	\N	\N	250.00	FIXED	\N
cmndrx2nw0092xpl6f6oysrkg	Diagnóstico de console de videogame	t	2026-03-30 22:42:36.86	2026-03-30 22:42:36.86	PERCENT	0.00	Diagnóstico de console de videogame	\N	SRV-0024	\N	\N	\N	120.00	FIXED	\N
cmndrx2nz0093xpl6kejpnll4	Limpeza interna de console	t	2026-03-30 22:42:36.863	2026-03-30 22:42:36.863	PERCENT	0.00	Limpeza interna de console	\N	SRV-0025	\N	\N	\N	150.00	FIXED	\N
cmndrx2o20094xpl6qn24gvlg	Troca de pasta térmica de console	t	2026-03-30 22:42:36.866	2026-03-30 22:42:36.866	PERCENT	0.00	Troca de pasta térmica de console	\N	SRV-0026	\N	\N	\N	150.00	FIXED	\N
cmndrx2o50095xpl664jr9d5o	Reparo em porta HDMI de console	t	2026-03-30 22:42:36.87	2026-03-30 22:42:36.87	PERCENT	0.00	Reparo em porta HDMI de console	\N	SRV-0027	\N	\N	\N	300.00	FIXED	\N
cmndrx2o80096xpl62pio07qp	Troca de HD por SSD em console	t	2026-03-30 22:42:36.873	2026-03-30 22:42:36.873	PERCENT	0.00	Troca de HD por SSD em console	\N	SRV-0028	\N	\N	\N	250.00	FIXED	\N
cmndrx2oc0097xpl6sgq0fs5i	Reparo drift analógico controle	t	2026-03-30 22:42:36.876	2026-03-30 22:42:36.876	PERCENT	0.00	Reparo drift analógico controle	\N	SRV-0029	\N	\N	\N	120.00	FIXED	\N
cmndrx2of0098xpl6y823e6di	Troca de carcaça de controle	t	2026-03-30 22:42:36.879	2026-03-30 22:42:36.879	PERCENT	0.00	Troca de carcaça de controle	\N	SRV-0030	\N	\N	\N	150.00	FIXED	\N
cmndrx2oi0099xpl62b2d87hp	Configuração de rede Wi-Fi	t	2026-03-30 22:42:36.882	2026-03-30 22:42:36.882	PERCENT	0.00	Configuração de rede Wi-Fi	\N	SRV-0031	\N	\N	\N	100.00	FIXED	\N
cmndrx2ol009axpl62qcl1c8k	Configuração de roteador avançado	t	2026-03-30 22:42:36.885	2026-03-30 22:42:36.885	PERCENT	0.00	Configuração de roteador avançado	\N	SRV-0032	\N	\N	\N	120.00	FIXED	\N
cmndrx2op009bxpl6lhau2q1i	Instalação e configuração de impressora	t	2026-03-30 22:42:36.889	2026-03-30 22:42:36.889	PERCENT	0.00	Instalação e configuração de impressora	\N	SRV-0033	\N	\N	\N	80.00	FIXED	\N
cmndrx2os009cxpl6o4rgoaw8	Suporte remoto por hora	t	2026-03-30 22:42:36.893	2026-03-30 22:42:36.893	PERCENT	0.00	Suporte remoto por hora	\N	SRV-0034	\N	\N	\N	80.00	FIXED	\N
cmndrx2ov009dxpl6li1tmgbm	Atendimento técnico presencial por hora	t	2026-03-30 22:42:36.896	2026-03-30 22:42:36.896	PERCENT	0.00	Atendimento técnico presencial por hora	\N	SRV-0035	\N	\N	\N	150.00	FIXED	\N
cmndrx2p0009expl6u9t8ygrp	Recuperação de dados em HD	t	2026-03-30 22:42:36.9	2026-03-30 22:42:36.9	PERCENT	0.00	Recuperação de dados em HD	\N	SRV-0036	\N	\N	\N	300.00	FIXED	\N
cmndrx2p4009fxpl6vytq0o62	Reballing de GPU/CPU	t	2026-03-30 22:42:36.904	2026-03-30 22:42:36.904	PERCENT	0.00	Reballing de GPU/CPU	\N	SRV-0037	\N	\N	\N	600.00	FIXED	\N
cmndrx2p8009gxpl6iozcbyze	Formatação Playstation	t	2026-03-30 22:42:36.909	2026-03-30 22:42:36.909	PERCENT	0.00	Formatação Playstation	\N	SRV-0038	\N	\N	\N	100.00	FIXED	\N
cmndrx2pc009hxpl6lyi8m5t9	Troca de HD PS4	t	2026-03-30 22:42:36.912	2026-03-30 22:42:36.912	PERCENT	0.00	Troca de HD PS4	\N	SRV-0039	\N	\N	\N	150.00	FIXED	\N
cmndrx2pf009ixpl6z8mhsgrg	Upgrade SSD PS5	t	2026-03-30 22:42:36.915	2026-03-30 22:42:36.915	PERCENT	0.00	Upgrade SSD PS5	\N	SRV-0040	\N	\N	\N	100.00	FIXED	\N
cmndrx2pm009kxpl64r8xcuje	Instalação de jogo digital	t	2026-03-30 22:42:36.922	2026-03-30 22:42:36.922	PERCENT	0.00	Instalação de jogo digital	\N	SRV-0042	\N	\N	\N	50.00	FIXED	\N
cmndrx2pp009lxpl6uds0jmur	Atualização de sistema	t	2026-03-30 22:42:36.926	2026-03-30 22:42:36.926	PERCENT	0.00	Atualização de sistema	\N	SRV-0043	\N	\N	\N	80.00	FIXED	\N
cmndrx2ps009mxpl6mruqvd28	Manutenção controle	t	2026-03-30 22:42:36.929	2026-03-30 22:42:36.929	PERCENT	0.00	Manutenção controle	\N	SRV-0044	\N	\N	\N	80.00	FIXED	\N
cmndrx2pv009nxpl6u5a1vvkf	Troca de analógico controle	t	2026-03-30 22:42:36.932	2026-03-30 22:42:36.932	PERCENT	0.00	Troca de analógico controle	\N	SRV-0045	\N	\N	\N	120.00	FIXED	\N
cmndrx2pi009jxpl6gb5ihu4m	Limpeza interna de Ps5	t	2026-03-30 22:42:36.919	2026-05-16 20:24:13.877	PERCENT	0.00	Limpeza interna console	\N	SRV-0041	\N	\N	\N	250.00	FIXED	0
\.


--
-- Data for Name: ServiceCommissionProvision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ServiceCommissionProvision" (id, "serviceOrderId", "serviceOrderItemId", "serviceId", "technicianUserId", "competenceMonth", "competenceYear", "baseAmount", "commissionPercent", "commissionAmount", status, "paidAt", "payableId", "createdAt", "updatedAt") FROM stdin;
cmp8x2ezp001zw6aq1780szk8	cmp8s5rah000hw6aqd7r40at1	cmp8soi0t000mw6aq6yh24rt5	cmndrx2pi009jxpl6gb5ihu4m	cmp44a4po0006m1n742wbaa42	5	2026	250.00	0.00	0.00	PROVISIONED	\N	\N	2026-05-16 22:27:17.99	2026-05-16 22:27:17.99
\.


--
-- Data for Name: ServiceOrder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ServiceOrder" (id, device, serial, defect, "entryDate", "createdAt", "updatedAt", "customerId", discount, "endDate", notes, report, "technicianId", total, "totalParts", "totalServices", status, priority) FROM stdin;
cmp8s5rah000hw6aqd7r40at1	PLAYSTATION 5 COM LEITOR		SE DESLIGA	2026-05-16 20:09:55.816	2026-05-16 20:09:55.817	2026-05-16 22:27:17.995	cmp8s3n2v000cw6aqlssmcyvi	0.00	2026-05-16 22:27:17.995	\nAcessórios: COMPLETO 	\N	cmp44a4po0006m1n742wbaa42	250.00	0.00	250.00	ENTREGUE	NORMAL
\.


--
-- Data for Name: ServiceOrderHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ServiceOrderHistory" (id, "createdAt", notes, "serviceOrderId", "userId", status) FROM stdin;
cmp8sj9ek000kw6aqithfh2q6	2026-05-16 20:20:25.821	Atribuição automática e início de diagnóstico.	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	DIAGNOSTICO
cmp8sq6x6000pw6aqfp2yo2ps	2026-05-16 20:25:49.194	Após a revisão, conclui se que precisa de uma limpeza completa para parar o desligamento\n	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	DIAGNOSTICO
cmp8sqiz7000sw6aq2ppxco32	2026-05-16 20:26:04.82	Diagnóstico/Orçamento concluído. Enviado para aprovação.	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	AGUARDANDO_APROVACAO
cmp8sqtg1000vw6aqe5h3xb1u	2026-05-16 20:26:18.385	Orçamento aprovado pelo cliente.	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	APROVADO
cmp8ss9n1000yw6aqmw95kbuy	2026-05-16 20:27:26.029	Iniciando reparo após aprovação.	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	EM_REPARO
cmp8x1i2g001tw6aqili65i3q	2026-05-16 22:26:35.32	Serviço finalizado com sucesso.	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	FINALIZADO
cmp8x2ezw0021w6aqri71hqae	2026-05-16 22:27:17.997	Entrega realizada com verificação e pagamento confirmado (Via Sistema).	cmp8s5rah000hw6aqd7r40at1	cmp44a4po0006m1n742wbaa42	ENTREGUE
\.


--
-- Data for Name: ServiceOrderItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ServiceOrderItem" (id, "serviceOrderId", type, "productId", "serviceId", name, quantity, "unitPrice", "costPrice", total, "warrantyMonths") FROM stdin;
cmp8soi0t000mw6aq6yh24rt5	cmp8s5rah000hw6aqd7r40at1	SERVICE	\N	cmndrx2pi009jxpl6gb5ihu4m	Limpeza interna de Ps5	1	250.00	0.00	250.00	0
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: Stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Stock" (id, "productId", quantity, "averageCost", "totalValue", "minStock", "updatedAt") FROM stdin;
cmp4l4ezt000givh6cwy57apz	cmp4l4eyr000civh64zs9vk28	6	28.00	0.00	2	2026-05-13 21:41:51.22
cmp4l5x7d000pivh6qowokz6y	cmp4l5x73000livh6e8dqb5ct	11	42.00	0.00	5	2026-05-13 21:43:01.473
cmp4l7hx3000yivh6esx0ftln	cmp4l7hx0000uivh6gnj2o86a	14	14.00	0.00	3	2026-05-13 21:44:14.97
cmp4l8p1v0017ivh6pxfd1ifk	cmp4l8p1b0013ivh6ntebyikt	2	38.00	0.00	1	2026-05-13 21:45:10.872
cmp4lakmb001hivh69uqtbvh3	cmp4lakm1001divh6kn1gvdj9	0	40.00	0.00	5	2026-05-13 21:46:38.435
cmp4lbcuk001pivh6xi2e9kh7	cmp4lbcuf001livh64rv7tig2	0	18.00	0.00	5	2026-05-13 21:47:59.661
cmp4lddew0021ivh6chojqncf	cmp4lddeu001xivh6o1ao0yq9	0	28.00	0.00	5	2026-05-13 21:48:49.064
cmp4lefza0028ivh6zkzr2e42	cmp4lefz70024ivh6a7uukowt	0	10.00	0.00	5	2026-05-13 21:49:39.046
cmp4lfmcf002givh6o0qjq7pq	cmp4lfmc5002civh6vvzrcyg2	0	42.00	0.00	5	2026-05-13 21:50:33.951
cmp4lh2kz002oivh63mr09lz7	cmp4lh2kr002kivh6c6jsf9ui	3	45.00	0.00	1	2026-05-13 21:51:41.655
cmp4lisdz002yivh6huab6tn6	cmp4lisdw002uivh6t1fs2q78	1	45.00	0.00	1	2026-05-13 21:53:01.755
cmp4lk7um0038ivh6txe2zsjk	cmp4lk7ug0034ivh6osmxceyv	2	35.00	0.00	1	2026-05-13 21:54:08.45
cmp4lnahy003hivh6seztfuay	cmp4lnahr003divh671q78k09	2	3560.00	0.00	2	2026-05-13 21:56:31.851
cmp5hyf82003qivh6y3fuh0mx	cmp5hyf7f003mivh6x5pngsbj	11	10.00	0.00	5	2026-05-14 13:00:58.909
cmp5hz7u5003zivh6lc25g70g	cmp5hz7u0003vivh6rfw9jfkc	2	40.00	0.00	1	2026-05-14 13:01:35.984
cmp8xd6qu0029w6aqssucojcf	cmp8xd6px0025w6aqald884sd	1	65.00	0.00	1	2026-05-16 22:35:40.541
cmp8xfzhg002jw6aqwnon955l	cmp8xfzhd002fw6aqb65s3zq5	1	110.00	0.00	1	2026-05-16 22:37:51.078
cmp8xh6zc002sw6aqbc4ogi69	cmp8xh6z1002ow6aq8gjqrmf5	1	110.00	0.00	1	2026-05-16 22:38:47.453
cmp8xj0hh0032w6aqsdq98nu6	cmp8xj0hc002yw6aqc6o6wbom	1	30.00	0.00	1	2026-05-16 22:40:12.344
cmp8xkivg003cw6aq2sgjl6hr	cmp8xkive0038w6aqaqm8ygam	2	40.00	0.00	1	2026-05-16 22:41:22.83
cmp8xlthm003mw6aqzfhunjbf	cmp8xlthk003iw6aq3kue5jwy	1	0.00	0.00	1	2026-05-16 22:42:23.244
cmp8xnqkt003ww6aq9v9wr120	cmp8xnqkm003sw6aqya7j8i8l	1	50.00	0.00	1	2026-05-16 22:43:52.785
cmp8xodpx0045w6aqrvc8i1zv	cmp8xodpv0041w6aq38bt6apn	0	40.00	0.00	1	2026-05-16 22:44:22.773
cmp8xq3nu004cw6aqnzph5w9r	cmp8xq3nr0048w6aqvvmgykon	1	200.00	0.00	1	2026-05-16 22:45:43.052
cmp8xrmmo004mw6aq2do1bs17	cmp8xrmml004iw6aqmbmmoygm	1	50.00	0.00	1	2026-05-16 22:46:54.291
cmp8xsm4k004ww6aq9t4obqch	cmp8xsm4g004sw6aqbp05fdt6	1	150.00	0.00	1	2026-05-16 22:47:40.295
cmp8xticn0056w6aqs5froqr0	cmp8xtick0052w6aqqi1jmxy7	1	200.00	0.00	1	2026-05-16 22:48:22.057
cmp8xvi1c005fw6aqrhiqgl1o	cmp8xvi13005bw6aqe072x78g	1	2000.00	0.00	1	2026-05-16 22:49:54.964
cmp8xwcvi005ow6aquimax5o6	cmp8xwcvd005kw6aqp1zizakm	0	1200.00	0.00	5	2026-05-16 22:50:34.926
cmp8xynx4005vw6aqre2x4538	cmp8xynx1005rw6aq15rqp8be	1	1000.00	0.00	1	2026-05-16 22:52:22.555
cmp8y1zl50064w6aqejrj4hf6	cmp8y1zkw0060w6aqi7z6z3e0	1	1300.00	0.00	1	2026-05-16 22:54:57.645
cmpbd8mh90007hp9z8lr9310n	cmpbd8mg80003hp9ziap0erdt	2	25.00	0.00	1	2026-05-18 15:35:33.858
cmpbda5ea000ghp9zurm73h6q	cmpbda5e1000chp9zgwxvbz4o	1	25.00	0.00	1	2026-05-18 15:36:45.014
cmpbdbc6b000php9zojdgpvxr	cmpbdbc68000lhp9zjo4hiwjz	2	25.00	0.00	1	2026-05-18 15:37:40.454
cmpbdcfdw000yhp9zh27m68p9	cmpbdcfdm000uhp9zeei3saot	1	25.00	0.00	1	2026-05-18 15:38:31.272
cmpbddvxs0017hp9zi7uuyttp	cmpbddvxl0013hp9z5i19u8wp	2	25.00	0.00	1	2026-05-18 15:39:39.379
cmpbdek2s001ghp9zcwtdm0al	cmpbdek2f001chp9z269415qv	2	25.00	0.00	1	2026-05-18 15:40:10.666
cmpbdfm2t001php9z2350a8gr	cmpbdfm2m001lhp9zc7tdf878	6	25.00	0.00	1	2026-05-18 15:40:59.911
cmpbdgdz1001yhp9z24rx7rln	cmpbdgdyw001uhp9zukj9f6te	2	25.00	0.00	1	2026-05-18 15:41:36.064
cmpbdhaym0027hp9za0yhqqqd	cmpbdhayi0023hp9z2ome0gtx	2	25.00	0.00	1	2026-05-18 15:42:18.818
cmpbdig6n002ghp9z2b8qyrms	cmpbdig6i002chp9zouqpo40z	1	25.00	0.00	1	2026-05-18 15:43:12.241
cmpbdjemr002php9zor0d8mfv	cmpbdjemj002lhp9zdcphsrho	1	25.00	0.00	1	2026-05-18 15:43:56.887
cmpbdk1bi002yhp9zocowmeuj	cmpbdk1bc002uhp9zipdjiekq	1	25.00	0.00	1	2026-05-18 15:44:26.291
cmpbdl8c10037hp9zr4m8ua8x	cmpbdl8be0033hp9za0ang19e	1	25.00	0.00	1	2026-05-18 15:45:22.044
cmpbdmr4l003ghp9zjssbn43e	cmpbdmr4j003chp9zlcnvcdus	1	25.00	0.00	1	2026-05-18 15:46:33.049
cmpbdninz003php9z1picjn0x	cmpbdninq003lhp9zy3kgn3kg	1	25.00	0.00	1	2026-05-18 15:47:08.744
cmpbdpmff003yhp9zzg0girxh	cmpbdpmfc003uhp9zzc4ipa94	1	25.00	0.00	1	2026-05-18 15:48:46.926
cmpbdr8xi0047hp9zojs37svj	cmpbdr8wd0043hp9z703u4pbn	1	25.00	0.00	1	2026-05-18 15:50:02.772
cmpbds2gi004ghp9zwbsfgn0l	cmpbds2g7004chp9zvoquqrsq	1	25.00	0.00	1	2026-05-18 15:50:41.015
cmpbdtj2g004php9z4s0g3phn	cmpbdtj26004lhp9z5kux5916	1	25.00	0.00	1	2026-05-18 15:51:49.196
cmpbdw925004yhp9zg0vjp590	cmpbdw91j004uhp9zi74rdcwq	1	25.00	0.00	1	2026-05-18 15:53:56.198
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StockMovement" (id, quantity, "productId", "createdAt", "createdBy", reason, "referenceId", type, invoice, "resultingAverageCost", "supplierId", "unitCost") FROM stdin;
cmp4l4ezz000iivh66hc0a2zy	6	cmp4l4eyr000civh64zs9vk28	2026-05-13 21:41:51.215	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	28.00
cmp4l5x7g000rivh6ygf1cjfz	11	cmp4l5x73000livh6e8dqb5ct	2026-05-13 21:43:01.468	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	42.00
cmp4l7hx40010ivh6yho1oifh	14	cmp4l7hx0000uivh6gnj2o86a	2026-05-13 21:44:14.968	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	14.00
cmp4l8p1x0019ivh6jys1sk3f	2	cmp4l8p1b0013ivh6ntebyikt	2026-05-13 21:45:10.869	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	38.00
cmp4lh2l1002qivh69u6cw7jo	3	cmp4lh2kr002kivh6c6jsf9ui	2026-05-13 21:51:41.653	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	45.00
cmp4lise10030ivh6n7r76gkc	1	cmp4lisdw002uivh6t1fs2q78	2026-05-13 21:53:01.754	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	45.00
cmp4lk7un003aivh64i6tkr28	2	cmp4lk7ug0034ivh6osmxceyv	2026-05-13 21:54:08.448	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	35.00
cmp4lnai1003jivh6q166vnas	2	cmp4lnahr003divh671q78k09	2026-05-13 21:56:31.849	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	3560.00
cmp5hyf86003sivh689xnxybz	11	cmp5hyf7f003mivh6x5pngsbj	2026-05-14 13:00:58.902	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	10.00
cmp5hz7u60041ivh6blih0n1u	2	cmp5hz7u0003vivh6rfw9jfkc	2026-05-14 13:01:35.982	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	40.00
cmp8xd6r4002bw6aqgi3k9mum	1	cmp8xd6px0025w6aqald884sd	2026-05-16 22:35:40.529	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	65.00
cmp8xfzhh002lw6aqkmv3p31o	1	cmp8xfzhd002fw6aqb65s3zq5	2026-05-16 22:37:51.077	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	110.00
cmp8xh6ze002uw6aqf3tfvp67	1	cmp8xh6z1002ow6aq8gjqrmf5	2026-05-16 22:38:47.451	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	110.00
cmp8xj0hi0034w6aq0u5rfqd9	1	cmp8xj0hc002yw6aqc6o6wbom	2026-05-16 22:40:12.342	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	30.00
cmp8xkivh003ew6aqno9hcivj	2	cmp8xkive0038w6aqaqm8ygam	2026-05-16 22:41:22.829	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	40.00
cmp8xlthn003ow6aq547dwcs9	1	cmp8xlthk003iw6aq3kue5jwy	2026-05-16 22:42:23.244	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	0.00
cmp8xnqkv003yw6aqrgsa4098	1	cmp8xnqkm003sw6aqya7j8i8l	2026-05-16 22:43:52.783	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	50.00
cmp8xq3nv004ew6aqpk89zyuq	1	cmp8xq3nr0048w6aqvvmgykon	2026-05-16 22:45:43.052	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	200.00
cmp8xrmmp004ow6aql8kvtzm9	1	cmp8xrmml004iw6aqmbmmoygm	2026-05-16 22:46:54.29	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	50.00
cmp8xsm4l004yw6aq4xb5d7pr	1	cmp8xsm4g004sw6aqbp05fdt6	2026-05-16 22:47:40.293	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	150.00
cmp8xticn0058w6aqkndwg1s5	1	cmp8xtick0052w6aqqi1jmxy7	2026-05-16 22:48:22.056	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	200.00
cmp8xvi1e005hw6aq4u37mbs2	1	cmp8xvi13005bw6aqe072x78g	2026-05-16 22:49:54.962	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	2000.00
cmp8xynx5005xw6aqwfvbk0p2	1	cmp8xynx1005rw6aq15rqp8be	2026-05-16 22:52:22.553	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	1000.00
cmp8y1zl70066w6aqv4ntkn27	1	cmp8y1zkw0060w6aqi7z6z3e0	2026-05-16 22:54:57.643	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	1300.00
cmpbd8mhm0009hp9z7ct0wemb	2	cmpbd8mg80003hp9ziap0erdt	2026-05-18 15:35:33.85	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbda5eb000ihp9zgxw4mcaq	1	cmpbda5e1000chp9zgwxvbz4o	2026-05-18 15:36:45.011	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdbc6d000rhp9z23izrtxv	2	cmpbdbc68000lhp9zjo4hiwjz	2026-05-18 15:37:40.453	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdcfdy0010hp9zpr9nj028	1	cmpbdcfdm000uhp9zeei3saot	2026-05-18 15:38:31.27	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbddvxt0019hp9zxpbrfhp1	2	cmpbddvxl0013hp9z5i19u8wp	2026-05-18 15:39:39.377	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdek2u001ihp9zu2ushdvy	2	cmpbdek2f001chp9z269415qv	2026-05-18 15:40:10.662	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdfm2u001rhp9z9xri917o	6	cmpbdfm2m001lhp9zc7tdf878	2026-05-18 15:40:59.91	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdgdz20020hp9z9r78tten	2	cmpbdgdyw001uhp9zukj9f6te	2026-05-18 15:41:36.062	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdhayn0029hp9zc69x20k7	2	cmpbdhayi0023hp9z2ome0gtx	2026-05-18 15:42:18.816	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdig6o002ihp9ziddyo8ef	1	cmpbdig6i002chp9zouqpo40z	2026-05-18 15:43:12.241	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdjems002rhp9zs3jv5vy4	1	cmpbdjemj002lhp9zdcphsrho	2026-05-18 15:43:56.884	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdk1bk0030hp9zubi0cyu7	1	cmpbdk1bc002uhp9zipdjiekq	2026-05-18 15:44:26.288	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdl8c70039hp9zfvjb6544	1	cmpbdl8be0033hp9za0ang19e	2026-05-18 15:45:22.04	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdmr4n003ihp9z7chjeo6u	1	cmpbdmr4j003chp9zlcnvcdus	2026-05-18 15:46:33.047	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdnio3003rhp9z0qvm87rj	1	cmpbdninq003lhp9zy3kgn3kg	2026-05-18 15:47:08.74	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdpmfg0040hp9z4292o1hz	1	cmpbdpmfc003uhp9zzc4ipa94	2026-05-18 15:48:46.925	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdr8y20049hp9z0qjwsccm	1	cmpbdr8wd0043hp9z703u4pbn	2026-05-18 15:50:02.762	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbds2gk004ihp9zcw707sp6	1	cmpbds2g7004chp9zvoquqrsq	2026-05-18 15:50:41.012	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdtj2h004rhp9zmzp84p1k	1	cmpbdtj26004lhp9z5kux5916	2026-05-18 15:51:49.194	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
cmpbdw9290050hp9zgii7c518	1	cmpbdw91j004uhp9zi74rdcwq	2026-05-18 15:53:56.193	cmndrx24x005oxpl63njyr4ps	Estoque Inicial	\N	IN_ADJUSTMENT	\N	\N	\N	25.00
\.


--
-- Data for Name: StoreSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StoreSettings" (id, "nameFantasia", cnpj, address, phone, email, "serviceHours", "updatedAt") FROM stdin;
cmp3zkmub0000m1n7jms1dcl1	Virtual Games	00.000.000/0001-00	Rua Venâncio Aires, 1434, Torre Divindade. Sala 106 D-2, Centro, Santa Maria, RS - CEP 97010-002	(55) 99725-2786	contato@virtualgames.com	Segunda a Sexta: 09:00 às 18:30 | Sábado: 09:00 às 13:00	2026-05-13 11:38:36.323
cmndryw8t0000yzzkyt7lamup	Virtual Games	00.000.000/0001-00	Rua Venâncio Aires, 1434, Torre Divindade. Sala 106 D-2, Centro, Santa Maria, RS - CEP 97010-002	(55) 99725-2786	contato@virtualgames.com	Segunda a Sexta: 09:00 às 18:30 | Sábado: 09:00 às 13:00	2026-03-30 22:44:01.853
fc01d690-0d60-4e91-80b2-b8f9a8e08cde	Virtual Games	00.000.000/0001-00	Rua Venancio Aires 1434 Torre Divindade Sala 106 D-2 Centro Santa Maria RS CEP 97010-002	(55) 99725-2786	contato@virtualgames.com	Segunda a Sexta 09h as 18h30 | Sabado 09h as 13h	2026-03-30 23:57:14.422
\.


--
-- Data for Name: Subcategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Subcategory" (id, "categoryId", name, slug, description, active, "createdAt", "updatedAt") FROM stdin;
cmndrx2cu0062xpl6c6lgp5ph	cmndrx2cp0060xpl69fqhprbq	Console	console	Categoria consolidada Console	t	2026-03-30 22:42:36.463	2026-03-30 22:42:36.463
cmndrx2d30065xpl6r70v0274	cmndrx2cz0063xpl6g8j5nn4x	Jogo	jogo	Categoria consolidada Jogo	t	2026-03-30 22:42:36.471	2026-03-30 22:42:36.471
cmndrx2d90068xpl6y0t4bek5	cmndrx2d60066xpl6nc7btcxn	Computador	computador	Categoria consolidada Computador	t	2026-03-30 22:42:36.478	2026-03-30 22:42:36.478
cmndrx2dg006bxpl60b81fhrf	cmndrx2dd0069xpl6ddqh77tl	Placa	placa	Categoria consolidada Placa	t	2026-03-30 22:42:36.484	2026-03-30 22:42:36.484
cmndrx2dn006expl6zylyi3q3	cmndrx2dk006cxpl6rtdo5nnt	Hardware	hardware	Categoria consolidada Hardware	t	2026-03-30 22:42:36.491	2026-03-30 22:42:36.491
cmndrx2du006hxpl64io79jww	cmndrx2dr006fxpl6inufoqdt	Periférico	periferico	Categoria consolidada Periférico	t	2026-03-30 22:42:36.498	2026-03-30 22:42:36.498
cmndrx2e1006kxpl6qf46h1an	cmndrx2dx006ixpl6vsx8qxdb	Smartphone	smartphone	Categoria consolidada Smartphone	t	2026-03-30 22:42:36.506	2026-03-30 22:42:36.506
cmndrx2e8006nxpl6x6okcevi	cmndrx2e5006lxpl613j3lba5	Tablet	tablet	Categoria consolidada Tablet	t	2026-03-30 22:42:36.512	2026-03-30 22:42:36.512
cmndrx2ee006qxpl6yshsb9rt	cmndrx2eb006oxpl6v9f1vglh	Wearable	wearable	Categoria consolidada Wearable	t	2026-03-30 22:42:36.519	2026-03-30 22:42:36.519
cmndrx2el006txpl66ciidmzl	cmndrx2ei006rxpl6mxknd5s9	Televisor	televisor	Categoria consolidada Televisor	t	2026-03-30 22:42:36.526	2026-03-30 22:42:36.526
cmndrx2es006wxpl6uzvv4db5	cmndrx2eo006uxpl61ofifoig	Monitor	monitor	Categoria consolidada Monitor	t	2026-03-30 22:42:36.532	2026-03-30 22:42:36.532
cmndrx2ey006zxpl62yigtd8g	cmndrx2ev006xxpl63n3jy2az	Áudio e Vídeo	audio-e-video	Categoria consolidada Áudio e Vídeo	t	2026-03-30 22:42:36.539	2026-03-30 22:42:36.539
cmndrx2f50072xpl6o385tepp	cmndrx2f20070xpl6dbckhnh5	Armazenamento	armazenamento	Categoria consolidada Armazenamento	t	2026-03-30 22:42:36.545	2026-03-30 22:42:36.545
cmndrx2fc0075xpl6kk1oyt3k	cmndrx2f80073xpl6v83yzabd	Rede	rede	Categoria consolidada Rede	t	2026-03-30 22:42:36.552	2026-03-30 22:42:36.552
cmndrx2fj0078xpl6ehkisrks	cmndrx2fg0076xpl61iv6rtgj	Energia	energia	Categoria consolidada Energia	t	2026-03-30 22:42:36.559	2026-03-30 22:42:36.559
cmndrx2fp007bxpl6xtam1xmt	cmndrx2fm0079xpl62qt3j22j	Peça	peca	Categoria consolidada Peça	t	2026-03-30 22:42:36.566	2026-03-30 22:42:36.566
cmndrx2fw007expl64jeny1ud	cmndrx2ft007cxpl6zucv9gip	Acessório	acessorio	Categoria consolidada Acessório	t	2026-03-30 22:42:36.573	2026-03-30 22:42:36.573
cmndrx2g3007hxpl6z8skfoiv	cmndrx2fz007fxpl68zusnpei	Diverso	diverso	Categoria consolidada Diverso	t	2026-03-30 22:42:36.58	2026-03-30 22:42:36.58
\.


--
-- Data for Name: Supplier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Supplier" (id, name, contact, phone, active, "createdAt", "updatedAt", document, email) FROM stdin;
\.


--
-- Data for Name: SupplierInteraction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SupplierInteraction" (id, "supplierId", type, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, name, active, "createdAt", "updatedAt", "emailVerified", image, password, "roleId", "failedLoginAttempts", "lockedUntil") FROM stdin;
cmndrx24x005oxpl63njyr4ps	admin@virtualgames.com	Admin Dono	t	2026-03-30 22:42:36.177	2026-05-13 13:44:04.636	\N	\N	$2b$10$skFvR3H5KtP1zCq83YECTebhn7sBBstCtUp.n0eelb5GFuJUJ3ZR2	cmndrx1ej000txpl6qndp3u9o	0	\N
cmp443t1j0002m1n7kthmw1bm	kevinmgraeff@gmail.com	Kevin de Mello Graeff	t	2026-05-13 13:45:29.285	2026-05-13 13:45:29.285	\N	\N	$2b$10$FrNRAUJbru21o7Xg0fU/Au6vHDnhTE48HBy1DVyGOSp69ZDjMpV/u	cmndrx1zl004wxpl61rok9i7m	0	\N
cmp44a4po0006m1n742wbaa42	erfagundes20@gmail.com	Elias Rodrigues Fagundes 	t	2026-05-13 13:50:24.348	2026-05-13 13:50:24.348	\N	\N	$2b$10$kIZpE3riSDRwFW7kKYRUD.47QMRCAQ1p1Xyh55enefH/rakCecGdm	cmndrx1zl004wxpl61rok9i7m	0	\N
cmp44djem000am1n7zkj8zkfs	gabrielrs2castro@gmail.com	Gabriel Rae da Silva Castro 	t	2026-05-13 13:53:03.358	2026-05-13 13:53:03.358	\N	\N	$2b$10$U/Q01YIVsRSrOiH9VqgYPupzlFs0ZB.PwfOecJ60o4/J566b3t8p2	cmndrx1wl0041xpl6b8kfhqng	0	\N
\.


--
-- Data for Name: _ManufacturerToSubcategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."_ManufacturerToSubcategory" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
cea6b74c-603b-4bf1-afd3-8a6b1edc154d	74321ef4af21dd277012df04272490dac49483b673162e05f491e8db020c4494	2026-05-13 11:37:55.501021+00	20260209235126_init	\N	\N	2026-05-13 11:37:55.484359+00	1
f338b99c-e0ce-4ee0-bb62-c98e4a01bf2a	bb4ad68093fc7b72472a0710c056de93465c9cf50add9786c060817c304667f7	2026-05-13 11:37:57.338807+00	20260321205452_	\N	\N	2026-05-13 11:37:57.304569+00	1
fab58a5f-7543-4bfb-b64a-192660f52fcc	b6bfc7b5683200f1c4e8b05d8ed21f341afea7abdbe1c4fdfb5a6cfee1065021	2026-05-13 11:37:55.693446+00	20260213112428_init_full_backend	\N	\N	2026-05-13 11:37:55.502449+00	1
aae154b0-8cef-4c0f-b738-5b8d6ab3862f	a7e87a2b28b9174fbb7dc1ae82602068f32161411c27d5b4338024479c9aa876	2026-05-13 11:37:56.507025+00	20260215125802_init_professional	\N	\N	2026-05-13 11:37:55.699733+00	1
2e75b309-b8f2-4e8a-b4ff-4ce7a8652ef9	dfa992cca4f14a0543dd10e3175867733960ba26f68cdbfe20b46db4d5a59d43	2026-05-13 11:37:57.656292+00	20260327103000_add_warranty_snapshot_fields	\N	\N	2026-05-13 11:37:57.651133+00	1
df75fb5a-db4a-4f68-8cb6-6e7dfc3b7a51	2744bd51c159d764659d007dc29e52d0888b705cef7c68d1ae93e1ae4033efec	2026-05-13 11:37:56.562445+00	20260219212422_feature_product_workflow	\N	\N	2026-05-13 11:37:56.508974+00	1
a7d188df-c2f3-4f93-bce8-c62c26495f5a	84d918e02f0f1977a34c7e1e43678ce63f3f4563f24bdbc5e631766773190369	2026-05-13 11:37:57.352888+00	20260324110000_service_category_optional	\N	\N	2026-05-13 11:37:57.340062+00	1
b44a84c3-aff3-4928-a37f-74cfeb4b0628	d429561201431cb4cdee282b1b56516a2f945e68e45c0a550319ade737473690	2026-05-13 11:37:56.614815+00	20260226220309_add_category_hierarchy	\N	\N	2026-05-13 11:37:56.56626+00	1
18dfca30-f540-4489-b705-3293f2ecbe73	3537188e600d06b7218b61c4e6dc47946f897fb759e6ee15f9d9f771fc3e00cb	2026-05-13 11:37:57.069998+00	20260227001531_add_cadastros_marketplace_module	\N	\N	2026-05-13 11:37:56.621994+00	1
3fdafb7c-54d3-49e1-b744-077ed2838974	13bb60a338ca6d480101e0bda1e3adc33f5c15ea20497898abd77560a04d060a	2026-05-13 11:37:57.090974+00	20260227002341_fix_subcategory_slug_composite	\N	\N	2026-05-13 11:37:57.072261+00	1
b074bd2a-db97-4c76-905a-fdf9377c39be	8dbca97a141c5f95ef9d201b371348b246ccda3917e8ebe1c8e6adb332bf3363	2026-05-13 11:37:57.376289+00	20260324113000_remove_service_categories	\N	\N	2026-05-13 11:37:57.356524+00	1
242063a8-4f35-478f-ae22-d19302acba66	f872c74062376ef42adf42bc3274ff1ba8ba80400f5a1746f504dc2166d6cdfd	2026-05-13 11:37:57.14825+00	20260227185623_add_attribute_options	\N	\N	2026-05-13 11:37:57.096839+00	1
24d5c1e6-75d6-4817-81df-2b357f5c9ada	c9d0baaf8f42933bafe6de04f0ea7e053894e9dac81bb45b99e0aa2ff9af6fed	2026-05-13 11:37:57.231797+00	20260311140708_add_attribute_order	\N	\N	2026-05-13 11:37:57.155506+00	1
53e4aa02-a4ba-48e4-b9e7-d1328f788a58	4d3a97373da11e1b04c9a4dcd59ae780d11a394cdffd6cbf9a2c9919ffcea9cf	2026-05-13 11:37:57.779579+00	20260427194421_add_login_lockout	\N	\N	2026-05-13 11:37:57.773297+00	1
fd90e856-8380-4f11-b982-997893ca8e9b	92197ce0f6a0b0d9d18dd7d059dfb2476d5d2d8b147b68d6a7b7861003ae9ec1	2026-05-13 11:37:57.261535+00	20260321120000_add_customer_funnel_card	\N	\N	2026-05-13 11:37:57.234301+00	1
ddb59086-f2e4-4622-ae1f-9e65ee7f34a4	580854bec5c5f0451041943b11900b785ed152bc8d175960e8e58e563dcdd770	2026-05-13 11:37:57.432489+00	20260325121000_remove_model_domain	\N	\N	2026-05-13 11:37:57.378734+00	1
1404e051-37a6-45de-9ee1-c084d9a74113	742795e1ab4ac3764750e2dcbbb8e6b82fb558e510a4d73b4cbec5156212bb02	2026-05-13 11:37:57.272499+00	20260321133000_add_feedback_realizado_stage	\N	\N	2026-05-13 11:37:57.264196+00	1
546ed0f5-5eb7-49f7-9a78-19d29fabef27	3232c893e91ddeac17a282b7872c4a94108938f9285111065a943a16f7f7d084	2026-05-13 11:37:57.292192+00	20260321140000_add_desinteressado_finalizado_stage	\N	\N	2026-05-13 11:37:57.275452+00	1
6b0c5536-5260-4342-9154-bd7d77fc6881	edca0fb903c03fa6ab645431566c74c7562cdbc64118feac1d8201056b2a5d74	2026-05-13 11:37:57.717326+00	20260329234826_remove_unused_service_fields	\N	\N	2026-05-13 11:37:57.657257+00	1
a3fd7887-20dc-4cd6-a980-af9068b2d576	5f3d025f2f5ff589908fcc49d0f1638de83df6085d51f6837728fd209cfd4d96	2026-05-13 11:37:57.303213+00	20260321200000_financial_receivable_fields	\N	\N	2026-05-13 11:37:57.296335+00	1
23b62b41-1a28-45c3-840a-24a006b3bdfc	da0ba04186e0571771d886fba83ce1b1bc9f6d327d36d5cae1cc6b92905bb3eb	2026-05-13 11:37:57.521398+00	20260325183000_customer_feedback_satisfaction	\N	\N	2026-05-13 11:37:57.434191+00	1
e9122aef-4dcf-44c3-97ba-b42e87fdd9ff	81aaee14579a28550bac98ea4d28ffeed9ba944bfb1ec8c9e3385e3b59d7aa57	2026-05-13 11:37:57.582002+00	20260325191000_feedback_request_funnel_card	\N	\N	2026-05-13 11:37:57.52427+00	1
de81f185-0c86-499d-a93f-316945750741	0ca1c4f851e62126a7b6f88a4d1c61a2c807c94876075fd5d300115aa75f2306	2026-05-13 11:37:57.639448+00	20260325203000_customer_interest_flow	\N	\N	2026-05-13 11:37:57.584625+00	1
bf387856-a130-4617-84cf-d2955972f13a	a2a82b6547581f5df98cc395bf1cb42f7059f1c46f8fe1a7899879642be9329b	2026-05-13 11:37:57.731422+00	20260330082227_init_employee	\N	\N	2026-05-13 11:37:57.718338+00	1
37625f6b-4b4e-485b-a3bd-bb0999de3498	0c566f685f5c50d99753f5c044ab8c781f227e6392868fa1245bfb3608634716	2026-05-13 11:37:57.649479+00	20260326143000_add_payment_fee_settings	\N	\N	2026-05-13 11:37:57.640545+00	1
c26c3add-27dd-4f75-94fc-ca1aa649ce80	7651c9b9fe26f63e3a241fd5fa4cfd163a3e37f6d951b691d7bc53e947e1fe40	2026-05-13 11:37:57.741669+00	20260330224230_init_store_settings_employee_profile	\N	\N	2026-05-13 11:37:57.732627+00	1
5d166a84-3cf4-4515-9d11-d51396748da6	42f8291f149cd2811f18ef8e23bc550ca3171a1ad9bd35af3b59fa84e4b2de3e	2026-05-13 11:37:57.790579+00	20260429123646_add_has_new_message_to_funnel_card	\N	\N	2026-05-13 11:37:57.782317+00	1
9e084d5d-f070-41c5-8e0a-831bf9914edf	575539f10586d29e848f91945c5350d53804275a41875e90a4395a648205715b	2026-05-13 11:37:57.772022+00	20260401114303_add_receivable_origin_and_service_commission_provision	\N	\N	2026-05-13 11:37:57.742855+00	1
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AttributeOption AttributeOption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AttributeOption"
    ADD CONSTRAINT "AttributeOption_pkey" PRIMARY KEY (id);


--
-- Name: Attribute Attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Attribute"
    ADD CONSTRAINT "Attribute_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: BlogAuthor BlogAuthor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogAuthor"
    ADD CONSTRAINT "BlogAuthor_pkey" PRIMARY KEY (id);


--
-- Name: BlogPost BlogPost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_pkey" PRIMARY KEY (id);


--
-- Name: CashMovement CashMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CashMovement"
    ADD CONSTRAINT "CashMovement_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: CostCenter CostCenter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CostCenter"
    ADD CONSTRAINT "CostCenter_pkey" PRIMARY KEY (id);


--
-- Name: CustomerFunnelCard CustomerFunnelCard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CustomerFunnelCard"
    ADD CONSTRAINT "CustomerFunnelCard_pkey" PRIMARY KEY (id);


--
-- Name: CustomerInteraction CustomerInteraction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CustomerInteraction"
    ADD CONSTRAINT "CustomerInteraction_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: DailyMetrics DailyMetrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyMetrics"
    ADD CONSTRAINT "DailyMetrics_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Item Item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_pkey" PRIMARY KEY (id);


--
-- Name: Manufacturer Manufacturer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Manufacturer"
    ADD CONSTRAINT "Manufacturer_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceCategory MarketplaceCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MarketplaceCategory"
    ADD CONSTRAINT "MarketplaceCategory_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceListing MarketplaceListing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_pkey" PRIMARY KEY (id);


--
-- Name: Marketplace Marketplace_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Marketplace"
    ADD CONSTRAINT "Marketplace_pkey" PRIMARY KEY (id);


--
-- Name: Payable Payable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payable"
    ADD CONSTRAINT "Payable_pkey" PRIMARY KEY (id);


--
-- Name: PaymentFeeSettings PaymentFeeSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PaymentFeeSettings"
    ADD CONSTRAINT "PaymentFeeSettings_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: ProductAttribute ProductAttribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductAttribute"
    ADD CONSTRAINT "ProductAttribute_pkey" PRIMARY KEY (id);


--
-- Name: ProductPriceHistory ProductPriceHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductPriceHistory"
    ADD CONSTRAINT "ProductPriceHistory_pkey" PRIMARY KEY (id);


--
-- Name: ProductVariation ProductVariation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductVariation"
    ADD CONSTRAINT "ProductVariation_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: RateLimit RateLimit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RateLimit"
    ADD CONSTRAINT "RateLimit_pkey" PRIMARY KEY (key);


--
-- Name: Receivable Receivable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Receivable"
    ADD CONSTRAINT "Receivable_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: SaleItem SaleItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleItem"
    ADD CONSTRAINT "SaleItem_pkey" PRIMARY KEY (id);


--
-- Name: SaleReturnItem SaleReturnItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleReturnItem"
    ADD CONSTRAINT "SaleReturnItem_pkey" PRIMARY KEY (id);


--
-- Name: SaleReturn SaleReturn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleReturn"
    ADD CONSTRAINT "SaleReturn_pkey" PRIMARY KEY (id);


--
-- Name: Sale Sale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Sale"
    ADD CONSTRAINT "Sale_pkey" PRIMARY KEY (id);


--
-- Name: ServiceCommissionProvision ServiceCommissionProvision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceCommissionProvision"
    ADD CONSTRAINT "ServiceCommissionProvision_pkey" PRIMARY KEY (id);


--
-- Name: ServiceOrderHistory ServiceOrderHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrderHistory"
    ADD CONSTRAINT "ServiceOrderHistory_pkey" PRIMARY KEY (id);


--
-- Name: ServiceOrderItem ServiceOrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_pkey" PRIMARY KEY (id);


--
-- Name: ServiceOrder ServiceOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrder"
    ADD CONSTRAINT "ServiceOrder_pkey" PRIMARY KEY (id);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (id);


--
-- Name: StoreSettings StoreSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreSettings"
    ADD CONSTRAINT "StoreSettings_pkey" PRIMARY KEY (id);


--
-- Name: Subcategory Subcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subcategory"
    ADD CONSTRAINT "Subcategory_pkey" PRIMARY KEY (id);


--
-- Name: SupplierInteraction SupplierInteraction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SupplierInteraction"
    ADD CONSTRAINT "SupplierInteraction_pkey" PRIMARY KEY (id);


--
-- Name: Supplier Supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: AttributeOption_attributeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AttributeOption_attributeId_idx" ON public."AttributeOption" USING btree ("attributeId");


--
-- Name: Attribute_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Attribute_slug_key" ON public."Attribute" USING btree (slug);


--
-- Name: BlogAuthor_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BlogAuthor_slug_key" ON public."BlogAuthor" USING btree (slug);


--
-- Name: BlogPost_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BlogPost_slug_key" ON public."BlogPost" USING btree (slug);


--
-- Name: Category_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Category_slug_key" ON public."Category" USING btree (slug);


--
-- Name: CustomerFunnelCard_customerId_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CustomerFunnelCard_customerId_active_idx" ON public."CustomerFunnelCard" USING btree ("customerId", active);


--
-- Name: CustomerFunnelCard_stage_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CustomerFunnelCard_stage_active_idx" ON public."CustomerFunnelCard" USING btree (stage, active);


--
-- Name: Customer_document_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_document_key" ON public."Customer" USING btree (document);


--
-- Name: Customer_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_email_key" ON public."Customer" USING btree (email);


--
-- Name: DailyMetrics_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyMetrics_date_key" ON public."DailyMetrics" USING btree (date);


--
-- Name: Employee_cpf_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Employee_cpf_key" ON public."Employee" USING btree (cpf);


--
-- Name: Item_serialNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Item_serialNumber_key" ON public."Item" USING btree ("serialNumber");


--
-- Name: Manufacturer_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Manufacturer_name_key" ON public."Manufacturer" USING btree (name);


--
-- Name: Manufacturer_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Manufacturer_slug_key" ON public."Manufacturer" USING btree (slug);


--
-- Name: MarketplaceCategory_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MarketplaceCategory_categoryId_idx" ON public."MarketplaceCategory" USING btree ("categoryId");


--
-- Name: MarketplaceCategory_marketplaceId_externalCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "MarketplaceCategory_marketplaceId_externalCode_key" ON public."MarketplaceCategory" USING btree ("marketplaceId", "externalCode");


--
-- Name: MarketplaceListing_externalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MarketplaceListing_externalId_idx" ON public."MarketplaceListing" USING btree ("externalId");


--
-- Name: MarketplaceListing_marketplaceId_productId_variationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "MarketplaceListing_marketplaceId_productId_variationId_key" ON public."MarketplaceListing" USING btree ("marketplaceId", "productId", "variationId");


--
-- Name: Marketplace_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Marketplace_name_key" ON public."Marketplace" USING btree (name);


--
-- Name: Permission_action_resource_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Permission_action_resource_key" ON public."Permission" USING btree (action, resource);


--
-- Name: ProductAttribute_productId_attributeId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ProductAttribute_productId_attributeId_key" ON public."ProductAttribute" USING btree ("productId", "attributeId");


--
-- Name: ProductVariation_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductVariation_sku_idx" ON public."ProductVariation" USING btree (sku);


--
-- Name: ProductVariation_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ProductVariation_sku_key" ON public."ProductVariation" USING btree (sku);


--
-- Name: Product_barcode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_barcode_idx" ON public."Product" USING btree (barcode);


--
-- Name: Product_baseSku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_baseSku_idx" ON public."Product" USING btree ("baseSku");


--
-- Name: Product_baseSku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_baseSku_key" ON public."Product" USING btree ("baseSku");


--
-- Name: Product_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_categoryId_idx" ON public."Product" USING btree ("categoryId");


--
-- Name: Product_manufacturerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_manufacturerId_idx" ON public."Product" USING btree ("manufacturerId");


--
-- Name: Receivable_origin_paidAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Receivable_origin_paidAt_idx" ON public."Receivable" USING btree (origin, "paidAt");


--
-- Name: Receivable_saleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Receivable_saleId_key" ON public."Receivable" USING btree ("saleId");


--
-- Name: Receivable_serviceOrderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Receivable_serviceOrderId_key" ON public."Receivable" USING btree ("serviceOrderId");


--
-- Name: RolePermission_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_key" ON public."RolePermission" USING btree ("roleId", "permissionId");


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: ServiceCommissionProvision_serviceOrderItemId_technicianUse_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ServiceCommissionProvision_serviceOrderItemId_technicianUse_key" ON public."ServiceCommissionProvision" USING btree ("serviceOrderItemId", "technicianUserId");


--
-- Name: ServiceCommissionProvision_status_paidAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceCommissionProvision_status_paidAt_idx" ON public."ServiceCommissionProvision" USING btree (status, "paidAt");


--
-- Name: ServiceCommissionProvision_technicianUserId_competenceYear__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceCommissionProvision_technicianUserId_competenceYear__idx" ON public."ServiceCommissionProvision" USING btree ("technicianUserId", "competenceYear", "competenceMonth", status);


--
-- Name: Service_internalCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Service_internalCode_key" ON public."Service" USING btree ("internalCode");


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: StockMovement_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StockMovement_productId_idx" ON public."StockMovement" USING btree ("productId");


--
-- Name: Stock_productId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Stock_productId_key" ON public."Stock" USING btree ("productId");


--
-- Name: Subcategory_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Subcategory_categoryId_idx" ON public."Subcategory" USING btree ("categoryId");


--
-- Name: Subcategory_slug_categoryId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Subcategory_slug_categoryId_key" ON public."Subcategory" USING btree (slug, "categoryId");


--
-- Name: Supplier_document_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Supplier_document_key" ON public."Supplier" USING btree (document);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: _ManufacturerToSubcategory_AB_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "_ManufacturerToSubcategory_AB_unique" ON public."_ManufacturerToSubcategory" USING btree ("A", "B");


--
-- Name: _ManufacturerToSubcategory_B_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "_ManufacturerToSubcategory_B_index" ON public."_ManufacturerToSubcategory" USING btree ("B");


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AttributeOption AttributeOption_attributeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AttributeOption"
    ADD CONSTRAINT "AttributeOption_attributeId_fkey" FOREIGN KEY ("attributeId") REFERENCES public."Attribute"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BlogPost BlogPost_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."BlogAuthor"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CashMovement CashMovement_payableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CashMovement"
    ADD CONSTRAINT "CashMovement_payableId_fkey" FOREIGN KEY ("payableId") REFERENCES public."Payable"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CashMovement CashMovement_receivableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CashMovement"
    ADD CONSTRAINT "CashMovement_receivableId_fkey" FOREIGN KEY ("receivableId") REFERENCES public."Receivable"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CustomerFunnelCard CustomerFunnelCard_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CustomerFunnelCard"
    ADD CONSTRAINT "CustomerFunnelCard_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerInteraction CustomerInteraction_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CustomerInteraction"
    ADD CONSTRAINT "CustomerInteraction_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Employee Employee_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item Item_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceCategory MarketplaceCategory_marketplaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MarketplaceCategory"
    ADD CONSTRAINT "MarketplaceCategory_marketplaceId_fkey" FOREIGN KEY ("marketplaceId") REFERENCES public."Marketplace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceListing MarketplaceListing_marketplaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_marketplaceId_fkey" FOREIGN KEY ("marketplaceId") REFERENCES public."Marketplace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceListing MarketplaceListing_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceListing MarketplaceListing_variationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_variationId_fkey" FOREIGN KEY ("variationId") REFERENCES public."ProductVariation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payable Payable_costCenterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payable"
    ADD CONSTRAINT "Payable_costCenterId_fkey" FOREIGN KEY ("costCenterId") REFERENCES public."CostCenter"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payable Payable_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payable"
    ADD CONSTRAINT "Payable_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductAttribute ProductAttribute_attributeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductAttribute"
    ADD CONSTRAINT "ProductAttribute_attributeId_fkey" FOREIGN KEY ("attributeId") REFERENCES public."Attribute"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductAttribute ProductAttribute_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductAttribute"
    ADD CONSTRAINT "ProductAttribute_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductPriceHistory ProductPriceHistory_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductPriceHistory"
    ADD CONSTRAINT "ProductPriceHistory_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductVariation ProductVariation_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductVariation"
    ADD CONSTRAINT "ProductVariation_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Product Product_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_manufacturerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_manufacturerId_fkey" FOREIGN KEY ("manufacturerId") REFERENCES public."Manufacturer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_originClientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_originClientId_fkey" FOREIGN KEY ("originClientId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Receivable Receivable_costCenterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Receivable"
    ADD CONSTRAINT "Receivable_costCenterId_fkey" FOREIGN KEY ("costCenterId") REFERENCES public."CostCenter"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Receivable Receivable_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Receivable"
    ADD CONSTRAINT "Receivable_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Receivable Receivable_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Receivable"
    ADD CONSTRAINT "Receivable_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public."Sale"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Receivable Receivable_serviceOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Receivable"
    ADD CONSTRAINT "Receivable_serviceOrderId_fkey" FOREIGN KEY ("serviceOrderId") REFERENCES public."ServiceOrder"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SaleItem SaleItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleItem"
    ADD CONSTRAINT "SaleItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SaleItem SaleItem_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleItem"
    ADD CONSTRAINT "SaleItem_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public."Sale"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SaleReturnItem SaleReturnItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleReturnItem"
    ADD CONSTRAINT "SaleReturnItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SaleReturnItem SaleReturnItem_saleReturnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleReturnItem"
    ADD CONSTRAINT "SaleReturnItem_saleReturnId_fkey" FOREIGN KEY ("saleReturnId") REFERENCES public."SaleReturn"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SaleReturn SaleReturn_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleReturn"
    ADD CONSTRAINT "SaleReturn_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SaleReturn SaleReturn_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleReturn"
    ADD CONSTRAINT "SaleReturn_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public."Sale"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Sale Sale_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Sale"
    ADD CONSTRAINT "Sale_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceOrderHistory ServiceOrderHistory_serviceOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrderHistory"
    ADD CONSTRAINT "ServiceOrderHistory_serviceOrderId_fkey" FOREIGN KEY ("serviceOrderId") REFERENCES public."ServiceOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceOrderItem ServiceOrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceOrderItem ServiceOrderItem_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceOrderItem ServiceOrderItem_serviceOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_serviceOrderId_fkey" FOREIGN KEY ("serviceOrderId") REFERENCES public."ServiceOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceOrder ServiceOrder_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrder"
    ADD CONSTRAINT "ServiceOrder_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceOrder ServiceOrder_technicianId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceOrder"
    ADD CONSTRAINT "ServiceOrder_technicianId_fkey" FOREIGN KEY ("technicianId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StockMovement StockMovement_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Stock Stock_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subcategory Subcategory_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subcategory"
    ADD CONSTRAINT "Subcategory_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SupplierInteraction SupplierInteraction_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SupplierInteraction"
    ADD CONSTRAINT "SupplierInteraction_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _ManufacturerToSubcategory _ManufacturerToSubcategory_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_ManufacturerToSubcategory"
    ADD CONSTRAINT "_ManufacturerToSubcategory_A_fkey" FOREIGN KEY ("A") REFERENCES public."Manufacturer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ManufacturerToSubcategory _ManufacturerToSubcategory_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_ManufacturerToSubcategory"
    ADD CONSTRAINT "_ManufacturerToSubcategory_B_fkey" FOREIGN KEY ("B") REFERENCES public."Subcategory"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 64KMjCnvRNFT1B1KVm3Zbe0qrbFBdmFZhXweVJ9cviUq1XiAI51WTJOd517HDJ3

